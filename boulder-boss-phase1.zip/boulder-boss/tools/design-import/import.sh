#!/bin/sh
# Regenerate src/screens/*.tsx from a Boulder Boss design handoff folder.
#   sh tools/design-import/import.sh path/to/boulder-boss-handoff
# Screens listed in screens.txt are converted 1:1 (layout, tokens, mock data in renderVals);
# nav/<screen>.json wires buttons to routes ('back' | 'soon' | 'jump' | '/path');
# patches.py re-applies the few hand edits. Reusable components (Chibi/Skyline/Wall/BottomNav)
# are hand-written in src/components and are NOT regenerated.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
HANDOFF="$(cd "${1:?usage: import.sh <handoff-dir>}" && pwd)"
OUT="$HERE/../../src/screens"
while read f n; do
  python3 -I "$HERE/dc2tsx.py" "$HANDOFF/screens/$f.dc.html" "$n" "$HERE/nav/$f.json" "$HERE/fx/$f.json" > "$OUT/$n.tsx"
done < "$HERE/screens.txt"
python3 -I "$HERE/patches.py" "$OUT"
echo "Regenerated $(wc -l < "$HERE/screens.txt") screens."
