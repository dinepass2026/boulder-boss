import sys, os
d = sys.argv[1]
def patch(name, pairs):
    p = os.path.join(d, name); s = open(p).read()
    for a, b in pairs:
        assert a in s, (name, a)
        s = s.replace(a, b, 1)
    open(p, 'w').write(s)
patch('A04ForgotPassword.tsx', [('onClick={v.back}', 'onClick={v.isStep1 ? () => go("back") : v.back}'), ('onClick={v.reset}', 'onClick={() => go("/map")}')])
patch('C16Climb.tsx', [('<Wall mode="climb"', '<Wall climbable onTop={() => go("/move/dyno")} mode="climb"')])
patch('C20Result.tsx', [('onClick={() => go("/routes")}', 'onClick={() => go(v.cta === "ลองอีกครั้ง" ? "/climb" : v.cta === "แข่งอีกรอบ" ? "soon" : "/routes")}')])
