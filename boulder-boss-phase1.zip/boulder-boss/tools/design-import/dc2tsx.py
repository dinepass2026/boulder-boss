#!/usr/bin/env python3
"""Convert a design-canvas .dc.html screen into a React TSX component.

Usage: dc2tsx.py <input.dc.html> <ComponentName> <navmap.json> > Out.tsx

- markup inside <x-dc> (minus <helmet>) -> JSX with style objects
- {{a.b}} holes -> v.a.b (or loop var a.b inside <sc-for>)
- <sc-for list as> -> .map(), <sc-if value> -> conditional
- <dc-import name=X ...> -> <X .../>
- DCLogic.renderVals -> plain function renderVals(props, state, setState)
- navmap: {"<label or raw label>": "/route" | "back" | "soon"} injects onClick on buttons/links
"""
import html
import json
import os
import re
import sys

VOID = {"br", "img", "input", "meta", "link", "hr", "source", "area", "col", "wbr"}
SVG_TAGS = {"svg", "path", "circle", "rect", "ellipse", "polygon", "polyline", "line", "g", "defs",
            "pattern", "lineargradient", "radialgradient", "stop", "text", "tspan", "clippath", "mask", "use"}
SVG_CASE = {"lineargradient": "linearGradient", "radialgradient": "radialGradient", "clippath": "clipPath"}
ATTR_MAP = {"class": "className", "for": "htmlFor", "tabindex": "tabIndex", "readonly": "readOnly",
            "maxlength": "maxLength", "minlength": "minLength", "inputmode": "inputMode",
            "autocomplete": "autoComplete", "colspan": "colSpan", "rowspan": "rowSpan",
            "autofocus": "autoFocus", "enterkeyhint": "enterKeyHint", "spellcheck": "spellCheck",
            "xlink:href": "href", "contenteditable": "contentEditable", "datetime": "dateTime",
            "onclick": "onClick", "onchange": "onChange", "oninput": "onInput"}
BOOL_ATTRS = {"disabled", "checked", "required", "readonly", "hidden", "selected", "autofocus", "multiple", "open"}
HOLE = re.compile(r"\{\{\s*([^}]*?)\s*\}\}")

COMPONENTS = {"Chibi", "Skyline", "Wall", "BottomNav"}


def tokenize(src):
    pos = 0
    tag_re = re.compile(r"<(/?)([a-zA-Z][a-zA-Z0-9-]*)((?:\s+[^\s=>/]+(?:\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+))?)*)\s*(/?)>")
    while pos < len(src):
        m = tag_re.search(src, pos)
        if not m:
            yield ("text", src[pos:])
            break
        if m.start() > pos:
            yield ("text", src[pos:m.start()])
        closing, name, attrs, selfclose = m.groups()
        if closing:
            yield ("close", name)
        else:
            al = []
            for am in re.finditer(r"([^\s=>/]+)(?:\s*=\s*(\"([^\"]*)\"|'([^']*)'|([^\s>]+)))?", attrs):
                k = am.group(1)
                val = am.group(3) if am.group(3) is not None else am.group(4) if am.group(4) is not None else am.group(5)
                al.append((k, None if val is None else html.unescape(val)))
            yield ("open", name, al, bool(selfclose))
        pos = m.end()


def parse(src):
    root = {"tag": "#root", "attrs": [], "children": []}
    stack = [root]
    for tok in tokenize(src):
        if tok[0] == "text":
            stack[-1]["children"].append({"tag": "#text", "text": html.unescape(tok[1])})
        elif tok[0] == "open":
            node = {"tag": tok[1], "attrs": tok[2], "children": []}
            stack[-1]["children"].append(node)
            if not tok[3] and tok[1].lower() not in VOID:
                stack.append(node)
        else:
            name = tok[1]
            # pop to matching
            for i in range(len(stack) - 1, 0, -1):
                if stack[i]["tag"] == name:
                    del stack[i:]
                    break
    return root


def n_text(node):
    if node["tag"] == "#text":
        return node["text"]
    return "".join(n_text(c) for c in node.get("children", []))


class Conv:
    def __init__(self, navmap, name, fx=None):
        self.fx = fx or []
        self.nav = navmap
        self.name = name
        self.used_components = set()
        self.unmatched = []

    def expr(self, e, scope):
        e = e.strip()
        if e in ("true", "false"):
            return e
        head = re.split(r"[.\[]", e, maxsplit=1)[0]
        return e if head in scope else "v." + e

    def str_or_tpl(self, s, scope):
        """attribute value -> JSX attribute value"""
        holes = list(HOLE.finditer(s))
        if not holes:
            return json.dumps(s, ensure_ascii=False)
        if len(holes) == 1 and holes[0].group(0) == s.strip():
            return "{" + self.expr(holes[0].group(1), scope) + "}"
        out = HOLE.sub(lambda m: "${" + self.expr(m.group(1), scope) + "}", s.replace("`", "\\`"))
        return "{`" + out + "`}"

    def style(self, s, scope):
        props = []
        for decl in re.split(r";(?![^(]*\))", s):
            if ":" not in decl:
                continue
            k, val = decl.split(":", 1)
            k, val = k.strip(), val.strip()
            if not k:
                continue
            if k.startswith("--"):
                key = json.dumps(k)
            else:
                key = re.sub(r"-([a-z])", lambda m: m.group(1).upper(), k)
                if key.startswith("Ms"):
                    key = "ms" + key[2:]
            if HOLE.search(val):
                if HOLE.fullmatch(val):
                    jv = self.expr(HOLE.fullmatch(val).group(1), scope)
                else:
                    jv = "`" + HOLE.sub(lambda m: "${" + self.expr(m.group(1), scope) + "}", val) + "`"
            else:
                jv = json.dumps(val, ensure_ascii=False)
            props = [pp for pp in props if not pp.startswith(key + ": ")]  # CSS: last declaration wins
            props.append(f"{key}: {jv}")
        return "{{ " + ", ".join(props) + " }}"

    def text_of(self, node):
        if node["tag"] == "#text":
            return node["text"]
        return "".join(self.text_of(c) for c in node.get("children", []))

    def nav_handler(self, node):
        attrs = dict(node["attrs"])
        label = (attrs.get("aria-label") or "").strip()
        text = re.sub(r"\s+", " ", self.text_of(node)).strip()
        for cand in (label, text):
            if cand and cand in self.nav:
                return self.nav[cand], cand
        # prefix match (keys ending with *)
        for k, target in self.nav.items():
            if k.endswith("*") and any(c.startswith(k[:-1]) for c in (label, text) if c):
                return target, k
        return None, (label or text)

    def fx_classes(self, node):
        """Animation classes: per-screen fx map + generic rules (fills, live dots, sheets)."""
        raw = " ".join(f'{k}="{v}"' if v is not None else k for k, v in node["attrs"])
        st = dict(node["attrs"]).get("style") or ""
        cls = []
        for rule in self.fx:
            hit = raw == rule["match"] if rule.get("exact") else rule["match"] in raw
            if hit and not rule.get("wrap"):
                cls.append(rule["cls"])
        pct = re.search(r"(?:^|;\s*)width: (\d+)%", st)
        if pct and "bb-load" not in cls and int(pct.group(1)) < 100 and "background" in st and (
                "height: 100%" in st or ("position: absolute" in st and "left: 0" in st and "bottom: 0" in st)):
            cls.append("bb-fill")
        if "width: 8px; height: 8px; border-radius: 50%; background: #17B2A0" in st:
            cls.append("bb-live")
        if "bottom: 0" in st and re.search(r"border-radius: 2[48]px 2[48]px 0 0", st):
            cls.append("bb-sheet")
        if node.get("_loop"):
            cls.append("bb-in")
        return cls

    def wrap_class(self, node):
        raw = " ".join(f'{k}="{v}"' if v is not None else k for k, v in node["attrs"])
        for rule in self.fx:
            if rule.get("wrap") and rule["match"] in raw:
                return rule["cls"]
        return None

    def attrs_jsx(self, node, scope, is_svg):
        out = []
        extra = self.fx_classes(node)
        if extra:
            out.append('className="' + " ".join(dict.fromkeys(extra)) + '"')
        loop_delay = node.get("_loop")
        tag = node["tag"]
        has_click = any(k.lower() == "onclick" for k, _ in node["attrs"])
        select_default = None
        for k, val in node["attrs"]:
            kl = k.lower()
            if kl.startswith("hint-"):
                continue
            if kl == "style":
                st = self.style(val or "", scope)
                if loop_delay:
                    st = st[:-3] + f", animationDelay: `${{Math.min({loop_delay}, 12) * 45}}ms` }}}}"
                out.append("style=" + st)
                continue
            if kl in ATTR_MAP:
                key = ATTR_MAP[kl]
            elif kl.startswith("aria-") or kl.startswith("data-"):
                key = kl
            elif "-" in k or ":" in k:
                key = re.sub(r"[-:]([a-z])", lambda m: m.group(1).upper(), k)
            else:
                key = k
            if tag in ("input", "textarea") and kl == "value":
                key = "defaultValue"
            if tag == "input" and kl == "checked":
                key = "defaultChecked"
            if tag == "option" and kl == "selected":
                continue
            if val is None:
                if kl in BOOL_ATTRS or True:
                    out.append(key)
                continue
            if key in ("onClick", "onChange", "onInput"):
                m = HOLE.fullmatch(val.strip())
                out.append(f"{key}={{{self.expr(m.group(1), scope)}}}" if m else f"{key}={{() => {{}}}}")
                continue
            if key in ("rows", "cols", "maxLength", "minLength", "tabIndex", "size") and val.strip().isdigit():
                out.append(f"{key}={{{val.strip()}}}")
                continue
            out.append(f"{key}={self.str_or_tpl(val, scope)}")
        if tag == "textarea" and n_text(node).strip():
            out.append("defaultValue=" + json.dumps(n_text(node).strip(), ensure_ascii=False))
        if tag == "select":
            for c in node["children"]:
                if c["tag"] == "option" and any(k == "selected" for k, _ in c["attrs"]):
                    a = dict(c["attrs"])
                    select_default = a.get("value") or self.text_of(c).strip()
            if select_default is not None:
                out.append("defaultValue=" + json.dumps(select_default, ensure_ascii=False))
        if loop_delay and not any(k.lower() == "style" for k, _ in node["attrs"]):
            out.append(f"style={{{{ animationDelay: `${{Math.min({loop_delay}, 12) * 45}}ms` }}}}")
        if tag in ("button", "a") and not has_click:
            target, lab = self.nav_handler(node)
            if target:
                out.append(f"onClick={{() => go({json.dumps(target, ensure_ascii=False)})}}")
            else:
                self.unmatched.append(lab)
        if tag == "a" and not any(k.lower() == "href" for k, _ in node["attrs"]):
            out.append('href="#"')
        return out

    def children(self, node, scope, ind, is_svg):
        parts = []
        for c in node["children"]:
            r = self.node(c, scope, ind, is_svg)
            if r:
                parts.append(r)
        return parts

    def node(self, n, scope, ind, is_svg=False):
        pad = "  " * ind
        tag = n["tag"]
        if tag == "#text":
            t = n["text"]
            if not t.strip():
                return None if "\n" in t else pad + '{" "}'
            pieces = []
            last = 0
            for m in HOLE.finditer(t):
                if m.start() > last:
                    pieces.append("{" + json.dumps(t[last:m.start()], ensure_ascii=False) + "}")
                pieces.append("{" + self.expr(m.group(1), scope) + "}")
                last = m.end()
            if last < len(t):
                pieces.append("{" + json.dumps(t[last:], ensure_ascii=False) + "}")
            return pad + "".join(pieces)
        if tag == "helmet" or tag == "script" or tag == "style":
            return None
        if tag == "sc-for":
            a = dict(n["attrs"])
            lst = self.expr(HOLE.fullmatch(a["list"].strip()).group(1), scope)
            var = a.get("as", "item")
            sc = scope | {var, var + "_i"}
            first = next((c for c in n["children"] if c["tag"] not in ("#text",) and not c["tag"].startswith(("sc-", "dc-"))), None)
            if first is not None:
                first["_loop"] = var + "_i"
            kids = self.children(n, sc, ind + 2, is_svg)
            return (f"{pad}{{({lst} || []).map(({var}: any, {var}_i: number) => (\n"
                    f"{pad}  <Fragment key={{{var}_i}}>\n" + "\n".join(kids) + f"\n{pad}  </Fragment>\n{pad}))}}")
        if tag == "sc-if":
            a = dict(n["attrs"])
            cond = self.expr(HOLE.fullmatch(a["value"].strip()).group(1), scope)
            kids = self.children(n, scope, ind + 2, is_svg)
            return f"{pad}{{{cond} ? (\n{pad}  <>\n" + "\n".join(kids) + f"\n{pad}  </>\n{pad}) : null}}"
        if tag == "dc-import":
            a = [(k, v) for k, v in n["attrs"] if not k.startswith("hint-")]
            name = dict(a)["name"]
            self.used_components.add(name)
            props = []
            for k, val in a:
                if k == "name":
                    continue
                props.append(f"{k}={self.str_or_tpl(val or '', scope)}")
            if name == "BottomNav":
                pass
            return f"{pad}<{name} {' '.join(props)} />"
        svg = is_svg or tag.lower() == "svg"
        jtag = SVG_CASE.get(tag.lower(), tag) if svg else tag
        attrs = self.attrs_jsx(n, scope, svg)
        a = (" " + " ".join(attrs)) if attrs else ""
        if tag.lower() in VOID or tag == "textarea" or (not n["children"]):
            return f"{pad}<{jtag}{a} />"
        kids = self.children(n, scope, ind + 1, svg)
        if not kids:
            return f"{pad}<{jtag}{a} />"
        wc = self.wrap_class(n)
        if wc:
            inner_tag = "g" if svg else "div"
            kids = [f'{pad}  <{inner_tag} className="{wc}">'] + kids + [f"{pad}  </{inner_tag}>"]
        return f"{pad}<{jtag}{a}>\n" + "\n".join(kids) + f"\n{pad}</{jtag}>"


def convert(path, name, navmap, fx=None):
    src = open(path, encoding="utf-8").read()
    m = re.search(r"<x-dc>(.*)</x-dc>", src, re.S)
    markup = m.group(1)
    tree = parse(markup)
    conv = Conv(navmap, name, fx)
    roots = [c for c in tree["children"] if not (c["tag"] == "#text" and not c["text"].strip()) and c["tag"] != "helmet"]
    body = "\n".join(filter(None, (conv.node(c, set(), 3) for c in roots)))
    if len(roots) > 1:
        body = "      <>\n" + body + "\n      </>"

    sm = re.search(r"<script type=\"text/x-dc\"[^>]*data-props='([^']*)'[^>]*>(.*?)</script>", src, re.S)
    props_def = json.loads(sm.group(1))
    logic = sm.group(2)
    rm = re.search(r"renderVals\s*\(\s*\)\s*\{(.*)\}\s*\}\s*$", logic.strip(), re.S)
    fn_body = rm.group(1)
    fn_body = fn_body.replace("this.props", "props").replace("this.setState", "setState").replace("this.state", "state")

    defaults = {k: v.get("default") for k, v in props_def.items() if not k.startswith("$")}
    prop_names = list(defaults.keys())
    prop_type = "; ".join(f"{k}?: string" for k in prop_names)

    imports = sorted(conv.used_components)
    lines = []
    lines.append("// Generated from handoff/" + path.split("handoff/")[-1] + " — layout matches the design canvas 1:1.")
    lines.append("/* eslint-disable */")
    lines.append("import { Fragment } from 'react';")
    lines.append("import { useDC, useGo } from '../lib/dc';")
    for c in imports:
        lines.append(f"import {c} from '../components/{c}';")
    lines.append("")
    lines.append(f"export type {name}Props = {{ {prop_type} }};")
    lines.append("")
    lines.append("// eslint-disable-next-line @typescript-eslint/no-unused-vars")
    lines.append(f"function renderVals(props: {name}Props, state: any, setState: (patch: any) => void): any {{")
    lines.append(fn_body.rstrip())
    lines.append("}")
    lines.append("")
    lines.append(f"export default function {name}(props: {name}Props) {{")
    lines.append("  const go = useGo();")
    lines.append("  const v = useDC(renderVals, props);")
    lines.append("  void go; void v;")
    lines.append("  return (")
    lines.append(body)
    lines.append("  );")
    lines.append("}")
    return "\n".join(lines) + "\n", conv.unmatched


if __name__ == "__main__":
    nm = json.load(open(sys.argv[3], encoding="utf-8")) if len(sys.argv) > 3 else {}
    fx = json.load(open(sys.argv[4], encoding="utf-8")) if len(sys.argv) > 4 and os.path.exists(sys.argv[4]) else []
    out, unmatched = convert(sys.argv[1], sys.argv[2], nm, fx)
    sys.stdout.write(out)
    for u in unmatched:
        sys.stderr.write("UNMATCHED: " + u + "\n")
