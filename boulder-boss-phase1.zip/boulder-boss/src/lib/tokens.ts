/** Design tokens — "Chalk & Sticker" (HANDOFF.md). Mirrored as CSS variables in styles.css. */
export const color = {
  ink: '#1B1B3A',
  ink2: '#55557A',
  paper: '#FFF7EC',
  yellow: '#FFC93C',
  coral: '#FF5F45',
  teal: '#17B2A0',
  sky: '#5AB8FF',
  grape: '#6C4CF1',
  danger: '#E5383B',
  line: '#E9DFCF',
} as const;

export const radius = { badge: 10, button: 16, card: 20, sheet: 28, chip: 999 } as const;
export const space = [4, 8, 12, 16, 20, 24, 32] as const;
export const border = `2.5px solid ${color.ink}`;
export const shadow = `0 4px 0 ${color.ink}`;

export const type = {
  display: { fontSize: 40, fontWeight: 700 },
  h1: { fontSize: 28, fontWeight: 700 },
  h2: { fontSize: 22, fontWeight: 700 },
  h3: { fontSize: 18, fontWeight: 600 },
  body: { fontSize: 16, fontWeight: 500 },
  caption: { fontSize: 13, fontWeight: 500 },
} as const;

/** Grade badge colours V0–V12. */
export function gradeColors(v: number): { bg: string; fg: string } {
  if (v <= 1) return { bg: '#3DDC84', fg: color.ink };
  if (v <= 3) return { bg: '#5AB8FF', fg: color.ink };
  if (v <= 5) return { bg: '#FFC93C', fg: color.ink };
  if (v <= 7) return { bg: '#FF8A3D', fg: color.ink };
  if (v <= 9) return { bg: '#C81D25', fg: '#FFFFFF' };
  if (v <= 11) return { bg: '#6C4CF1', fg: '#FFFFFF' };
  return { bg: color.ink, fg: color.yellow };
}

/** Stage size of every screen (mobile portrait). */
export const STAGE = { w: 390, h: 844 } as const;
