import { useCallback, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * Runs a screen's renderVals(props, state, setState) — the view-model logic ported
 * from the design canvas (DCLogic). setState shallow-merges like the original.
 */
export function useDC<P>(renderVals: (props: P, state: any, setState: (patch: any) => void) => any, props: P) {
  const [state, setRaw] = useState<Record<string, any>>({});
  const setState = useCallback((patch: any) => setRaw((s) => ({ ...s, ...patch })), []);
  return renderVals(props, state, setState) ?? {};
}

export function toast(message: string) {
  window.dispatchEvent(new CustomEvent('bb-toast', { detail: message }));
}

/**
 * Navigation helper used by every screen.
 *  '/path' → navigate · 'back' → history back (falls back to /map)
 *  'soon'  → toast for features outside Phase 1 · 'jump' → dyno outcome (mock)
 */
export function useGo() {
  const navigate = useNavigate();
  return useMemo(
    () => (target: string) => {
      if (target === 'back') {
        if (window.history.state && window.history.state.idx > 0) navigate(-1);
        else navigate('/map');
      } else if (target === 'soon') {
        toast('เร็วๆ นี้ — ฟีเจอร์นี้มาในเฟสถัดไป');
      } else if (target === 'jump') {
        navigate(dynoOutcome(), { replace: true });
      } else {
        navigate(target);
      }
    },
    [navigate],
  );
}

/**
 * Dyno timing (mock): read where the animated needle is inside the timing bar.
 * PERFECT zone 54–66% → Flash, GOOD 38–82% → Send, otherwise Fall.
 */
function dynoOutcome(): string {
  const needle = document.querySelector('.bb-needle') as HTMLElement | null;
  const bar = needle?.parentElement;
  if (!needle || !bar) return Math.random() < 0.7 ? '/result/send' : '/fall';
  const n = needle.getBoundingClientRect();
  const b = bar.getBoundingClientRect();
  const pct = ((n.left + n.width / 2 - b.left) / b.width) * 100;
  if (pct >= 54 && pct <= 66) return '/result/flash';
  if (pct >= 38 && pct <= 82) return '/result/send';
  return '/fall';
}
