// Generated from handoff/screens/C20-Result.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type C20ResultProps = { result?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: C20ResultProps, state: any, setState: (patch: any) => void): any {

const r = props.result ?? 'send';
const R = {
flash: { bg: '#FFC93C', ray: '#FFDB70', title: 'FLASH!', titleColor: '#FFFFFF', sub: 'ขึ้นถึง TOP ในครั้งแรก', coins: 180, xp: 120, hp: '100%', s1: 3, s2: 2, pose: 'cheer', cta: 'รูทถัดไป' },
send: { bg: '#17B2A0', ray: '#3CC7B6', title: 'SEND!', titleColor: '#FFC93C', sub: 'พิชิตได้ในครั้งที่ 4', coins: 120, xp: 80, hp: '100%', s1: 2, s2: 1, pose: 'cheer', cta: 'รูทถัดไป' },
speed: { bg: '#6C4CF1', ray: '#7D61F3', title: '0:23.96', titleColor: '#FFC93C', sub: 'Speed Run · สถิติใหม่ของคุณ −0.35 วิ · อันดับ #11', coins: 40, xp: 30, hp: '#11', s1: 0, s2: 1, pose: 'cheer', cta: 'แข่งอีกรอบ' },
project: { bg: '#5AB8FF', ray: '#7CC8FF', title: 'PROJECT', titleColor: '#FFFFFF', sub: 'บันทึกไว้ ลองใหม่ได้ทุกเมื่อ', coins: 20, xp: 30, hp: '74%', s1: 1, s2: 0, pose: 'wave', cta: 'ลองอีกครั้ง' }
}[r];
return R;
}

export default function C20Result(props: C20ResultProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: v.bg }}>
        <svg width="390" height="440" viewBox="0 0 390 440" style={{ position: "absolute", left: "0", top: "0" }} aria-hidden="true">
          <g fill={v.ray} transform="translate(195 230)">
            <g className="bb-spin">
            <path d="M0 0L-30 -300H30z" />
            <path d="M0 0L-30 -300H30z" transform="rotate(30)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(60)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(90)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(120)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(150)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(180)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(210)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(240)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(270)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(300)" />
            <path d="M0 0L-30 -300H30z" transform="rotate(330)" />
            </g>
          </g>
          <g className="bb-confetti" stroke="#1B1B3A" strokeWidth="2">
            <rect x="50" y="90" width="12" height="12" fill="#FF5F45" transform="rotate(20 56 96)" />
            <rect x="320" y="120" width="10" height="10" fill="#5AB8FF" transform="rotate(-15 325 125)" />
            <circle cx="300" cy="300" r="6" fill="#FFFFFF" />
            <circle cx="80" cy="280" r="5" fill="#6C4CF1" />
            <rect x="250" y="70" width="9" height="9" fill="#3DDC84" />
          </g>
        </svg>
        <div style={{ position: "absolute", left: "0", right: "0", top: "64px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
          <span style={{ fontSize: "15px", fontWeight: "700", color: "#1B1B3A", background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "8px", padding: "2px 10px" }}>
            {"ข้าวเหนียวมะม่วง · V4"}
          </span>
          <span className="bb-stamp" style={{ fontSize: "68px", fontWeight: "700", lineHeight: "1.1", color: v.titleColor, WebkitTextStroke: "3px #1B1B3A", textShadow: "0 6px 0 #1B1B3A", letterSpacing: "2px" }}>
            {v.title}
          </span>
          <span className="bb-rise" style={{ fontSize: "16px", fontWeight: "700", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "8px", padding: "0 8px" }}>
            {v.sub}
          </span>
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "236px", display: "flex", justifyContent: "center" }}>
          <Chibi pose={v.pose} w="140" band="#FFC93C" />
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "20px 20px 34px", display: "flex", flexDirection: "column", gap: "14px" }}>
          <div className="bb-stagger" style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px 6px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"+"}{v.coins}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"เหรียญ"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px 6px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"+"}{v.xp}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"XP"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px 6px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {v.hp}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"high point"}
              </div>
            </div>
          </div>
          <div className="bb-stagger" style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
            <span style={{ height: "32px", padding: "0 10px", borderRadius: "10px", background: "#E3F7F4", border: "2px solid #1B1B3A", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"แรงนิ้ว +"}{v.s1}
            </span>
            <span style={{ height: "32px", padding: "0 10px", borderRadius: "10px", background: "#E3F7F4", border: "2px solid #1B1B3A", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"Technique +"}{v.s2}
            </span>
            <span style={{ height: "32px", padding: "0 10px", borderRadius: "10px", background: "#E3F7F4", border: "2px solid #1B1B3A", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"Stamina +1"}
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: "14px", fontWeight: "700" }}>
              {"ให้ดาวรูทนี้"}
            </span>
            <div className="bb-stagger" style={{ display: "flex", gap: "2px" }}>
              <button type="button" aria-label="1 ดาว" style={{ width: "44px", height: "44px", border: "none", background: "none", padding: "0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </button>
              <button type="button" aria-label="2 ดาว" style={{ width: "44px", height: "44px", border: "none", background: "none", padding: "0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </button>
              <button type="button" aria-label="3 ดาว" style={{ width: "44px", height: "44px", border: "none", background: "none", padding: "0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </button>
              <button type="button" aria-label="4 ดาว" style={{ width: "44px", height: "44px", border: "none", background: "none", padding: "0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </button>
              <button type="button" aria-label="5 ดาว" style={{ width: "44px", height: "44px", border: "none", background: "none", padding: "0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z" fill="#FFFFFF" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "10px" }}>
            <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }} onClick={() => go("soon")}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 3v12 M7 8l5-5 5 5 M5 14v6h14v-6" />
              </svg>
              {"แชร์ replay"}
            </button>
            <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go(v.cta === "ลองอีกครั้ง" ? "/climb" : v.cta === "แข่งอีกรอบ" ? "soon" : "/routes")}>
              {v.cta}
            </button>
          </div>
        </div>
      </div>
  );
}
