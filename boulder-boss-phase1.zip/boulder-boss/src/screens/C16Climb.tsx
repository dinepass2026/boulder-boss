// Generated from handoff/screens/C16-Climb.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Wall from '../components/Wall';

export type C16ClimbProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: C16ClimbProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function C16Climb(props: C16ClimbProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#1B1B3A" }}>
        <div style={{ position: "absolute", left: "0", top: "104px" }}>
          <Wall climbable onTop={() => go("/move/dyno")} mode="climb" climberTop="322" />
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "104px", boxSizing: "border-box", padding: "48px 16px 0", background: "#1B1B3A", display: "flex", alignItems: "center", gap: "10px" }}>
          <button type="button" aria-label="หยุดเกม" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #FFC93C", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("/pause")}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="3" strokeLinecap="round" aria-hidden="true">
              <path d="M8 5v14 M16 5v14" />
            </svg>
          </button>
          <div style={{ flex: "1", minWidth: "0", color: "#FFFFFF" }}>
            <div style={{ fontSize: "16px", fontWeight: "700", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {"ข้าวเหนียวมะม่วง"}
            </div>
            <div style={{ fontSize: "12px", color: "#D8D6EA" }}>
              {"ครั้งที่ 4 · high point เดิม 70%"}
            </div>
          </div>
          <span style={{ minWidth: "44px", height: "32px", borderRadius: "10px", border: "2.5px solid #FFFFFF", background: "#FFC93C", fontWeight: "700", fontSize: "15px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"V4"}
          </span>
        </div>
        <div style={{ position: "absolute", right: "10px", top: "124px", width: "40px", height: "440px", display: "flex", flexDirection: "column", alignItems: "center", gap: "6px" }}>
          <span style={{ fontSize: "11px", fontWeight: "700", color: "#1B1B3A", background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "6px", padding: "0 4px" }}>
            {"TOP"}
          </span>
          <div style={{ position: "relative", flex: "1", width: "14px", borderRadius: "999px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", overflow: "hidden" }}>
            <div style={{ position: "absolute", left: "0", right: "0", bottom: "0", height: "52%", background: "#17B2A0" }} />
            <div style={{ position: "absolute", left: "-2px", right: "-2px", bottom: "70%", height: "3px", background: "#FF5F45" }} />
          </div>
          <span style={{ fontSize: "12px", fontWeight: "700", color: "#1B1B3A", background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "6px", padding: "0 4px" }}>
            {"5.2ม."}
          </span>
        </div>
        <div style={{ position: "absolute", left: "14px", top: "380px", height: "30px", padding: "0 10px", borderRadius: "10px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", gap: "6px" }}>
          <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#FF5F45", border: "1.5px solid #1B1B3A" }} />
          {"ถัดไป: Pinch · แตะค้างเพื่อบีบ"}
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", height: "128px", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "24px 24px 0 0", padding: "16px 16px 30px", display: "flex", gap: "12px", alignItems: "center" }}>
          <div style={{ flex: "1", display: "flex", flexDirection: "column", gap: "10px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#17B2A0" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
                <path d="M13 2L4 14h7l-1 8 9-12h-7z" />
              </svg>
              <span style={{ width: "58px", fontSize: "13px", fontWeight: "700" }}>
                {"Stamina"}
              </span>
              <div style={{ flex: "1", height: "18px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
                <div className="bb-fill" style={{ width: "64%", height: "100%", background: "#17B2A0" }} />
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#FF5F45" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 14c-1-4 2-8 6-9 4-1 8 1 8 5s-2 8-6 9-7-1-8-5z" />
              </svg>
              <span style={{ width: "58px", fontSize: "13px", fontWeight: "700" }}>
                {"Grip"}
              </span>
              <div style={{ flex: "1", height: "18px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
                <div className="bb-fill" style={{ width: "31%", height: "100%", background: "#FF5F45" }} />
              </div>
            </div>
          </div>
          <button type="button" aria-label="ลงชอล์ก ฟื้น Grip (เหลือ 2 ครั้ง)" style={{ position: "relative", width: "72px", height: "72px", flexShrink: "0", borderRadius: "50%", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "0", padding: "0", fontFamily: "inherit" }}>
            <svg width="30" height="30" viewBox="0 0 24 24" aria-hidden="true">
              <rect x="5" y="7" width="14" height="13" rx="4" fill="#17B2A0" stroke="#1B1B3A" strokeWidth="2" />
              <path d="M6 11h12" stroke="#FFFFFF" strokeWidth="2.4" strokeLinecap="round" />
              <circle cx="9" cy="4" r="1.4" fill="#B9B2C8" />
              <circle cx="13" cy="3" r="1.2" fill="#B9B2C8" />
              <circle cx="16" cy="5" r="1" fill="#B9B2C8" />
            </svg>
            <span style={{ fontSize: "11px", fontWeight: "700", color: "#1B1B3A" }}>
              {"ชอล์ก"}
            </span>
            <span style={{ position: "absolute", top: "-6px", right: "-4px", width: "24px", height: "24px", borderRadius: "50%", background: "#FFC93C", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"2"}
            </span>
          </button>
        </div>
      </div>
  );
}
