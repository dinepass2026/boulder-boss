// Generated from handoff/screens/D23-Logbook.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type D23LogbookProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D23LogbookProps, state: any, setState: (patch: any) => void): any {

const G = (g) => g <= 1 ? ['#3DDC84', '#1B1B3A'] : g <= 3 ? ['#5AB8FF', '#1B1B3A'] : g <= 5 ? ['#FFC93C', '#1B1B3A'] : ['#FF8A3D', '#1B1B3A'];
const R = { FLASH: ['#FFC93C', 'solid'], SEND: ['#17B2A0', 'solid'], PROJECT: ['#FFFFFF', 'dashed'] };
const mk = (g, name, r, tries) => ({ g, name, r, tries, gbg: G(g)[0], gfg: G(g)[1], rbg: R[r][0], bs: R[r][1] });
const days = [
{ date: 'วันนี้ · 20 พ.ย.', gym: 'Crimp Factory ทองหล่อ', items: [mk(4, 'ข้าวเหนียวมะม่วง', 'PROJECT', '4 ครั้ง'), mk(3, 'แตงโมหล่น', 'SEND', '2 ครั้ง'), mk(2, 'บันไดสวรรค์', 'FLASH', '1 ครั้ง')] },
{ date: 'อังคาร · 18 พ.ย.', gym: 'Slab Lab เอกมัย', items: [mk(3, 'ใบตองแห้ง', 'SEND', '3 ครั้ง'), mk(1, 'ชาไทยไม่หวาน', 'FLASH', '1 ครั้ง')] },
{ date: 'อาทิตย์ · 16 พ.ย.', gym: 'Crimp Factory ทองหล่อ', items: [mk(3, 'น้ำท่วมซอย', 'SEND', '5 ครั้ง')] }
];
const pattern = [1, 0, 2, 0, 0, 1, 3, 0, 1, 0, 2, 2, 0, 0, 1, 0, 3, 1, 0, 3];
const C = ['#3A3A60', '#5AB8FF', '#17B2A0', '#FFC93C'];
return { days, heat: pattern.map((v) => ({ c: C[v] })) };
}

export default function D23Logbook(props: D23LogbookProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"ประวัติการปีน"}
          </h1>
        </div>
        <div style={{ margin: "14px 20px 0", padding: "4px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "4px" }}>
          <button type="button" style={{ height: "40px", borderRadius: "11px", border: "none", background: "#1B1B3A", color: "#FFFFFF", fontFamily: "inherit", fontSize: "14px", fontWeight: "700" }}>
            {"ตามวัน"}
          </button>
          <button type="button" style={{ height: "40px", borderRadius: "11px", border: "none", background: "transparent", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "700" }}>
            {"ตามยิม"}
          </button>
        </div>
        <div style={{ margin: "12px 20px 0", background: "#1B1B3A", color: "#FFFFFF", borderRadius: "20px", padding: "14px", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "14px", fontWeight: "700" }}>
            <span>
              {"พฤศจิกายน 2026"}
            </span>
            <span style={{ color: "#FFC93C" }}>
              {"12 วันที่ปีน"}
            </span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(10, minmax(0, 1fr))", gap: "4px" }}>
            {(v.heat || []).map((d: any, d_i: number) => (
              <Fragment key={d_i}>
                <span className="bb-in" style={{ height: "18px", borderRadius: "4px", background: d.c, animationDelay: `${Math.min(d_i, 12) * 45}ms` }} />
              </Fragment>
            ))}
          </div>
          <div style={{ display: "flex", gap: "14px", fontSize: "12px", color: "#D8D6EA" }}>
            <span>
              <b style={{ color: "#FFFFFF" }}>
                {"31"}
              </b>
              {" Send"}
            </span>
            <span>
              <b style={{ color: "#FFFFFF" }}>
                {"7"}
              </b>
              {" Flash"}
            </span>
            <span>
              <b style={{ color: "#FFFFFF" }}>
                {"58"}
              </b>
              {" ครั้งที่ลอง"}
            </span>
          </div>
        </div>
        <div style={{ flex: "1", minHeight: "0", padding: "14px 20px 30px", display: "flex", flexDirection: "column", gap: "10px", overflow: "hidden" }}>
          {(v.days || []).map((day: any, day_i: number) => (
            <Fragment key={day_i}>
              <div className="bb-in" style={{ display: "flex", flexDirection: "column", gap: "8px", flexShrink: "0", animationDelay: `${Math.min(day_i, 12) * 45}ms` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <b style={{ fontSize: "15px" }}>
                    {day.date}
                  </b>
                  <span style={{ fontSize: "12px", color: "#55557A" }}>
                    {day.gym}
                  </span>
                </div>
                <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", overflow: "hidden" }}>
                  {(day.items || []).map((it: any, it_i: number) => (
                    <Fragment key={it_i}>
                      <div className="bb-in" style={{ minHeight: "52px", padding: "0 12px", display: "flex", alignItems: "center", gap: "10px", borderBottom: "2px solid #F1E9DC", animationDelay: `${Math.min(it_i, 12) * 45}ms` }}>
                        <span style={{ minWidth: "38px", height: "28px", borderRadius: "8px", border: "2px solid #1B1B3A", background: it.gbg, color: it.gfg, fontWeight: "700", fontSize: "13px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          {"V"}{it.g}
                        </span>
                        <span style={{ flex: "1", fontSize: "15px", fontWeight: "600" }}>
                          {it.name}
                        </span>
                        <span style={{ fontSize: "12px", color: "#55557A" }}>
                          {it.tries}
                        </span>
                        <span style={{ minWidth: "62px", height: "24px", padding: "0 6px", boxSizing: "border-box", borderRadius: "7px", border: `2px ${it.bs} #1B1B3A`, background: it.rbg, fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                          {it.r}
                        </span>
                      </div>
                    </Fragment>
                  ))}
                </div>
              </div>
            </Fragment>
          ))}
        </div>
      </div>
  );
}
