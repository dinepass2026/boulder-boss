// Generated from handoff/screens/B15-RouteDetail.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Wall from '../components/Wall';

export type B15RouteDetailProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B15RouteDetailProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function B15RouteDetail(props: B15RouteDetailProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "400px", background: "#5A4A82", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: "80px", top: "34px", width: "390px", height: "620px", transform: "scale(0.59)", transformOrigin: "top left", border: "4px solid #1B1B3A", borderRadius: "20px", overflow: "hidden" }}>
            <Wall mode="preview" />
          </div>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "52px", display: "flex", justifyContent: "space-between" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <button type="button" aria-label="แชร์รูท" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("soon")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M12 3v12 M7 8l5-5 5 5 M5 14v6h14v-6" />
            </svg>
          </button>
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", top: "376px", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "20px 20px 34px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: "12px" }}>
            <div style={{ flex: "1" }}>
              <div style={{ display: "flex", gap: "6px", marginBottom: "4px" }}>
                <span style={{ height: "22px", padding: "0 7px", borderRadius: "6px", background: "#FF5F45", border: "1.5px solid #1B1B3A", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center" }}>
                  {"NEW"}
                </span>
                <span style={{ height: "22px", padding: "0 7px", borderRadius: "6px", background: "#FFFFFF", border: "1.5px dashed #1B1B3A", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center" }}>
                  {"PROJECT"}
                </span>
              </div>
              <h1 style={{ margin: "0", fontSize: "26px", lineHeight: "1.2" }}>
                {"ข้าวเหนียวมะม่วง"}
              </h1>
              <div style={{ fontSize: "13px", color: "#55557A", marginTop: "2px" }}>
                {"Crimp · ผนัง A · ผู้ตั้งรูท "}
                <b style={{ color: "#1B1B3A" }}>
                  {"พี่หมี"}
                </b>
                {" · ★ "}
                <b style={{ color: "#1B1B3A" }}>
                  {"4.6"}
                </b>
                {" (312)"}
              </div>
            </div>
            <span style={{ width: "64px", height: "56px", borderRadius: "16px", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", background: "#FFC93C", fontWeight: "700", fontSize: "26px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V4"}
            </span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"18%"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"Flash"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"42%"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"Send"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"3"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"ครั้งที่ลอง"}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "13px", fontWeight: "600" }}>
              <span>
                {"High point ของคุณ"}
              </span>
              <span>
                {"70% · hold ที่ 7/10"}
              </span>
            </div>
            <div style={{ height: "16px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
              <div className="bb-fill" style={{ width: "70%", height: "100%", background: "#FF5F45" }} />
            </div>
          </div>
          <a href="B15c-SpeedBoard.dc.html" style={{ minHeight: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", gap: "10px", padding: "0 12px", textDecoration: "none", color: "#1B1B3A" }} onClick={() => go("soon")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M12 21a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M12 9v4l2.5 2 M10 2h4 M12 2v3" />
            </svg>
            <span style={{ flex: "1", fontSize: "13px" }}>
              <b>
                {"เร็วสุด 0:31.20"}
              </b>
              {" · ปีนแหลก99"}
            </span>
            <span style={{ height: "24px", padding: "0 7px", borderRadius: "7px", background: "#EDE6DA", fontSize: "11px", fontWeight: "700", color: "#55557A", display: "flex", alignItems: "center" }}>
              {"Speed Run ปลดล็อกหลัง Send"}
            </span>
          </a>
          <div style={{ flex: "1" }} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }} onClick={() => go("/beta")}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M7 4l13 8-13 8z" />
              </svg>
              {"ดู beta (12)"}
            </button>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }} onClick={() => go("soon")}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M2 21c0-4 3-6 7-6s7 2 7 6 M19 8v6 M16 11h6" />
              </svg>
              {"ชวนเพื่อน"}
            </button>
          </div>
          <button type="button" style={{ height: "60px", borderRadius: "18px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 5px 0 #1B1B3A", fontFamily: "inherit", fontSize: "20px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/climb")}>
            {"เริ่มปีน"}
          </button>
        </div>
      </div>
  );
}
