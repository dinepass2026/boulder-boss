// Generated from handoff/screens/A07-PlayerInfo.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type A07PlayerInfoProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A07PlayerInfoProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A07PlayerInfo(props: A07PlayerInfoProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <div style={{ flex: "1", display: "flex", flexDirection: "column", gap: "6px" }}>
            <span style={{ fontSize: "13px", fontWeight: "600", color: "#55557A" }}>
              {"ขั้นที่ 1 จาก 2"}
            </span>
            <div style={{ height: "10px", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
              <div className="bb-fill" style={{ width: "50%", height: "100%", background: "#FFC93C" }} />
            </div>
          </div>
        </div>
        <div style={{ padding: "18px 24px 0" }}>
          <h1 style={{ margin: "0", fontSize: "26px" }}>
            {"แนะนำตัวหน่อย"}
          </h1>
        </div>
        <form style={{ padding: "16px 24px 0", display: "flex", flexDirection: "column", gap: "16px" }}>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"ชื่อในเกม\n"}
            <span style={{ position: "relative", display: "flex" }}>
              <input type="text" defaultValue="น้องชอล์ก" style={{ flex: "1", height: "52px", boxSizing: "border-box", border: "2.5px solid #17B2A0", borderRadius: "14px", background: "#FFFFFF", padding: "0 48px 0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
              <span style={{ position: "absolute", right: "12px", top: "13px", width: "26px", height: "26px", borderRadius: "50%", background: "#17B2A0", border: "2px solid #1B1B3A", boxSizing: "border-box", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 12l5 5 9-10" />
                </svg>
              </span>
            </span>
            <span style={{ fontSize: "12px", fontWeight: "600", color: "#0B6B60" }}>
              {"ชื่อนี้ว่าง ใช้ได้เลย · 3–16 ตัวอักษร"}
            </span>
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"วันเกิด\n"}
            <input type="date" defaultValue="2001-08-14" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
            <span style={{ fontSize: "12px", fontWeight: "500", color: "#55557A" }}>
              {"ไม่แสดงต่อสาธารณะ"}
            </span>
          </label>
          <fieldset style={{ border: "none", margin: "0", padding: "0", display: "flex", flexDirection: "column", gap: "8px" }}>
            <legend style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px" }}>
              {"เคยปีนผาจริงไหม?"}
            </legend>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
              <label style={{ minHeight: "84px", borderRadius: "16px", border: "2px solid #1B1B3A", background: "#FFFFFF", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "4px", fontSize: "14px", fontWeight: "600", textAlign: "center" }}>
                <input type="radio" name="exp" style={{ position: "absolute", opacity: "0", width: "1px", height: "1px" }} />
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M12 3v4 M12 17v4 M5 12H3 M21 12h-2 M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
                </svg>
                {"ไม่เคย"}
              </label>
              <label style={{ minHeight: "84px", borderRadius: "16px", border: "2.5px solid #1B1B3A", background: "#FFC93C", boxShadow: "0 3px 0 #1B1B3A", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "4px", fontSize: "14px", fontWeight: "700", textAlign: "center" }}>
                <input type="radio" name="exp" defaultChecked style={{ position: "absolute", opacity: "0", width: "1px", height: "1px" }} />
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M5 14c-1-4 2-8 6-9 4-1 8 1 8 5s-2 8-6 9-7-1-8-5z" />
                </svg>
                {"เคยบ้าง"}
              </label>
              <label style={{ minHeight: "84px", borderRadius: "16px", border: "2px solid #1B1B3A", background: "#FFFFFF", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "4px", fontSize: "14px", fontWeight: "600", textAlign: "center" }}>
                <input type="radio" name="exp" style={{ position: "absolute", opacity: "0", width: "1px", height: "1px" }} />
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M12 22c4 0 7-3 7-7 0-5-5-7-5-12-3 2-5 5-5 8-1-1-2-2-2-4-2 2-2 5-2 8 0 4 3 7 7 7z" />
                </svg>
                {"ปีนประจำ"}
              </label>
            </div>
          </fieldset>
          <fieldset style={{ border: "none", margin: "0", padding: "0" }}>
            <legend style={{ fontSize: "14px", fontWeight: "600", marginBottom: "8px" }}>
              {"เลือกโซนเริ่มต้นในกรุงเทพ"}
            </legend>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
              <button type="button" style={{ height: "44px", padding: "0 16px", borderRadius: "999px", background: "#1B1B3A", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#FFFFFF" }}>
                {"สุขุมวิท"}
              </button>
              <button type="button" style={{ height: "44px", padding: "0 16px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A" }}>
                {"สยาม"}
              </button>
              <button type="button" style={{ height: "44px", padding: "0 16px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A" }}>
                {"อารีย์"}
              </button>
              <button type="button" style={{ height: "44px", padding: "0 16px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A" }}>
                {"ริมเจ้าพระยา"}
              </button>
            </div>
          </fieldset>
        </form>
        <div style={{ flex: "1" }} />
        <div style={{ padding: "0 24px 34px" }}>
          <button type="button" style={{ width: "100%", height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/avatar")}>
            {"ถัดไป: สร้างตัวละคร"}
          </button>
        </div>
      </div>
  );
}
