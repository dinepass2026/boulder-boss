// Generated from handoff/screens/C17-MoveMinigame.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Wall from '../components/Wall';

export type C17MoveMinigameProps = { move?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: C17MoveMinigameProps, state: any, setState: (patch: any) => void): any {

const m = props.move ?? 'dyno';
return { isDyno: m === 'dyno', isHeel: m === 'heelhook', title: m === 'dyno' ? 'DYNO!' : 'HEEL HOOK' };
}

export default function C17MoveMinigame(props: C17MoveMinigameProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#1B1B3A" }}>
        <div style={{ position: "absolute", left: "0", top: "104px" }}>
          <Wall mode="plain" />
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "104px", height: "620px", background: "rgba(27,27,58,0.55)" }} />
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "104px", boxSizing: "border-box", padding: "48px 16px 0", background: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }}>
          <span style={{ height: "40px", padding: "0 16px", borderRadius: "12px", background: "#6C4CF1", border: "2.5px solid #FFFFFF", color: "#FFFFFF", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", letterSpacing: "1px" }}>
            {v.title}
          </span>
        </div>
        {v.isDyno ? (
          <>
            <svg width="390" height="620" viewBox="0 0 390 620" style={{ position: "absolute", left: "0", top: "104px" }} aria-hidden="true">
              <path d="M190 430Q120 250 230 120" fill="none" stroke="#FFC93C" strokeWidth="5" strokeDasharray="10 10" strokeLinecap="round" />
              <circle className="bb-ring-svg" cx="236" cy="112" r="34" fill="none" stroke="#FFC93C" strokeWidth="4" />
              <path d="M216 116c0-12 8-20 20-20s18 6 16 16-8 14-18 14-18-2-18-10z" fill="#FF5F45" stroke="#1B1B3A" strokeWidth="3" />
            </svg>
            <div className="bb-crouch" style={{ position: "absolute", left: "136px", top: "470px" }}>
              <Chibi pose="cheer" w="110" band="#FFC93C" />
            </div>
            <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "24px 24px 0 0", padding: "18px 20px 34px", display: "flex", flexDirection: "column", gap: "12px" }}>
              <div style={{ fontSize: "16px", fontWeight: "700", textAlign: "center" }}>
                {"แตะตอนเข็มอยู่ในโซน "}
                <span style={{ background: "#3DDC84", border: "2px solid #1B1B3A", borderRadius: "6px", padding: "0 6px" }}>
                  {"PERFECT"}
                </span>
              </div>
              <div style={{ position: "relative", height: "34px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden", display: "flex" }}>
                <div style={{ flex: "38", background: "#FFE3E0" }} />
                <div style={{ flex: "16", background: "#FFE9A8" }} />
                <div style={{ flex: "12", background: "#3DDC84", borderLeft: "2px solid #1B1B3A", borderRight: "2px solid #1B1B3A" }} />
                <div style={{ flex: "16", background: "#FFE9A8" }} />
                <div style={{ flex: "18", background: "#FFE3E0" }} />
                <div className="bb-needle" style={{ position: "absolute", left: "58%", top: "-4px", width: "6px", height: "42px", background: "#1B1B3A", borderRadius: "3px" }} />
              </div>
              <button type="button" style={{ height: "72px", borderRadius: "22px", background: "#FFC93C", border: "3px solid #1B1B3A", boxShadow: "0 6px 0 #1B1B3A", fontFamily: "inherit", fontSize: "24px", fontWeight: "700", color: "#1B1B3A", letterSpacing: "1px" }} onClick={() => go("jump")}>
                {"กระโดด!"}
              </button>
            </div>
          </>
        ) : null}
        {v.isHeel ? (
          <>
            <svg width="390" height="620" viewBox="0 0 390 620" style={{ position: "absolute", left: "0", top: "104px" }} aria-hidden="true">
              <path d="M150 470C220 470 290 420 300 330" fill="none" stroke="#FFFFFF" strokeWidth="26" strokeLinecap="round" opacity="0.25" />
              <path d="M150 470C220 470 290 420 300 330" fill="none" stroke="#FFFFFF" strokeWidth="6" strokeDasharray="2 14" strokeLinecap="round" />
              <path d="M150 470C200 472 240 456 262 430" fill="none" stroke="#FFC93C" strokeWidth="10" strokeLinecap="round" />
              <circle className="bb-ring-svg" cx="300" cy="320" r="30" fill="none" stroke="#FFC93C" strokeWidth="4" />
              <path d="M282 330c0-16 10-28 22-28s14 12 12 24-8 14-18 14-16-2-16-10z" fill="#5AB8FF" stroke="#1B1B3A" strokeWidth="3" />
              <circle cx="150" cy="470" r="14" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="3" />
            </svg>
            <div className="bb-drag" style={{ position: "absolute", left: "250px", top: "520px" }}>
              <svg width="56" height="64" viewBox="0 0 56 64" aria-hidden="true">
                <path d="M20 6c0-3 2-5 5-5s5 2 5 5v22l10 2c5 1 8 5 7 10l-3 14c-1 6-6 10-12 10H22c-4 0-7-2-9-5L4 38c-2-3-1-6 2-7 2-1 5 0 7 2l7 7z" fill="#FFFFFF" stroke="#1B1B3A" strokeWidth="3" strokeLinejoin="round" />
              </svg>
            </div>
            <div style={{ position: "absolute", left: "90px", top: "330px" }}>
              <Chibi pose="climb" w="110" band="#FFC93C" />
            </div>
            <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "24px 24px 0 0", padding: "18px 20px 34px", display: "flex", flexDirection: "column", gap: "12px" }}>
              <div style={{ fontSize: "16px", fontWeight: "700", textAlign: "center" }}>
                {"ลากนิ้วตามเส้นจุด เพื่อเกี่ยวส้นเท้า"}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <span style={{ fontSize: "13px", fontWeight: "700", width: "70px" }}>
                  {"ความแม่น"}
                </span>
                <div style={{ flex: "1", height: "18px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
                  <div className="bb-fill" style={{ width: "46%", height: "100%", background: "#FFC93C" }} />
                </div>
                <b style={{ fontSize: "14px" }}>
                  {"46%"}
                </b>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <span style={{ fontSize: "13px", fontWeight: "700", width: "70px" }}>
                  {"เวลา"}
                </span>
                <div style={{ flex: "1", height: "18px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
                  <div className="bb-fill" style={{ width: "72%", height: "100%", background: "#17B2A0" }} />
                </div>
                <b style={{ fontSize: "14px" }}>
                  {"2.1s"}
                </b>
              </div>
            </div>
          </>
        ) : null}
      </div>
  );
}
