// Generated from handoff/screens/A03-Login.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type A03LoginProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A03LoginProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A03Login(props: A03LoginProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <Chibi pose="wave" w="66" band="#FFC93C" />
        </div>
        <div style={{ padding: "4px 24px 0", display: "flex", flexDirection: "column", gap: "6px" }}>
          <h1 style={{ margin: "0", fontSize: "28px", fontWeight: "700" }}>
            {"ยินดีต้อนรับกลับมา"}
          </h1>
        </div>
        <form style={{ padding: "24px 24px 0", display: "flex", flexDirection: "column", gap: "14px" }}>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"อีเมล\n"}
            <input type="email" placeholder="you@email.com" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"รหัสผ่าน\n"}
            <span style={{ position: "relative", display: "flex" }}>
              <input type="password" defaultValue="climbing123" style={{ flex: "1", height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 52px 0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
              <button type="button" aria-label="แสดงรหัสผ่าน" style={{ position: "absolute", right: "4px", top: "4px", width: "44px", height: "44px", border: "none", background: "none", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                </svg>
              </button>
            </span>
          </label>
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <a href="A04-ForgotPassword.dc.html" style={{ minHeight: "44px", display: "flex", alignItems: "center", fontSize: "14px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/forgot")}>
              {"ลืมรหัสผ่าน?"}
            </a>
          </div>
          <button type="submit" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/map")}>
            {"เข้าสู่ระบบ"}
          </button>
        </form>
        <div style={{ padding: "22px 24px 0", display: "flex", alignItems: "center", gap: "12px", fontSize: "13px", color: "#55557A" }}>
          <span style={{ flex: "1", height: "2px", background: "#E9DFCF" }} />
          {"หรือเข้าด้วย"}
          <span style={{ flex: "1", height: "2px", background: "#E9DFCF" }} />
        </div>
        <div style={{ padding: "16px 24px 0", display: "flex", flexDirection: "column", gap: "10px" }}>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }} onClick={() => go("/map")}>
            <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "8px", background: "#06C755", color: "#FFFFFF", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"L"}
            </span>
            {"LINE"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }} onClick={() => go("/map")}>
            <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "50%", border: "2px solid #1B1B3A", boxSizing: "border-box", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"G"}
            </span>
            {"Google"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#1B1B3A", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "600", color: "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }} onClick={() => go("/map")}>
            <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "8px", background: "#FFFFFF", color: "#1B1B3A", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"A"}
            </span>
            {"Apple"}
          </button>
        </div>
        <div style={{ flex: "1" }} />
        <p style={{ margin: "0", padding: "0 24px 34px", textAlign: "center", fontSize: "15px", color: "#55557A" }}>
          {"ยังไม่มีบัญชี? "}
          <a href="A05-Register.dc.html" style={{ color: "#1B1B3A", fontWeight: "700" }} onClick={() => go("/register")}>
            {"สมัครสมาชิก"}
          </a>
        </p>
      </div>
  );
}
