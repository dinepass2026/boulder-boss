// Generated from handoff/screens/D22-EditProfile.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type D22EditProfileProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D22EditProfileProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function D22EditProfile(props: D22EditProfileProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"แก้ไขโปรไฟล์"}
          </h1>
          <button type="button" style={{ height: "44px", padding: "0 16px", borderRadius: "14px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("back")}>
            {"บันทึก"}
          </button>
        </div>
        <div style={{ padding: "20px 20px 0", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
          <div style={{ position: "relative", width: "128px", height: "128px", borderRadius: "36px", background: "#5AB8FF", border: "3px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", overflow: "hidden", display: "flex", justifyContent: "center", alignItems: "flex-start" }}>
            <div style={{ marginTop: "6px" }}>
              <Chibi pose="wave" w="140" band="#FFC93C" />
            </div>
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            <button type="button" style={{ height: "44px", padding: "0 14px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", color: "#1B1B3A" }}>
              {"เปลี่ยนท่าโปรไฟล์"}
            </button>
            <button type="button" style={{ height: "44px", padding: "0 14px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", color: "#1B1B3A" }}>
              {"สีพื้นหลัง"}
            </button>
          </div>
        </div>
        <form style={{ padding: "18px 24px 0", display: "flex", flexDirection: "column", gap: "16px" }}>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"ชื่อในเกม\n"}
            <input type="text" defaultValue="น้องชอล์ก" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
            <span style={{ fontSize: "12px", fontWeight: "500", color: "#55557A" }}>
              {"เปลี่ยนชื่อได้ 1 ครั้งทุก 30 วัน · ครั้งถัดไป 12 ธ.ค."}
            </span>
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"คำแนะนำตัว\n"}
            <textarea rows={3} style={{ boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "12px 16px", fontFamily: "inherit", fontSize: "16px", lineHeight: "1.5", color: "#1B1B3A", resize: "none" }} defaultValue="ปีน slab ไม่เก่ง แต่ชอบ crimp มาก หาเพื่อนปีนแถวทองหล่อ" />
            <span style={{ fontSize: "12px", fontWeight: "500", color: "#55557A", alignSelf: "flex-end" }}>
              {"52/120"}
            </span>
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"ยิมโปรด\n"}
            <select style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }}>
              <option>
                {"Crimp Factory ทองหล่อ"}
              </option>
              <option>
                {"Slab Lab เอกมัย"}
              </option>
              <option>
                {"Dyno Den พร้อมพงษ์"}
              </option>
            </select>
          </label>
        </form>
        <div style={{ flex: "1" }} />
        <div style={{ padding: "0 24px 34px" }}>
          <button type="button" style={{ width: "100%", height: "52px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/wardrobe")}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M8 3l4 3 4-3 5 4-3 4-2-1v11H8V10l-2 1-3-4z" />
            </svg>
            {"แต่งตัวที่ตู้เสื้อผ้า"}
          </button>
        </div>
      </div>
  );
}
