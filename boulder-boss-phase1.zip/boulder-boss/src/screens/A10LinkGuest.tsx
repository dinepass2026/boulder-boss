// Generated from handoff/screens/A10-LinkGuest.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Skyline from '../components/Skyline';

export type A10LinkGuestProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A10LinkGuestProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A10LinkGuest(props: A10LinkGuestProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#0C1433" }}>
        <div style={{ position: "absolute", inset: "0" }}>
          <Skyline time="dusk" w="390" h="844" />
        </div>
        <div style={{ position: "absolute", inset: "0", background: "rgba(27,27,58,0.6)" }} />
        <div className="bb-sheet" role="dialog" aria-modal="true" aria-labelledby="lg-title" style={{ position: "absolute", left: "0", right: "0", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "12px 24px 34px", display: "flex", flexDirection: "column", gap: "14px" }}>
          <div style={{ alignSelf: "center", width: "48px", height: "5px", borderRadius: "999px", background: "#B9B2C8" }} />
          <div style={{ display: "flex", alignItems: "flex-end", gap: "12px", marginTop: "-60px" }}>
            <Chibi pose="cheer" w="100" band="#FFC93C" />
            <span style={{ marginBottom: "14px", height: "32px", padding: "0 12px", borderRadius: "10px", background: "#FFC93C", border: "2.5px solid #1B1B3A", fontSize: "14px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"+100 เหรียญเมื่อผูกบัญชี"}
            </span>
          </div>
          <h1 id="lg-title" style={{ margin: "0", fontSize: "24px", lineHeight: "1.3" }}>
            {"เล่นมา 3 วันแล้ว!"}
            <br />
            {"ผูกบัญชีกันความคืบหน้าหาย"}
          </h1>
          <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.5", color: "#55557A" }}>
            {"ตอนนี้ข้อมูลอยู่ในเครื่องนี้เท่านั้น ถ้าลบแอปหรือเปลี่ยนเครื่องจะหายทั้งหมด"}
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"V3"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"เกรดสูงสุด"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"24"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"Send"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px", textAlign: "center" }}>
              <div style={{ fontSize: "22px", fontWeight: "700" }}>
                {"1,250"}
              </div>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"เหรียญ"}
              </div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
            <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/map")}>
              <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "7px", background: "#06C755", color: "#FFFFFF", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"L"}
              </span>
              {"LINE"}
            </button>
            <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/map")}>
              <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "50%", border: "2px solid #1B1B3A", boxSizing: "border-box", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"G"}
              </span>
              {"Google"}
            </button>
            <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#1B1B3A", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/map")}>
              <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "7px", background: "#FFFFFF", color: "#1B1B3A", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"A"}
              </span>
              {"Apple"}
            </button>
          </div>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/register")}>
            {"ผูกด้วยอีเมล"}
          </button>
          <button type="button" style={{ height: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#55557A" }} onClick={() => go("back")}>
            {"ไว้ทีหลัง (เตือนอีกครั้งพรุ่งนี้)"}
          </button>
        </div>
      </div>
  );
}
