// Generated from handoff/screens/A02-Welcome.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Skyline from '../components/Skyline';

export type A02WelcomeProps = { time?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A02WelcomeProps, state: any, setState: (patch: any) => void): any {
 return { time: props.time ?? 'auto' };
}

export default function A02Welcome(props: A02WelcomeProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ position: "relative", height: "440px", flexShrink: "0" }}>
          <Skyline time={v.time} w="390" h="440" />
          <div style={{ position: "absolute", left: "0", right: "0", bottom: "6px", display: "flex", justifyContent: "center", alignItems: "flex-end", gap: "0" }}>
            <Chibi pose="wave" w="96" shirt="#17B2A0" pants="#1B1B3A" hair="#6B3E26" skin="#FFE0C2" />
            <Chibi pose="cheer" w="132" shirt="#FF5F45" pants="#3B5BDB" band="#FFC93C" />
            <Chibi pose="stand" w="96" shirt="#6C4CF1" pants="#2D2346" hair="#1B1B3A" skin="#D9A27A" shoes="#3DDC84" />
          </div>
        </div>
        <div className="bb-sheet" style={{ flex: "1", marginTop: "-28px", position: "relative", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "28px 24px 32px", display: "flex", flexDirection: "column", gap: "14px" }}>
          <h1 style={{ margin: "0", fontSize: "28px", lineHeight: "1.25", fontWeight: "700" }}>
            {"ปีนผาทั่วกรุงเทพ"}
            <br />
            {"กับเพื่อนทั้งเมือง"}
          </h1>
          <p style={{ margin: "0", fontSize: "16px", lineHeight: "1.55", color: "#55557A" }}>
            {"ไล่ Send รูทในยิม ปลดล็อกโซนใหม่ แล้วขึ้นไปท้า Boss Wall"}
          </p>
          <div style={{ flex: "1" }} />
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/register")}>
            {"สมัครสมาชิก"}
          </button>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/login")}>
            {"เข้าสู่ระบบ"}
          </button>
          <button type="button" style={{ height: "48px", border: "none", background: "none", fontFamily: "inherit", fontSize: "16px", fontWeight: "700", color: "#1B1B3A", textDecoration: "underline" }} onClick={() => go("/player-info")}>
            {"เล่นแบบ Guest ก่อน"}
          </button>
          <p style={{ margin: "0", fontSize: "12px", lineHeight: "1.5", color: "#55557A", textAlign: "center" }}>
            {"การเล่นต่อถือว่ายอมรับ "}
            <a href="#" style={{ color: "#1B1B3A", fontWeight: "600" }} onClick={() => go("/legal")}>
              {"ข้อตกลงการใช้งาน"}
            </a>
            {" และ "}
            <a href="#" style={{ color: "#1B1B3A", fontWeight: "600" }} onClick={() => go("/legal")}>
              {"นโยบายความเป็นส่วนตัว"}
            </a>
          </p>
        </div>
      </div>
  );
}
