// Generated from handoff/screens/A04-ForgotPassword.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type A04ForgotPasswordProps = { startStep?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A04ForgotPasswordProps, state: any, setState: (patch: any) => void): any {

const step = (state && state.step) || Number(props.startStep ?? 1);
const labels = ['อีเมล', 'OTP', 'รหัสใหม่'];
return {
isStep1: step === 1, isStep2: step === 2, isStep3: step === 3,
steps: labels.map((label, i) => ({ label, bg: i < step ? '#FFC93C' : '#FFFFFF', fg: i < step ? '#1B1B3A' : '#55557A', weight: i + 1 === step ? 700 : 500 })),
next: () => setState({ step: Math.min(3, step + 1) }),
back: () => setState({ step: Math.max(1, step - 1) }),
reset: () => setState({ step: 1 })
};
}

export default function A04ForgotPassword(props: A04ForgotPasswordProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" onClick={v.isStep1 ? () => go("back") : v.back} style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", fontSize: "20px", fontWeight: "700" }}>
            {"ลืมรหัสผ่าน"}
          </h1>
        </div>
        <div style={{ padding: "20px 24px 0", display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
          {(v.steps || []).map((s: any, s_i: number) => (
            <Fragment key={s_i}>
              <div className="bb-in" style={{ display: "flex", flexDirection: "column", gap: "6px", animationDelay: `${Math.min(s_i, 12) * 45}ms` }}>
                <div style={{ height: "10px", borderRadius: "999px", border: "2px solid #1B1B3A", background: s.bg }} />
                <span style={{ fontSize: "12px", fontWeight: s.weight, color: s.fg }}>
                  {s.label}
                </span>
              </div>
            </Fragment>
          ))}
        </div>
        {v.isStep1 ? (
          <>
            <div style={{ flex: "1", padding: "28px 24px 34px", display: "flex", flexDirection: "column", gap: "16px" }}>
              <div style={{ width: "88px", height: "88px", borderRadius: "24px", background: "#5AB8FF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M3 6h18v12H3z M3 7l9 6 9-6" />
                </svg>
              </div>
              <h2 style={{ margin: "0", fontSize: "24px" }}>
                {"กรอกอีเมลที่ใช้สมัคร"}
              </h2>
              <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.55", color: "#55557A" }}>
                {"เราจะส่งรหัส OTP 6 หลักไปที่อีเมลนี้ รหัสใช้ได้ 10 นาที"}
              </p>
              <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
                {"อีเมล\n"}
                <input type="email" defaultValue="chalk.nong@email.com" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
              </label>
              <div style={{ flex: "1" }} />
              <button type="button" onClick={v.next} style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }}>
                {"ส่งรหัส OTP"}
              </button>
            </div>
          </>
        ) : null}
        {v.isStep2 ? (
          <>
            <div style={{ flex: "1", padding: "28px 24px 34px", display: "flex", flexDirection: "column", gap: "16px" }}>
              <h2 style={{ margin: "0", fontSize: "24px" }}>
                {"ใส่รหัสจากอีเมล"}
              </h2>
              <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.55", color: "#55557A" }}>
                {"ส่งไปที่ "}
                <b style={{ color: "#1B1B3A" }}>
                  {"chalk.nong@email.com"}
                </b>
                {" แล้ว"}
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(6, minmax(0, 1fr))", gap: "8px" }}>
                <input aria-label="หลักที่ 1" defaultValue="4" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
                <input aria-label="หลักที่ 2" defaultValue="8" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
                <input aria-label="หลักที่ 3" defaultValue="1" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
                <input aria-label="หลักที่ 4" defaultValue="" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #FF5F45", borderRadius: "14px", background: "#FFF1EE", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
                <input aria-label="หลักที่ 5" defaultValue="" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
                <input aria-label="หลักที่ 6" defaultValue="" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
              </div>
              <p style={{ margin: "0", fontSize: "14px", color: "#55557A" }}>
                {"ไม่ได้รับรหัส? ส่งใหม่ได้ใน "}
                <b style={{ color: "#1B1B3A" }}>
                  {"00:45"}
                </b>
              </p>
              <div style={{ flex: "1" }} />
              <button type="button" onClick={v.next} style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }}>
                {"ยืนยันรหัส"}
              </button>
            </div>
          </>
        ) : null}
        {v.isStep3 ? (
          <>
            <div style={{ flex: "1", padding: "28px 24px 34px", display: "flex", flexDirection: "column", gap: "14px" }}>
              <h2 style={{ margin: "0", fontSize: "24px" }}>
                {"ตั้งรหัสผ่านใหม่"}
              </h2>
              <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
                {"รหัสผ่านใหม่\n"}
                <input type="password" defaultValue="newpass2026" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
              </label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "6px" }}>
                <span style={{ height: "8px", borderRadius: "999px", background: "#17B2A0" }} />
                <span style={{ height: "8px", borderRadius: "999px", background: "#17B2A0" }} />
                <span style={{ height: "8px", borderRadius: "999px", background: "#17B2A0" }} />
                <span style={{ height: "8px", borderRadius: "999px", background: "#E9DFCF" }} />
              </div>
              <span style={{ fontSize: "13px", color: "#55557A" }}>
                {"ความแข็งแรง: ดี · อย่างน้อย 8 ตัว มีตัวเลข"}
              </span>
              <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
                {"ยืนยันรหัสผ่านใหม่\n"}
                <input type="password" defaultValue="newpass2026" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
              </label>
              <div style={{ flex: "1" }} />
              <button type="button" onClick={() => go("/map")} style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }}>
                {"บันทึกและเข้าสู่ระบบ"}
              </button>
            </div>
          </>
        ) : null}
      </div>
  );
}
