// Generated from handoff/screens/B13-Gym.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import BottomNav from '../components/BottomNav';

export type B13GymProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B13GymProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function B13Gym(props: B13GymProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "250px", background: "#6B5B95", borderBottom: "2.5px solid #1B1B3A", overflow: "hidden" }}>
          <svg width="390" height="250" viewBox="0 0 390 250" aria-hidden="true">
            <rect width="390" height="250" fill="#5A4A82" />
            <g stroke="#4A3B70" strokeWidth="6">
              <path d="M0 40H390 M60 0V120 M180 0V120 M300 0V120" />
            </g>
            <polygon points="10,250 10,110 100,90 110,250" fill="#F3D9A8" stroke="#1B1B3A" strokeWidth="2.5" />
            <polygon points="110,250 100,90 210,70 220,250" fill="#EBCB93" stroke="#1B1B3A" strokeWidth="2.5" />
            <polygon points="220,250 210,70 300,100 300,250" fill="#F3D9A8" stroke="#1B1B3A" strokeWidth="2.5" />
            <polygon points="300,250 300,100 380,120 380,250" fill="#E5C185" stroke="#1B1B3A" strokeWidth="2.5" />
            <g stroke="#1B1B3A" strokeWidth="2">
              <circle cx="40" cy="200" r="7" fill="#FF5F45" />
              <circle cx="70" cy="150" r="6" fill="#5AB8FF" />
              <circle cx="140" cy="190" r="7" fill="#FFC93C" />
              <circle cx="170" cy="130" r="6" fill="#FF5F45" />
              <circle cx="250" cy="170" r="7" fill="#3DDC84" />
              <circle cx="270" cy="120" r="6" fill="#6C4CF1" />
              <circle cx="330" cy="190" r="7" fill="#FF5F45" />
              <circle cx="350" cy="150" r="6" fill="#5AB8FF" />
            </g>
            <rect x="0" y="232" width="390" height="18" fill="#3B5BDB" />
          </svg>
          <span style={{ position: "absolute", left: "40px", top: "210px", width: "30px", height: "26px", borderRadius: "8px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"A"}
          </span>
          <span style={{ position: "absolute", left: "148px", top: "210px", width: "30px", height: "26px", borderRadius: "8px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"B"}
          </span>
          <span style={{ position: "absolute", left: "244px", top: "210px", width: "30px", height: "26px", borderRadius: "8px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"C"}
          </span>
          <span style={{ position: "absolute", left: "326px", top: "210px", width: "30px", height: "26px", borderRadius: "8px", background: "#1B1B3A", color: "#FFC93C", border: "2px solid #1B1B3A", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
            {"D"}
          </span>
        </div>
        <button type="button" aria-label="ย้อนกลับ" style={{ position: "absolute", left: "20px", top: "52px", width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" />
          </svg>
        </button>
        <span style={{ position: "absolute", right: "20px", top: "56px", height: "36px", padding: "0 12px", borderRadius: "12px", background: "#FFC93C", border: "2.5px solid #1B1B3A", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center", gap: "6px" }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" />
          </svg>
          {"คลับประจำยิม: Crimp Gang"}
        </span>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "266px", bottom: "96px", display: "flex", flexDirection: "column", gap: "14px", overflow: "hidden" }}>
          <div>
            <h1 style={{ margin: "0", fontSize: "26px" }}>
              {"Crimp Factory ทองหล่อ"}
            </h1>
            <div style={{ fontSize: "13px", color: "#55557A" }}>
              {"4 ผนัง · 48 รูท · "}
              <span style={{ color: "#0B6B60", fontWeight: "600" }}>
                {"156 คนในยิมตอนนี้"}
              </span>
            </div>
          </div>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", padding: "12px 14px", display: "flex", flexDirection: "column", gap: "8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "14px", fontWeight: "700" }}>
              <span>
                {"รูทแยกตามเกรด"}
              </span>
              <span style={{ color: "#55557A", fontWeight: "500", fontSize: "12px" }}>
                {"Send แล้ว 14/48"}
              </span>
            </div>
            <div style={{ height: "76px", display: "grid", gridTemplateColumns: "repeat(10, minmax(0, 1fr))", gap: "5px", alignItems: "end" }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "34px", background: "#3DDC84", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V0"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "44px", background: "#3DDC84", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V1"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "56px", background: "#5AB8FF", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V2"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "56px", background: "#5AB8FF", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V3"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "48px", background: "#FFC93C", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V4"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "40px", background: "#FFC93C", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V5"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "28px", background: "#FF8A3D", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V6"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "20px", background: "#FF8A3D", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V7"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "14px", background: "#C81D25", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V8"}
                </span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "3px" }}>
                <div style={{ width: "100%", height: "10px", background: "#C81D25", border: "2px solid #1B1B3A", borderRadius: "5px", boxSizing: "border-box" }} />
                <span style={{ fontSize: "11px", fontWeight: "600" }}>
                  {"V9"}
                </span>
              </div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
            <button type="button" style={{ textAlign: "left", minHeight: "92px", borderRadius: "20px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", padding: "12px", display: "flex", flexDirection: "column", justifyContent: "space-between", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("soon")}>
              <span style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
                <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M2 21c0-4 3-6 7-6s7 2 7 6 M16 3a4 4 0 0 1 0 8 M22 21c0-3-2-5-4-6" />
                </svg>
                <span style={{ height: "22px", padding: "0 6px", borderRadius: "6px", background: "#EDE6DA", fontSize: "11px", fontWeight: "700", color: "#55557A", display: "flex", alignItems: "center" }}>
                  {"เร็วๆ นี้"}
                </span>
              </span>
              <b style={{ fontSize: "16px", display: "block" }}>
                {"เข้า Lobby"}
              </b>
            </button>
            <button type="button" style={{ textAlign: "left", minHeight: "92px", borderRadius: "20px", background: "#1B1B3A", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #FFC93C", padding: "12px", display: "flex", flexDirection: "column", justifyContent: "space-between", fontFamily: "inherit", color: "#FFFFFF" }} onClick={() => go("soon")}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#FFC93C" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M8 4h8v5a4 4 0 0 1-8 0z M8 6H4v1a4 4 0 0 0 4 4 M16 6h4v1a4 4 0 0 1-4 4 M12 13v4 M8 21h8" />
              </svg>
              <span>
                <b style={{ fontSize: "16px", display: "block", color: "#FFC93C" }}>
                  {"Boss Wall"}
                </b>
                <span style={{ fontSize: "12px", color: "#D8D6EA" }}>
                  {"ต้อง Send V5 ครบ 3 เส้น"}
                </span>
              </span>
            </button>
          </div>
          <button type="button" style={{ height: "56px", flexShrink: "0", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/routes")}>
            {"ดูรูททั้งหมด (48)"}
          </button>
        </div>
        <div style={{ position: "absolute", left: "0", bottom: "0" }}>
          <BottomNav active="gym" />
        </div>
      </div>
  );
}
