// Generated from handoff/screens/D26-PlayerProfile.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type D26PlayerProfileProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D26PlayerProfileProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function D26PlayerProfile(props: D26PlayerProfileProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "236px", background: "#FF8A3D", borderBottom: "2.5px solid #1B1B3A", overflow: "hidden" }}>
          <svg width="390" height="236" viewBox="0 0 390 236" aria-hidden="true">
            <g fill="#FF9D5C">
              <circle cx="330" cy="60" r="34" />
              <circle cx="60" cy="140" r="18" />
            </g>
            <ellipse cx="96" cy="226" rx="70" ry="14" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2.5" />
          </svg>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "52px", display: "flex", justifyContent: "space-between" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <button type="button" aria-label="ตัวเลือกเพิ่มเติม" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="#1B1B3A" aria-hidden="true">
              <circle cx="5" cy="12" r="2.2" />
              <circle cx="12" cy="12" r="2.2" />
              <circle cx="19" cy="12" r="2.2" />
            </svg>
          </button>
        </div>
        <div style={{ position: "absolute", left: "38px", top: "72px" }}>
          <Chibi pose="stand" w="116" shirt="#1B1B3A" pants="#6C4CF1" hair="#E0A458" skin="#D9A27A" shoes="#3DDC84" />
        </div>
        <div style={{ position: "absolute", left: "176px", top: "116px", right: "20px", display: "flex", flexDirection: "column", gap: "6px" }}>
          <h1 style={{ margin: "0", fontSize: "24px", lineHeight: "1.1" }}>
            {"ปีนแหลก99"}
          </h1>
          <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
            <span style={{ minWidth: "40px", height: "28px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V6"}
            </span>
            <span style={{ fontSize: "13px", fontWeight: "700" }}>
              {"Lv.31"}
            </span>
          </div>
          <span style={{ alignSelf: "flex-start", height: "28px", padding: "0 10px", borderRadius: "9px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", gap: "6px" }}>
            <span className="bb-live" style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#17B2A0" }} />
            {"อยู่ที่ Dyno Den"}
          </span>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "254px", bottom: "34px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.5" }}>
            {"สาย dyno ตัวพ่อ ชอบรูทที่ต้องกระโดด ใครอยู่พร้อมพงษ์ทักมาปีนด้วยกันได้"}
          </p>
          <div style={{ display: "flex", gap: "8px", fontSize: "13px", color: "#55557A" }}>
            <span>
              {"คลับ "}
              <b style={{ color: "#1B1B3A" }}>
                {"Dyno Bros"}
              </b>
            </span>
            <span>
              {"·"}
            </span>
            <span>
              {"ยิมโปรด "}
              <b style={{ color: "#1B1B3A" }}>
                {"Dyno Den"}
              </b>
            </span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "8px" }}>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"212"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"Send"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"48"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"Flash"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"V7"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"สูงสุด"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"2"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"Boss Wall"}
              </div>
            </div>
          </div>
          <h2 style={{ margin: "0", fontSize: "16px" }}>
            {"Send ล่าสุด"}
          </h2>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", overflow: "hidden" }}>
            <div style={{ minHeight: "48px", padding: "0 12px", display: "flex", alignItems: "center", gap: "10px", borderBottom: "2px solid #F1E9DC" }}>
              <span style={{ minWidth: "38px", height: "26px", borderRadius: "8px", border: "2px solid #1B1B3A", background: "#FF8A3D", fontWeight: "700", fontSize: "13px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"V6"}
              </span>
              <span style={{ flex: "1", fontSize: "14px", fontWeight: "600" }}>
                {"ตุ๊กตุ๊กซิ่ง"}
              </span>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"เมื่อวาน"}
              </span>
            </div>
            <div style={{ minHeight: "48px", padding: "0 12px", display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ minWidth: "38px", height: "26px", borderRadius: "8px", border: "2px solid #1B1B3A", background: "#FF8A3D", fontWeight: "700", fontSize: "13px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"V7"}
              </span>
              <span style={{ flex: "1", fontSize: "14px", fontWeight: "600" }}>
                {"หมูกระทะ"}
              </span>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"3 วันก่อน"}
              </span>
            </div>
          </div>
          <div style={{ flex: "1" }} />
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("soon")}>
            {"เพิ่มเพื่อน"}
          </button>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("soon")}>
              {"ส่งข้อความ"}
            </button>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("soon")}>
              {"ชวนปีนด้วยกัน"}
            </button>
          </div>
          <div style={{ display: "flex", justifyContent: "center", gap: "24px" }}>
            <button type="button" style={{ minHeight: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", color: "#55557A" }} onClick={() => go("soon")}>
              {"รายงาน"}
            </button>
            <button type="button" style={{ minHeight: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", color: "#B4232A" }} onClick={() => go("soon")}>
              {"บล็อก"}
            </button>
          </div>
        </div>
      </div>
  );
}
