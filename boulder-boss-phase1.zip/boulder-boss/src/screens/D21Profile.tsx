// Generated from handoff/screens/D21-Profile.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import BottomNav from '../components/BottomNav';
import Chibi from '../components/Chibi';

export type D21ProfileProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D21ProfileProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function D21Profile(props: D21ProfileProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "236px", background: "#5AB8FF", borderBottom: "2.5px solid #1B1B3A", overflow: "hidden" }}>
          <svg width="390" height="236" viewBox="0 0 390 236" aria-hidden="true">
            <g fill="#4AA4EA">
              <circle cx="40" cy="70" r="16" />
              <circle cx="350" cy="150" r="24" />
              <circle cx="300" cy="60" r="10" />
            </g>
            <ellipse cx="96" cy="226" rx="70" ry="14" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2.5" />
          </svg>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "52px", display: "flex", justifyContent: "flex-end", gap: "8px" }}>
          <button type="button" aria-label="แก้ไขโปรไฟล์" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("/profile/edit")}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M4 20h4L19 9l-4-4L4 16z M14 6l4 4" />
            </svg>
          </button>
          <button type="button" aria-label="ตั้งค่า" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("/settings")}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
            </svg>
          </button>
        </div>
        <div style={{ position: "absolute", left: "38px", top: "72px" }}>
          <Chibi pose="wave" w="116" band="#FFC93C" />
        </div>
        <div style={{ position: "absolute", left: "176px", top: "120px", right: "20px", display: "flex", flexDirection: "column", gap: "6px" }}>
          <h1 style={{ margin: "0", fontSize: "24px", lineHeight: "1.1" }}>
            {"น้องชอล์ก"}
          </h1>
          <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
            <span style={{ minWidth: "40px", height: "28px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#5AB8FF", boxShadow: "0 2px 0 #1B1B3A", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V3"}
            </span>
            <span style={{ fontSize: "13px", fontWeight: "700" }}>
              {"Lv.12"}
            </span>
          </div>
          <span style={{ alignSelf: "flex-start", height: "28px", padding: "0 10px", borderRadius: "9px", background: "#1B1B3A", color: "#FFC93C", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", gap: "4px" }}>
            {"คลับ Crimp Gang"}
          </span>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "254px", bottom: "96px", display: "flex", flexDirection: "column", gap: "12px", overflow: "hidden" }}>
          <div style={{ display: "flex", gap: "12px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "10px 12px", alignItems: "center" }}>
            <svg width="150" height="150" viewBox="0 0 160 160" role="img" aria-label="กราฟ stat: แรงนิ้ว 62 Stamina 48 Flexibility 40 Technique 70">
              <polygon points="80,20 140,80 80,140 20,80" fill="#FFF7EC" stroke="#E9DFCF" strokeWidth="2" />
              <polygon points="80,40 120,80 80,120 40,80" fill="none" stroke="#E9DFCF" strokeWidth="2" />
              <polygon points="80,60 100,80 80,100 60,80" fill="none" stroke="#E9DFCF" strokeWidth="2" />
              <path d="M80 20V140 M20 80H140" stroke="#E9DFCF" strokeWidth="2" />
              <polygon points="80,42.8 108.8,80 80,104 38,80" fill="#FF5F45" fillOpacity="0.55" stroke="#1B1B3A" strokeWidth="2.5" strokeLinejoin="round" />
              <g fill="#1B1B3A">
                <circle cx="80" cy="42.8" r="3.5" />
                <circle cx="108.8" cy="80" r="3.5" />
                <circle cx="80" cy="104" r="3.5" />
                <circle cx="38" cy="80" r="3.5" />
              </g>
              <text x="80" y="12" textAnchor="middle" fontSize="11" fontWeight="700" fill="#1B1B3A" fontFamily="Bai Jamjuree">
                {"แรงนิ้ว"}
              </text>
              <text x="80" y="156" textAnchor="middle" fontSize="11" fontWeight="700" fill="#1B1B3A" fontFamily="Bai Jamjuree">
                {"Flex"}
              </text>
              <text x="156" y="84" textAnchor="end" fontSize="11" fontWeight="700" fill="#1B1B3A" fontFamily="Bai Jamjuree">
                {"Sta"}
              </text>
              <text x="4" y="84" fontSize="11" fontWeight="700" fill="#1B1B3A" fontFamily="Bai Jamjuree">
                {"Tech"}
              </text>
            </svg>
            <div style={{ flex: "1", display: "flex", flexDirection: "column", gap: "6px", fontSize: "13px" }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {"แรงนิ้ว"}
                </span>
                <b>
                  {"62"}
                </b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {"Stamina"}
                </span>
                <b>
                  {"48"}
                </b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {"Flexibility"}
                </span>
                <b>
                  {"40"}
                </b>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span>
                  {"Technique"}
                </span>
                <b>
                  {"70"}
                </b>
              </div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "8px" }}>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"24"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"Send"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"6"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"Flash"}
              </div>
            </div>
            <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"V4"}
              </div>
              <div style={{ fontSize: "11px", color: "#55557A" }}>
                {"สูงสุด"}
              </div>
            </div>
            <div style={{ background: "#FFC93C", border: "2.5px solid #1B1B3A", borderRadius: "14px", padding: "8px 4px", textAlign: "center" }}>
              <div style={{ fontSize: "20px", fontWeight: "700" }}>
                {"7"}
              </div>
              <div style={{ fontSize: "11px", color: "#1B1B3A" }}>
                {"วันติด"}
              </div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ margin: "0", fontSize: "17px" }}>
              {"ตราและ Boss Wall"}
            </h2>
            <a href="D25-Achievements.dc.html" style={{ minHeight: "44px", display: "flex", alignItems: "center", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/achievements")}>
              {"ดูทั้งหมด"}
            </a>
          </div>
          <div style={{ display: "flex", gap: "10px", marginTop: "-8px" }}>
            <span style={{ width: "56px", height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }} aria-label="ตรา Send แรก" role="img">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 21V4 M5 4h11l-2 4 2 4H5" />
              </svg>
            </span>
            <span style={{ width: "56px", height: "56px", borderRadius: "16px", background: "#FF5F45", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }} aria-label="ตรา Streak 7 วัน" role="img">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 22c4 0 7-3 7-7 0-5-5-7-5-12-3 2-5 5-5 8-1-1-2-2-2-4-2 2-2 5-2 8 0 4 3 7 7 7z" />
              </svg>
            </span>
            <span style={{ width: "56px", height: "56px", borderRadius: "16px", background: "#17B2A0", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }} aria-label="ตรา Flash 5 ครั้ง" role="img">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M13 2L4 14h7l-1 8 9-12h-7z" />
              </svg>
            </span>
            <span style={{ width: "56px", height: "56px", borderRadius: "16px", background: "#EDE6DA", border: "2.5px dashed #6B6680", display: "flex", alignItems: "center", justifyContent: "center" }} aria-label="Boss Wall ยังไม่ผ่าน" role="img">
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M6 11h12v10H6z M8 11V8a4 4 0 0 1 8 0v3" />
              </svg>
            </span>
          </div>
          <h2 style={{ margin: "0", fontSize: "17px" }}>
            {"Project ค้างอยู่ (2)"}
          </h2>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "16px", padding: "10px 12px", display: "flex", gap: "10px", alignItems: "center", flexShrink: "0" }}>
            <span style={{ minWidth: "40px", height: "30px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#FFC93C", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V4"}
            </span>
            <div style={{ flex: "1", minWidth: "0" }}>
              <div style={{ fontSize: "15px", fontWeight: "700" }}>
                {"ข้าวเหนียวมะม่วง"}
              </div>
              <div style={{ height: "8px", borderRadius: "999px", background: "#EDE6DA", marginTop: "4px", overflow: "hidden" }}>
                <div className="bb-fill" style={{ width: "74%", height: "100%", background: "#FF5F45" }} />
              </div>
            </div>
            <span style={{ fontSize: "13px", fontWeight: "700" }}>
              {"74%"}
            </span>
          </div>
        </div>
        <div style={{ position: "absolute", left: "0", bottom: "0" }}>
          <BottomNav active="profile" />
        </div>
      </div>
  );
}
