// Generated from handoff/screens/B13b-WallView.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Wall from '../components/Wall';

export type B13bWallViewProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B13bWallViewProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function B13bWallView(props: B13bWallViewProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#5A4A82" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "150px", height: "470px", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: "0", top: "-120px" }}>
            <Wall mode="plain" />
          </div>
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "150px", boxSizing: "border-box", padding: "48px 16px 0", background: "#1B1B3A", display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M15 5l-7 7 7 7" />
              </svg>
            </button>
            <div style={{ flex: "1", color: "#FFFFFF" }}>
              <div style={{ fontSize: "18px", fontWeight: "700" }}>
                {"ผนัง A · The Cave"}
              </div>
              <div style={{ fontSize: "12px", color: "#D8D6EA" }}>
                {"Crimp Factory · ชัน 45° · 14 รูท"}
              </div>
            </div>
            <span style={{ height: "30px", padding: "0 8px", borderRadius: "8px", background: "#FF5F45", border: "2px solid #FFFFFF", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"รีเซ็ต 3 วันก่อน"}
            </span>
          </div>
          <div role="tablist" aria-label="เลือกผนัง" style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "6px" }}>
            <button type="button" role="tab" aria-selected="true" style={{ height: "40px", borderRadius: "12px", background: "#FFC93C", border: "2.5px solid #FFFFFF", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }}>
              {"A"}
            </button>
            <button type="button" role="tab" style={{ height: "40px", borderRadius: "12px", background: "#3A3A60", border: "2px solid #6B6A90", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#FFFFFF" }}>
              {"B"}
            </button>
            <button type="button" role="tab" style={{ height: "40px", borderRadius: "12px", background: "#3A3A60", border: "2px solid #6B6A90", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#FFFFFF" }}>
              {"C"}
            </button>
            <button type="button" role="tab" style={{ height: "40px", borderRadius: "12px", background: "#3A3A60", border: "2px solid #6B6A90", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#FFFFFF" }}>
              {"D"}
            </button>
          </div>
        </div>
        <button type="button" style={{ position: "absolute", left: "186px", top: "372px", height: "34px", padding: "0 10px", borderRadius: "10px", background: "#FF5F45", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/route")}>
          {"V4 · ข้าวเหนียวฯ"}
        </button>
        <button type="button" style={{ position: "absolute", left: "76px", top: "336px", height: "34px", padding: "0 10px", borderRadius: "10px", background: "#5AB8FF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/route")}>
          {"V3 · แตงโมหล่น"}
        </button>
        <button type="button" style={{ position: "absolute", left: "252px", top: "470px", height: "34px", padding: "0 10px", borderRadius: "10px", background: "#3DDC84", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/route")}>
          {"V1 · ชาไทย"}
        </button>
        <button type="button" style={{ position: "absolute", left: "236px", top: "280px", height: "34px", padding: "0 10px", borderRadius: "10px", background: "#6C4CF1", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#FFFFFF" }} onClick={() => go("/route")}>
          {"V6 · ตุ๊กตุ๊ก"}
        </button>
        <span style={{ position: "absolute", left: "16px", top: "568px", height: "32px", padding: "0 10px", borderRadius: "10px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
          {"แตะป้ายสีเพื่อไฮไลต์รูทบนผนัง"}
        </span>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", height: "240px", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "24px 24px 0 0", padding: "16px 20px 30px", display: "flex", flexDirection: "column", gap: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <b style={{ fontSize: "16px" }}>
              {"รูทบนผนังนี้"}
            </b>
            <span style={{ fontSize: "12px", color: "#55557A" }}>
              {"Send แล้ว 5/14"}
            </span>
          </div>
          <button type="button" style={{ textAlign: "left", minHeight: "56px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", padding: "0 12px", display: "flex", alignItems: "center", gap: "10px", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("/route")}>
            <span style={{ width: "14px", height: "14px", borderRadius: "50%", background: "#FF5F45", border: "2px solid #1B1B3A" }} />
            <span style={{ flex: "1" }}>
              <b style={{ fontSize: "15px", display: "block" }}>
                {"ข้าวเหนียวมะม่วง"}
              </b>
              <span style={{ fontSize: "12px", color: "#B4232A", fontWeight: "600" }}>
                {"Project · 74%"}
              </span>
            </span>
            <span style={{ minWidth: "42px", height: "30px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#FFC93C", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V4"}
            </span>
          </button>
          <button type="button" style={{ textAlign: "left", minHeight: "56px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", padding: "0 12px", display: "flex", alignItems: "center", gap: "10px", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("/route")}>
            <span style={{ width: "14px", height: "14px", borderRadius: "50%", background: "#6C4CF1", border: "2px solid #1B1B3A" }} />
            <span style={{ flex: "1" }}>
              <b style={{ fontSize: "15px", display: "block" }}>
                {"ตุ๊กตุ๊กซิ่ง"}
              </b>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"ยังไม่ปีน · Dyno"}
              </span>
            </span>
            <span style={{ minWidth: "42px", height: "30px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#FF8A3D", fontWeight: "700", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V6"}
            </span>
          </button>
          <button type="button" style={{ height: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#1B1B3A", textDecoration: "underline" }} onClick={() => go("/routes")}>
            {"ดูทั้ง 14 รูทของผนัง A"}
          </button>
        </div>
      </div>
  );
}
