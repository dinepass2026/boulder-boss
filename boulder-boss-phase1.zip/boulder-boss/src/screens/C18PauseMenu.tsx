// Generated from handoff/screens/C18-PauseMenu.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Wall from '../components/Wall';

export type C18PauseMenuProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: C18PauseMenuProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function C18PauseMenu(props: C18PauseMenuProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#1B1B3A" }}>
        <div style={{ position: "absolute", left: "0", top: "104px" }}>
          <Wall mode="climb" climberTop="322" />
        </div>
        <div style={{ position: "absolute", inset: "0", background: "rgba(27,27,58,0.72)" }} />
        <div role="dialog" aria-modal="true" aria-labelledby="pz-title" style={{ position: "absolute", left: "28px", right: "28px", top: "190px", background: "#FFF7EC", border: "3px solid #1B1B3A", borderRadius: "28px", boxShadow: "0 6px 0 #000000", padding: "24px 20px 20px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ position: "absolute", left: "50%", top: "-26px", marginLeft: "-26px", width: "52px", height: "52px", borderRadius: "16px", background: "#FFC93C", border: "3px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="3.2" strokeLinecap="round" aria-hidden="true">
              <path d="M8 5v14 M16 5v14" />
            </svg>
          </div>
          <h1 id="pz-title" style={{ margin: "14px 0 0", fontSize: "26px", textAlign: "center" }}>
            {"พักแป๊บ"}
          </h1>
          <div style={{ textAlign: "center", fontSize: "14px", color: "#55557A" }}>
            {"ข้าวเหนียวมะม่วง · V4 · ตอนนี้อยู่ที่ 52%"}
          </div>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("back")}>
            {"เล่นต่อ"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "17px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/climb")}>
            {"เริ่มใหม่จากพื้น"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #E5383B", fontFamily: "inherit", fontSize: "17px", fontWeight: "700", color: "#B4232A" }} onClick={() => go("/route")}>
            {"ลงจากผนัง"}
          </button>
          <div style={{ display: "flex", justifyContent: "center", gap: "12px", paddingTop: "4px" }}>
            <button type="button" aria-label="ปิดเสียง" style={{ width: "48px", height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 9h4l5-4v14l-5-4H4z M17 9a4 4 0 0 1 0 6 M19.5 6.5a8 8 0 0 1 0 11" />
              </svg>
            </button>
            <button type="button" aria-label="ปิดการสั่น" style={{ width: "48px", height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M8 4h8v16H8z M4 8v8 M20 8v8" />
              </svg>
            </button>
            <button type="button" aria-label="วิธีเล่น" style={{ width: "48px", height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0", fontFamily: "inherit", fontSize: "20px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/tutorial")}>
              {"?"}
            </button>
          </div>
        </div>
      </div>
  );
}
