// Generated from handoff/screens/J57-Settings.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type J57SettingsProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: J57SettingsProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function J57Settings(props: J57SettingsProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"ตั้งค่า"}
          </h1>
        </div>
        <div style={{ flex: "1", minHeight: "0", padding: "14px 20px 30px", display: "flex", flexDirection: "column", gap: "6px", overflow: "hidden" }}>
          <span style={{ fontSize: "13px", fontWeight: "700", color: "#55557A" }}>
            {"เสียงและการสั่น"}
          </span>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", overflow: "hidden", flexShrink: "0" }}>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "2px solid #F1E9DC" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"เพลงประกอบ"}
              </span>
              <button type="button" role="switch" aria-checked="true" aria-label="เพลงประกอบ" style={{ width: "54px", height: "32px", borderRadius: "999px", background: "#17B2A0", border: "2.5px solid #1B1B3A", padding: "0", position: "relative" }}>
                <span style={{ position: "absolute", right: "2px", top: "2px", width: "23px", height: "23px", borderRadius: "50%", background: "#FFFFFF", border: "2px solid #1B1B3A", boxSizing: "border-box" }} />
              </button>
            </div>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "2px solid #F1E9DC" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"เสียงเอฟเฟกต์"}
              </span>
              <button type="button" role="switch" aria-checked="true" aria-label="เสียงเอฟเฟกต์" style={{ width: "54px", height: "32px", borderRadius: "999px", background: "#17B2A0", border: "2.5px solid #1B1B3A", padding: "0", position: "relative" }}>
                <span style={{ position: "absolute", right: "2px", top: "2px", width: "23px", height: "23px", borderRadius: "50%", background: "#FFFFFF", border: "2px solid #1B1B3A", boxSizing: "border-box" }} />
              </button>
            </div>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"การสั่น"}
              </span>
              <button type="button" role="switch" aria-checked="false" aria-label="การสั่น" style={{ width: "54px", height: "32px", borderRadius: "999px", background: "#EDE6DA", border: "2.5px solid #1B1B3A", padding: "0", position: "relative" }}>
                <span style={{ position: "absolute", left: "2px", top: "2px", width: "23px", height: "23px", borderRadius: "50%", background: "#FFFFFF", border: "2px solid #1B1B3A", boxSizing: "border-box" }} />
              </button>
            </div>
          </div>
          <span style={{ fontSize: "13px", fontWeight: "700", color: "#55557A", marginTop: "4px" }}>
            {"ทั่วไปและความเป็นส่วนตัว"}
          </span>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", overflow: "hidden", flexShrink: "0" }}>
            <button type="button" style={{ width: "100%", minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between", border: "none", borderBottom: "2px solid #F1E9DC", background: "none", fontFamily: "inherit", color: "#1B1B3A" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"ภาษา"}
              </span>
              <span style={{ fontSize: "14px", color: "#55557A", display: "flex", alignItems: "center", gap: "4px" }}>
                {"ไทย"}
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M9 5l7 7-7 7" />
                </svg>
              </span>
            </button>
            <button type="button" style={{ width: "100%", minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between", border: "none", borderBottom: "2px solid #F1E9DC", background: "none", fontFamily: "inherit", color: "#1B1B3A" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"ใครส่งข้อความหาได้"}
              </span>
              <span style={{ fontSize: "14px", color: "#55557A", display: "flex", alignItems: "center", gap: "4px" }}>
                {"เพื่อนเท่านั้น"}
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M9 5l7 7-7 7" />
                </svg>
              </span>
            </button>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: "15px", fontWeight: "600" }}>
                {"แสดงสถานะออนไลน์"}
              </span>
              <button type="button" role="switch" aria-checked="true" aria-label="แสดงสถานะออนไลน์" style={{ width: "54px", height: "32px", borderRadius: "999px", background: "#17B2A0", border: "2.5px solid #1B1B3A", padding: "0", position: "relative" }}>
                <span style={{ position: "absolute", right: "2px", top: "2px", width: "23px", height: "23px", borderRadius: "50%", background: "#FFFFFF", border: "2px solid #1B1B3A", boxSizing: "border-box" }} />
              </button>
            </div>
          </div>
          <span style={{ fontSize: "13px", fontWeight: "700", color: "#55557A", marginTop: "4px" }}>
            {"บัญชีที่ผูก"}
          </span>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", overflow: "hidden", flexShrink: "0" }}>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", gap: "10px", borderBottom: "2px solid #F1E9DC" }}>
              <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "8px", background: "#06C755", color: "#FFFFFF", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"L"}
              </span>
              <span style={{ flex: "1", fontSize: "15px", fontWeight: "600" }}>
                {"LINE"}
              </span>
              <span style={{ fontSize: "13px", fontWeight: "700", color: "#0B6B60" }}>
                {"ผูกแล้ว"}
              </span>
            </div>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", gap: "10px", borderBottom: "2px solid #F1E9DC" }}>
              <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "50%", border: "2px solid #1B1B3A", boxSizing: "border-box", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"G"}
              </span>
              <span style={{ flex: "1", fontSize: "15px", fontWeight: "600" }}>
                {"Google"}
              </span>
              <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/link-guest")}>
                {"ผูกบัญชี"}
              </button>
            </div>
            <div style={{ minHeight: "48px", padding: "0 14px", display: "flex", alignItems: "center", gap: "10px" }}>
              <span aria-hidden="true" style={{ width: "26px", height: "26px", borderRadius: "8px", background: "#1B1B3A", color: "#FFFFFF", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {"A"}
              </span>
              <span style={{ flex: "1", fontSize: "15px", fontWeight: "600" }}>
                {"Apple"}
              </span>
              <button type="button" style={{ height: "36px", padding: "0 12px", borderRadius: "10px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/link-guest")}>
                {"ผูกบัญชี"}
              </button>
            </div>
          </div>
          <div style={{ flex: "1" }} />
          <button type="button" style={{ height: "52px", flexShrink: "0", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "16px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/welcome")}>
            {"ออกจากระบบ"}
          </button>
          <button type="button" style={{ height: "44px", flexShrink: "0", border: "none", background: "none", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#B4232A" }} onClick={() => go("soon")}>
            {"ลบบัญชีถาวร"}
          </button>
          <div style={{ textAlign: "center", fontSize: "12px", color: "#55557A" }}>
            {"Boulder Boss เวอร์ชัน 0.1.0"}
          </div>
        </div>
      </div>
  );
}
