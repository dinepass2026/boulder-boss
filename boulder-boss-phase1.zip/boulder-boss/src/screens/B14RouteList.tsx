// Generated from handoff/screens/B14-RouteList.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import BottomNav from '../components/BottomNav';

export type B14RouteListProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B14RouteListProps, state: any, setState: (patch: any) => void): any {

const s = state || {};
const status = s.status || 'all', grade = s.grade || 'all', style = s.style || 'all';
const G = (g) => g <= 1 ? ['#3DDC84', '#1B1B3A'] : g <= 3 ? ['#5AB8FF', '#1B1B3A'] : g <= 5 ? ['#FFC93C', '#1B1B3A'] : g <= 7 ? ['#FF8A3D', '#1B1B3A'] : g <= 9 ? ['#C81D25', '#FFFFFF'] : ['#6C4CF1', '#FFFFFF'];
const data = [
{ name: 'ข้าวเหนียวมะม่วง', grade: 4, style: 'crimp', wall: 'A', stars: 4.6, st: 'project', isNew: true, hold: '#FF5F45' },
{ name: 'แตงโมหล่น', grade: 3, style: 'sloper', wall: 'B', stars: 4.2, st: 'send', isNew: false, hold: '#5AB8FF' },
{ name: 'รถติดสุขุมวิท', grade: 5, style: 'crimp', wall: 'A', stars: 4.8, st: 'none', isNew: true, hold: '#FFC93C' },
{ name: 'บันไดสวรรค์', grade: 2, style: 'slab', wall: 'C', stars: 3.9, st: 'flash', isNew: false, hold: '#3DDC84' },
{ name: 'ตุ๊กตุ๊กซิ่ง', grade: 6, style: 'dyno', wall: 'D', stars: 4.7, st: 'none', isNew: true, hold: '#6C4CF1' },
{ name: 'ชาไทยไม่หวาน', grade: 1, style: 'slab', wall: 'C', stars: 4.0, st: 'send', isNew: false, hold: '#FF8FC8' },
{ name: 'น้ำท่วมซอย', grade: 3, style: 'dyno', wall: 'B', stars: 4.4, st: 'none', isNew: false, hold: '#17B2A0' },
{ name: 'หมูกระทะ', grade: 7, style: 'sloper', wall: 'D', stars: 4.5, st: 'none', isNew: false, hold: '#FF8A3D' }
];
const inGrade = (g) => grade === 'all' || (grade === 'low' && g <= 2) || (grade === 'mid' && g >= 3 && g <= 5) || (grade === 'high' && g >= 6);
const inStatus = (x) => status === 'all' || (status === 'none' && x === 'none') || (status === 'project' && x === 'project') || (status === 'send' && (x === 'send' || x === 'flash'));
const SL = { none: ['ยังไม่ปีน', '#55557A'], project: ['PROJECT · high point 70%', '#B4232A'], send: ['SEND แล้ว', '#0B6B60'], flash: ['FLASH!', '#0B6B60'] };
const routes = data.filter((r) => inGrade(r.grade) && inStatus(r.st) && (style === 'all' || r.style === style)).map((r) => {
const c = G(r.grade);
return { ...r, style: r.style.charAt(0).toUpperCase() + r.style.slice(1), gbg: c[0], gfg: c[1], statusLabel: SL[r.st][0], statusColor: SL[r.st][1] };
});
const tab = (arr, cur, key, on, off) => arr.map(([id, label]) => ({ label, bg: id === cur ? on[0] : off[0], fg: id === cur ? on[1] : off[1], border: id === cur ? '#1B1B3A' : '#B9B2C8', pick: () => setState({ [key]: id }) }));
return {
routes, count: routes.length, empty: routes.length === 0,
statuses: tab([['all', 'ทั้งหมด'], ['none', 'ยังไม่ปีน'], ['project', 'Project'], ['send', 'Send']], status, 'status', ['#1B1B3A', '#FFFFFF'], ['transparent', '#1B1B3A']),
grades: tab([['all', 'ทุกเกรด'], ['low', 'V0–V2'], ['mid', 'V3–V5'], ['high', 'V6+']], grade, 'grade', ['#FFC93C', '#1B1B3A'], ['#FFFFFF', '#1B1B3A']),
styles: tab([['all', 'ทุกสไตล์'], ['crimp', 'Crimp'], ['slab', 'Slab'], ['dyno', 'Dyno'], ['sloper', 'Sloper']], style, 'style', ['#E3F7F4', '#1B1B3A'], ['#FFFFFF', '#1B1B3A'])
};
}

export default function B14RouteList(props: B14RouteListProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <div style={{ flex: "1" }}>
            <h1 style={{ margin: "0", fontSize: "20px" }}>
              {"รูททั้งหมด"}
            </h1>
            <div style={{ fontSize: "12px", color: "#55557A" }}>
              {"Crimp Factory ทองหล่อ"}
            </div>
          </div>
          <span style={{ fontSize: "13px", fontWeight: "700" }}>
            {v.count}{" รูท"}
          </span>
        </div>
        <div role="tablist" aria-label="สถานะ" style={{ margin: "14px 20px 0", padding: "4px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "4px" }}>
          {(v.statuses || []).map((t: any, t_i: number) => (
            <Fragment key={t_i}>
              <button className="bb-in" type="button" role="tab" onClick={t.pick} style={{ height: "40px", borderRadius: "11px", border: "none", background: t.bg, color: t.fg, fontFamily: "inherit", fontSize: "13px", fontWeight: "700", animationDelay: `${Math.min(t_i, 12) * 45}ms` }}>
                {t.label}
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ padding: "10px 20px 0", display: "flex", gap: "6px", overflow: "hidden" }}>
          {(v.grades || []).map((t: any, t_i: number) => (
            <Fragment key={t_i}>
              <button className="bb-in" type="button" onClick={t.pick} style={{ height: "44px", padding: "0 12px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: t.bg, color: t.fg, fontFamily: "inherit", fontSize: "14px", fontWeight: "600", animationDelay: `${Math.min(t_i, 12) * 45}ms` }}>
                {t.label}
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ padding: "8px 20px 0", display: "flex", gap: "6px", overflow: "hidden" }}>
          {(v.styles || []).map((t: any, t_i: number) => (
            <Fragment key={t_i}>
              <button className="bb-in" type="button" onClick={t.pick} style={{ height: "44px", padding: "0 12px", flexShrink: "0", borderRadius: "12px", border: `2px solid ${t.border}`, background: t.bg, color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", animationDelay: `${Math.min(t_i, 12) * 45}ms` }}>
                {t.label}
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ flex: "1", minHeight: "0", padding: "14px 20px 96px", display: "flex", flexDirection: "column", gap: "10px", overflow: "hidden" }}>
          {v.empty ? (
            <>
              <div style={{ padding: "32px 16px", textAlign: "center", border: "2.5px dashed #B9B2C8", borderRadius: "20px", color: "#55557A", fontSize: "15px" }}>
                {"ไม่มีรูทตรงตัวกรองนี้ ลองเปลี่ยนเกรดหรือสไตล์ดู"}
              </div>
            </>
          ) : null}
          {(v.routes || []).map((r: any, r_i: number) => (
            <Fragment key={r_i}>
              <button className="bb-in" type="button" style={{ textAlign: "left", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", boxShadow: "0 3px 0 #1B1B3A", padding: "10px 12px", display: "flex", gap: "12px", alignItems: "center", fontFamily: "inherit", color: "#1B1B3A", flexShrink: "0", animationDelay: `${Math.min(r_i, 12) * 45}ms` }} onClick={() => go("/route")}>
                <span style={{ width: "48px", height: "48px", flexShrink: "0", borderRadius: "12px", background: "#FFF7EC", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="32" height="32" viewBox="0 0 40 40" aria-hidden="true">
                    <path d="M4 26c0-10 8-18 18-18s16 6 14 14-8 12-16 12S4 34 4 26z" fill={r.hold} stroke="#1B1B3A" strokeWidth="2.5" />
                  </svg>
                </span>
                <span style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", gap: "2px" }}>
                  <span style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                    <b style={{ fontSize: "16px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {r.name}
                    </b>
                    {r.isNew ? (
                      <>
                        <span style={{ height: "20px", padding: "0 6px", borderRadius: "6px", background: "#FF5F45", border: "1.5px solid #1B1B3A", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center" }}>
                          {"NEW"}
                        </span>
                      </>
                    ) : null}
                  </span>
                  <span style={{ fontSize: "12px", color: "#55557A" }}>
                    {r.style}{" · ผนัง "}{r.wall}{" · ★ "}{r.stars}
                  </span>
                  <span style={{ fontSize: "12px", fontWeight: "700", color: r.statusColor }}>
                    {r.statusLabel}
                  </span>
                </span>
                <span style={{ minWidth: "48px", height: "34px", padding: "0 8px", boxSizing: "border-box", borderRadius: "10px", border: "2.5px solid #1B1B3A", background: r.gbg, color: r.gfg, fontWeight: "700", fontSize: "16px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  {"V"}{r.grade}
                </span>
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ position: "absolute", left: "0", bottom: "0" }}>
          <BottomNav active="gym" />
        </div>
      </div>
  );
}
