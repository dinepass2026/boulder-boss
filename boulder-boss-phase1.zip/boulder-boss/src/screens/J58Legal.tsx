// Generated from handoff/screens/J58-Legal.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type J58LegalProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: J58LegalProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function J58Legal(props: J58LegalProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ปิด" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.8" strokeLinecap="round" aria-hidden="true">
              <path d="M6 6l12 12 M18 6L6 18" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"ข้อตกลงและนโยบาย"}
          </h1>
        </div>
        <div role="tablist" style={{ margin: "14px 20px 0", padding: "4px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "4px" }}>
          <button type="button" role="tab" aria-selected="true" style={{ height: "40px", borderRadius: "11px", border: "none", background: "#1B1B3A", color: "#FFFFFF", fontFamily: "inherit", fontSize: "14px", fontWeight: "700" }}>
            {"ข้อตกลงการใช้งาน"}
          </button>
          <button type="button" role="tab" aria-selected="false" style={{ height: "40px", borderRadius: "11px", border: "none", background: "transparent", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "700" }}>
            {"นโยบายความเป็นส่วนตัว"}
          </button>
        </div>
        <div style={{ flex: "1", minHeight: "0", margin: "14px 20px 0", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", padding: "16px", display: "flex", flexDirection: "column", gap: "12px", overflow: "hidden" }}>
          <span style={{ fontSize: "12px", color: "#55557A" }}>
            {"มีผลตั้งแต่ [วันที่มีผลบังคับใช้] · ฉบับที่ [เลขฉบับ]"}
          </span>
          <div style={{ background: "#FFF1C2", border: "2px solid #1B1B3A", borderRadius: "14px", padding: "10px 12px", display: "flex", flexDirection: "column", gap: "4px" }}>
            <b style={{ fontSize: "14px" }}>
              {"สรุปสั้นๆ"}
            </b>
            <span style={{ fontSize: "13px", lineHeight: "1.5" }}>
              {"[สรุปภาษาง่าย 3–4 บรรทัดจากทีมกฎหมาย เช่น สิทธิ์ในบัญชี กติกาในชุมชน การซื้อของในเกม]"}
            </span>
          </div>
          <h2 style={{ margin: "4px 0 0", fontSize: "16px" }}>
            {"1. การยอมรับข้อตกลง"}
          </h2>
          <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.6", color: "#55557A" }}>
            {"[เนื้อหาฉบับเต็มจากทีมกฎหมาย]"}
          </p>
          <h2 style={{ margin: "4px 0 0", fontSize: "16px" }}>
            {"2. บัญชีผู้ใช้และอายุ"}
          </h2>
          <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.6", color: "#55557A" }}>
            {"[เงื่อนไขอายุขั้นต่ำ และการจำกัดแชทส่วนตัวตามอายุ]"}
          </p>
          <h2 style={{ margin: "4px 0 0", fontSize: "16px" }}>
            {"3. กติกาในชุมชน"}
          </h2>
          <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.6", color: "#55557A" }}>
            {"[พฤติกรรมที่ห้าม การรายงาน และการบล็อก]"}
          </p>
          <h2 style={{ margin: "4px 0 0", fontSize: "16px" }}>
            {"4. การซื้อในเกม (บาท)"}
          </h2>
          <p style={{ margin: "0", fontSize: "14px", lineHeight: "1.6", color: "#55557A" }}>
            {"[นโยบายการคืนเงินและเหรียญในเกม]"}
          </p>
          <h2 style={{ margin: "4px 0 0", fontSize: "16px" }}>
            {"5. การระงับและลบบัญชี"}
          </h2>
        </div>
        <div style={{ padding: "14px 20px 34px", display: "flex", flexDirection: "column", gap: "8px" }}>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("back")}>
            {"อ่านแล้ว ยอมรับ"}
          </button>
        </div>
      </div>
  );
}
