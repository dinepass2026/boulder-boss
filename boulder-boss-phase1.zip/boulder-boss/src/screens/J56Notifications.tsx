// Generated from handoff/screens/J56-Notifications.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type J56NotificationsProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: J56NotificationsProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function J56Notifications(props: J56NotificationsProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"การแจ้งเตือน"}
          </h1>
          <button type="button" style={{ minHeight: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#1B1B3A", textDecoration: "underline", padding: "0" }}>
            {"อ่านทั้งหมด"}
          </button>
        </div>
        <div style={{ flex: "1", minHeight: "0", padding: "16px 20px 30px", display: "flex", flexDirection: "column", gap: "10px", overflow: "hidden" }}>
          <span style={{ fontSize: "13px", fontWeight: "700", color: "#55557A" }}>
            {"วันนี้"}
          </span>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", boxShadow: "0 3px 0 #1B1B3A", padding: "12px", display: "flex", flexDirection: "column", gap: "10px", flexShrink: "0" }}>
            <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
              <span style={{ width: "44px", height: "44px", flexShrink: "0", borderRadius: "13px", background: "#FF8A3D", border: "2px solid #1B1B3A", overflow: "hidden", display: "flex", justifyContent: "center" }}>
                <Chibi w="56" shirt="#1B1B3A" hair="#E0A458" skin="#D9A27A" />
              </span>
              <div style={{ flex: "1", fontSize: "14px", lineHeight: "1.45" }}>
                <b>
                  {"ปีนแหลก99"}
                </b>
                {" ขอเป็นเพื่อนกับคุณ"}
                <div style={{ fontSize: "12px", color: "#55557A" }}>
                  {"5 นาทีที่แล้ว"}
                </div>
              </div>
              <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#FF5F45", border: "1.5px solid #1B1B3A", marginTop: "6px" }} aria-label="ยังไม่อ่าน" />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "8px" }}>
              <button type="button" style={{ height: "44px", borderRadius: "12px", background: "#FFC93C", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/player")}>
                {"ยอมรับ"}
              </button>
              <button type="button" style={{ height: "44px", borderRadius: "12px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }}>
                {"ไว้ก่อน"}
              </button>
            </div>
          </div>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", padding: "12px", display: "flex", gap: "10px", alignItems: "flex-start", flexShrink: "0" }}>
            <span style={{ width: "44px", height: "44px", flexShrink: "0", borderRadius: "13px", background: "#5AB8FF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 14c-1-4 2-8 6-9 4-1 8 1 8 5s-2 8-6 9-7-1-8-5z" />
              </svg>
            </span>
            <div style={{ flex: "1", fontSize: "14px", lineHeight: "1.45" }}>
              <b>
                {"มายด์ไม่ปีนไม่นอน"}
              </b>
              {" ชวนคุณปีน "}
              <b>
                {"รถติดสุขุมวิท V5"}
              </b>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"32 นาทีที่แล้ว · แตะเพื่อดูรูท"}
              </div>
            </div>
            <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#FF5F45", border: "1.5px solid #1B1B3A", marginTop: "6px" }} aria-label="ยังไม่อ่าน" />
          </div>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", padding: "12px", display: "flex", gap: "10px", alignItems: "flex-start", flexShrink: "0" }}>
            <span style={{ width: "44px", height: "44px", flexShrink: "0", borderRadius: "13px", background: "#FFC93C", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M4 12a8 8 0 0 1 14-5.3L20 9 M20 4v5h-5 M20 12a8 8 0 0 1-14 5.3L4 15 M4 20v-5h5" />
              </svg>
            </span>
            <div style={{ flex: "1", fontSize: "14px", lineHeight: "1.45" }}>
              <b>
                {"Crimp Factory"}
              </b>
              {" รีเซ็ตผนัง A แล้ว มีรูทใหม่ 8 เส้น"}
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"2 ชม. ที่แล้ว"}
              </div>
            </div>
            <span style={{ width: "10px", height: "10px", borderRadius: "50%", background: "#FF5F45", border: "1.5px solid #1B1B3A", marginTop: "6px" }} aria-label="ยังไม่อ่าน" />
          </div>
          <span style={{ fontSize: "13px", fontWeight: "700", color: "#55557A", marginTop: "4px" }}>
            {"ก่อนหน้า"}
          </span>
          <div style={{ background: "#F6F0E6", border: "2px solid #D9CFBF", borderRadius: "18px", padding: "12px", display: "flex", gap: "10px", alignItems: "flex-start", flexShrink: "0" }}>
            <span style={{ width: "44px", height: "44px", flexShrink: "0", borderRadius: "13px", background: "#1B1B3A", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FFC93C" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" />
              </svg>
            </span>
            <div style={{ flex: "1", fontSize: "14px", lineHeight: "1.45" }}>
              {"คลับ "}
              <b>
                {"Crimp Gang"}
              </b>
              {" จบสัปดาห์ที่อันดับ 3 ของสุขุมวิท"}
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"เมื่อวาน"}
              </div>
            </div>
          </div>
          <div style={{ background: "#F6F0E6", border: "2px solid #D9CFBF", borderRadius: "18px", padding: "12px", display: "flex", gap: "10px", alignItems: "flex-start", flexShrink: "0" }}>
            <span style={{ width: "44px", height: "44px", flexShrink: "0", borderRadius: "13px", background: "#17B2A0", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12l5 5 9-10" />
              </svg>
            </span>
            <div style={{ flex: "1", fontSize: "14px", lineHeight: "1.45" }}>
              {"ภารกิจรายวันครบแล้ว รับ "}
              <b>
                {"+150 เหรียญ"}
              </b>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"18 พ.ย."}
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}
