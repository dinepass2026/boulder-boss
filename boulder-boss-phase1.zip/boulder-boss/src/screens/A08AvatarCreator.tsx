// Generated from handoff/screens/A08-AvatarCreator.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type A08AvatarCreatorProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A08AvatarCreatorProps, state: any, setState: (patch: any) => void): any {

const s = state || {};
const look = { skin: s.skin || '#F5C6A0', hair: s.hair || '#2D2346', shirt: s.shirt || '#FF5F45', shoes: s.shoes || '#FFC93C', bag: s.bag || '#17B2A0' };
const tab = s.tab || 'shirt';
const P = {
skin: ['#FFE0C2', '#F5C6A0', '#E8B48A', '#D9A27A', '#B57D56', '#9C6644', '#7A4E30', '#5C3A22', '#FFD4C2', '#EFC0A0'],
hair: ['#1B1B3A', '#2D2346', '#6B3E26', '#A0522D', '#E0A458', '#F2D16B', '#FF5F45', '#6C4CF1', '#17B2A0', '#FF8FC8'],
shirt: ['#FF5F45', '#FFC93C', '#17B2A0', '#5AB8FF', '#6C4CF1', '#3DDC84', '#FF8A3D', '#FFFFFF', '#1B1B3A', '#FF8FC8'],
shoes: ['#FFC93C', '#FF5F45', '#1B1B3A', '#FFFFFF', '#5AB8FF', '#3DDC84', '#6C4CF1', '#FF8A3D', '#17B2A0', '#B9B2C8'],
bag: ['#17B2A0', '#FFC93C', '#FF5F45', '#5AB8FF', '#6C4CF1', '#1B1B3A', '#FFFFFF', '#3DDC84', '#FF8A3D', '#FF8FC8']
};
const labels = { skin: 'สีผิว', hair: 'ผม', shirt: 'ชุด', shoes: 'รองเท้า', bag: 'ถุงชอล์ก' };
const poses = ['stand', 'wave', 'cheer', 'climb'];
const poseTh = { stand: 'ยืน', wave: 'โบกมือ', cheer: 'เชียร์', climb: 'ปีน' };
const pose = s.pose || 'wave';
return {
...look, pose, poseLabel: poseTh[pose],
flip: s.flip ? 'scaleX(-1)' : 'none',
turn: () => setState({ flip: !s.flip }),
cyclePose: () => setState({ pose: poses[(poses.indexOf(pose) + 1) % poses.length] }),
shuffle: () => { const r = (a) => a[Math.floor(Math.random() * a.length)]; setState({ skin: r(P.skin), hair: r(P.hair), shirt: r(P.shirt), shoes: r(P.shoes), bag: r(P.bag) }); },
tabs: Object.keys(labels).map((k) => ({ label: labels[k], bg: k === tab ? '#1B1B3A' : '#FFFFFF', fg: k === tab ? '#FFFFFF' : '#1B1B3A', pick: () => setState({ tab: k }) })),
options: P[tab].map((c, i) => ({ color: c, label: labels[tab] + ' แบบที่ ' + (i + 1), ring: look[tab] === c ? 5 : 0, pick: () => setState({ [tab]: c }) }))
};
}

export default function A08AvatarCreator(props: A08AvatarCreatorProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <div style={{ flex: "1", display: "flex", flexDirection: "column", gap: "6px" }}>
            <span style={{ fontSize: "13px", fontWeight: "600", color: "#55557A" }}>
              {"ขั้นที่ 2 จาก 2 · สร้างตัวละคร"}
            </span>
            <div style={{ height: "10px", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFC93C" }} />
          </div>
          <button type="button" onClick={v.shuffle} aria-label="สุ่มลุค" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M3 7h4l10 10h4 M3 17h4l3-3 M14 10l3-3h4 M18 4l3 3-3 3 M18 14l3 3-3 3" />
            </svg>
          </button>
        </div>
        <div style={{ margin: "16px 20px 0", height: "300px", borderRadius: "28px", border: "2.5px solid #1B1B3A", background: "#5AB8FF", position: "relative", overflow: "hidden" }}>
          <svg width="100%" height="100%" viewBox="0 0 346 300" preserveAspectRatio="none" style={{ position: "absolute", inset: "0" }} aria-hidden="true">
            <g fill="#4AA4EA">
              <circle cx="40" cy="40" r="10" />
              <circle cx="300" cy="70" r="14" />
              <circle cx="80" cy="150" r="8" />
              <circle cx="270" cy="170" r="9" />
            </g>
            <ellipse cx="173" cy="270" rx="120" ry="24" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2.5" />
          </svg>
          <div style={{ position: "absolute", left: "0", right: "0", bottom: "34px", display: "flex", justifyContent: "center", transform: v.flip }}>
            <Chibi pose={v.pose} w="168" skin={v.skin} hair={v.hair} shirt={v.shirt} shoes={v.shoes} bag={v.bag} pants="#2D2346" />
          </div>
          <button type="button" onClick={v.turn} aria-label="หมุนซ้าย" style={{ position: "absolute", left: "12px", top: "124px", width: "44px", height: "44px", borderRadius: "50%", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <button type="button" onClick={v.turn} aria-label="หมุนขวา" style={{ position: "absolute", right: "12px", top: "124px", width: "44px", height: "44px", borderRadius: "50%", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M9 5l7 7-7 7" />
            </svg>
          </button>
          <button type="button" onClick={v.cyclePose} style={{ position: "absolute", left: "12px", top: "12px", height: "36px", padding: "0 12px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "13px", fontWeight: "700", color: "#1B1B3A" }}>
            {"ท่า: "}{v.poseLabel}
          </button>
        </div>
        <div role="tablist" aria-label="หมวดแต่งตัว" style={{ padding: "16px 20px 0", display: "flex", gap: "6px", overflow: "hidden" }}>
          {(v.tabs || []).map((t: any, t_i: number) => (
            <Fragment key={t_i}>
              <button className="bb-in" type="button" role="tab" onClick={t.pick} style={{ height: "44px", padding: "0 12px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: t.bg, color: t.fg, fontFamily: "inherit", fontSize: "14px", fontWeight: "600", animationDelay: `${Math.min(t_i, 12) * 45}ms` }}>
                {t.label}
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ margin: "14px 20px 0", padding: "16px", borderRadius: "20px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "grid", gridTemplateColumns: "repeat(5, minmax(0, 1fr))", gap: "12px", justifyItems: "center" }}>
          {(v.options || []).map((o: any, o_i: number) => (
            <Fragment key={o_i}>
              <button className="bb-in" type="button" onClick={o.pick} aria-label={o.label} style={{ width: "52px", height: "52px", borderRadius: "50%", padding: "0", background: o.color, border: "2.5px solid #1B1B3A", boxShadow: `0 0 0 ${o.ring}px #FFC93C`, animationDelay: `${Math.min(o_i, 12) * 45}ms` }} />
            </Fragment>
          ))}
        </div>
        <div style={{ flex: "1" }} />
        <div style={{ padding: "0 24px 34px" }}>
          <button type="button" style={{ width: "100%", height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/tutorial")}>
            {"เสร็จแล้ว ไปปีนกัน!"}
          </button>
        </div>
      </div>
  );
}
