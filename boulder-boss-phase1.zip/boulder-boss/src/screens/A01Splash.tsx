// Generated from handoff/screens/A01-Splash.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Skyline from '../components/Skyline';

export type A01SplashProps = { time?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A01SplashProps, state: any, setState: (patch: any) => void): any {
 return { time: props.time ?? 'auto' };
}

export default function A01Splash(props: A01SplashProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#0C1433" }}>
        <div style={{ position: "absolute", inset: "0" }}>
          <Skyline time={v.time} w="390" h="844" />
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "150px", display: "flex", flexDirection: "column", alignItems: "center", gap: "18px" }}>
          <div className="bb-logo" style={{ width: "120px", height: "120px", borderRadius: "32px", background: "#FFC93C", border: "3px solid #1B1B3A", boxShadow: "0 6px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", transform: "rotate(-6deg)" }}>
            <svg width="78" height="78" viewBox="0 0 56 56" aria-hidden="true">
              <path d="M10 40c-3-10 4-22 15-25 11-3 22 3 22 13s-6 19-17 21S13 50 10 40z" fill="#FF5F45" stroke="#1B1B3A" strokeWidth="3" />
              <circle cx="28" cy="31" r="4" fill="#1B1B3A" />
            </svg>
          </div>
          <div className="bb-stamp" style={{ background: "#FFFFFF", border: "3px solid #1B1B3A", boxShadow: "0 6px 0 #1B1B3A", borderRadius: "20px", padding: "10px 22px", textAlign: "center" }}>
            <div style={{ fontSize: "36px", fontWeight: "700", lineHeight: "1.05", letterSpacing: "1px" }}>
              {"BOULDER BOSS"}
            </div>
            <div style={{ fontSize: "18px", fontWeight: "700", color: "#FF5F45", marginTop: "2px" }}>
              {"ยิมปีนผา"}
            </div>
          </div>
        </div>
        <div style={{ position: "absolute", left: "32px", right: "32px", bottom: "56px", display: "flex", flexDirection: "column", gap: "10px", background: "#1B1B3A", borderRadius: "20px", padding: "16px 18px", boxShadow: "0 4px 0 rgba(0,0,0,0.25)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "14px", fontWeight: "600", color: "#FFFFFF" }}>
            <span>
              {"กำลังลงชอล์ก..."}
            </span>
            <span>
              {"68%"}
            </span>
          </div>
          <div style={{ height: "18px", borderRadius: "999px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", overflow: "hidden" }}>
            <div className="bb-load" style={{ width: "68%", height: "100%", background: "#FFC93C", borderRight: "2.5px solid #1B1B3A" }} />
          </div>
          <div style={{ fontSize: "12px", textAlign: "center", marginTop: "2px", color: "#D8D6EA" }}>
            {"เวอร์ชัน 0.1.0"}
          </div>
        </div>
      </div>
  );
}
