// Generated from handoff/screens/B11-MapHome.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import BottomNav from '../components/BottomNav';
import Chibi from '../components/Chibi';

export type B11MapHomeProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B11MapHomeProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function B11MapHome(props: B11MapHomeProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFEFD0" }}>
        <svg width="390" height="844" viewBox="0 0 390 844" style={{ position: "absolute", inset: "0" }} aria-hidden="true">
          <rect width="390" height="844" fill="#FFEFD0" />
          <g stroke="#FFFFFF" strokeWidth="10" strokeLinecap="round" fill="none">
            <path d="M0 300H390" />
            <path d="M200 0V844" />
            <path d="M0 560L390 470" />
            <path d="M120 0L330 844" />
            <path d="M390 200L180 420" />
          </g>
          <g stroke="#F5DDB0" strokeWidth="4" fill="none">
            <path d="M0 420H390 M60 0V844 M300 0V844 M0 160H390 M0 680H390" />
          </g>
          <path d="M60 -10C110 120 20 200 90 300S40 460 120 540 60 700 140 860" fill="none" stroke="#5AB8FF" strokeWidth="44" strokeLinecap="round" />
          <path d="M60 -10C110 120 20 200 90 300S40 460 120 540 60 700 140 860" fill="none" stroke="#1B1B3A" strokeWidth="48" strokeLinecap="round" opacity="0.12" />
          <path d="M60 -10C110 120 20 200 90 300S40 460 120 540 60 700 140 860" fill="none" stroke="#5AB8FF" strokeWidth="42" strokeLinecap="round" />
          <rect x="212" y="300" width="64" height="44" rx="14" fill="#A6E3A1" stroke="#1B1B3A" strokeWidth="2" />
          <rect x="150" y="150" width="40" height="30" rx="10" fill="#A6E3A1" stroke="#1B1B3A" strokeWidth="2" />
          <g fill="#FFFFFF" stroke="#1B1B3A" strokeWidth="2">
            <rect x="230" y="420" width="18" height="24" rx="3" />
            <rect x="252" y="412" width="14" height="32" rx="3" />
            <rect x="170" y="240" width="16" height="20" rx="3" />
            <rect x="300" y="250" width="18" height="18" rx="3" />
          </g>
        </svg>
        <div style={{ position: "absolute", left: "16px", right: "16px", top: "50px", display: "flex", alignItems: "center", gap: "8px" }}>
          <button type="button" aria-label="โปรไฟล์ของฉัน" style={{ flex: "1", minWidth: "0", height: "52px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", gap: "8px", padding: "0 10px 0 4px", fontFamily: "inherit" }} onClick={() => go("/profile")}>
            <span style={{ width: "42px", height: "42px", borderRadius: "12px", background: "#5AB8FF", overflow: "hidden", display: "flex", justifyContent: "center", alignItems: "flex-start" }}>
              <Chibi w="54" />
            </span>
            <span style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", minWidth: "0" }}>
              <b style={{ fontSize: "15px", color: "#1B1B3A" }}>
                {"น้องชอล์ก"}
              </b>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"Lv.12"}
              </span>
            </span>
            <span style={{ marginLeft: "auto", minWidth: "40px", height: "30px", borderRadius: "9px", border: "2.5px solid #1B1B3A", background: "#5AB8FF", fontWeight: "700", fontSize: "15px", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"V3"}
            </span>
          </button>
          <div style={{ height: "52px", padding: "0 12px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", gap: "6px", boxSizing: "border-box" }}>
            <svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="12" cy="12" r="10" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2" />
              <path d="M9.5 7.5h3.5a2 2 0 0 1 0 4H9.5h4a2 2 0 0 1 0 4H9.5z M11 6v1.5 M11 15.5V17" fill="none" stroke="#1B1B3A" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
            <b style={{ fontSize: "16px" }}>
              {"1,250"}
            </b>
          </div>
          <button type="button" aria-label="การแจ้งเตือน 3 รายการใหม่" style={{ position: "relative", width: "52px", height: "52px", borderRadius: "16px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("/notifications")}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z M10 21h4" />
            </svg>
            <span className="bb-badge" style={{ position: "absolute", top: "-6px", right: "-6px", minWidth: "22px", height: "22px", borderRadius: "999px", background: "#FF5F45", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"3"}
            </span>
          </button>
        </div>
        <button type="button" style={{ position: "absolute", left: "132px", top: "136px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", border: "none", background: "none", padding: "0", fontFamily: "inherit" }} onClick={() => go("/zone")}>
          <span style={{ height: "40px", padding: "0 14px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontSize: "16px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center" }}>
            {"อารีย์"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px", display: "flex", alignItems: "center", gap: "4px" }}>
            <span className="bb-live" style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#17B2A0" }} />
            {"128 ออนไลน์"}
          </span>
        </button>
        <div style={{ position: "absolute", left: "252px", top: "180px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
          <span style={{ height: "40px", padding: "0 12px", borderRadius: "14px", background: "#EDE6DA", border: "2.5px dashed #6B6680", fontSize: "15px", fontWeight: "700", color: "#55557A", display: "flex", alignItems: "center", gap: "6px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 11h12v10H6z M8 11V8a4 4 0 0 1 8 0v3" />
            </svg>
            {"ลาดพร้าว"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#55557A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px" }}>
            {"ปลดล็อกที่ V5"}
          </span>
        </div>
        <button type="button" style={{ position: "absolute", left: "150px", top: "262px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", border: "none", background: "none", padding: "0", fontFamily: "inherit" }} onClick={() => go("/zone")}>
          <span style={{ height: "40px", padding: "0 14px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontSize: "16px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center" }}>
            {"สยาม"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px", display: "flex", alignItems: "center", gap: "4px" }}>
            <span className="bb-live" style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#17B2A0" }} />
            {"214 ออนไลน์"}
          </span>
        </button>
        <button type="button" style={{ position: "absolute", left: "14px", top: "352px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", border: "none", background: "none", padding: "0", fontFamily: "inherit" }} onClick={() => go("/zone")}>
          <span style={{ height: "40px", padding: "0 12px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontSize: "15px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center" }}>
            {"ริมเจ้าพระยา"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px", display: "flex", alignItems: "center", gap: "4px" }}>
            <span className="bb-live" style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#17B2A0" }} />
            {"86 ออนไลน์"}
          </span>
        </button>
        <button type="button" style={{ position: "absolute", left: "200px", top: "360px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", border: "none", background: "none", padding: "0", fontFamily: "inherit" }} onClick={() => go("/zone")}>
          <span className="bb-bob" style={{ fontSize: "12px", fontWeight: "700", color: "#FFFFFF", background: "#1B1B3A", borderRadius: "6px", padding: "2px 8px" }}>
            {"คุณอยู่ที่นี่"}
          </span>
          <span className="bb-pin" style={{ height: "48px", padding: "0 16px", borderRadius: "16px", background: "#FFC93C", border: "3px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontSize: "18px", fontWeight: "700", color: "#1B1B3A", display: "flex", alignItems: "center" }}>
            {"สุขุมวิท"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px", display: "flex", alignItems: "center", gap: "4px" }}>
            <span className="bb-live" style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#17B2A0" }} />
            {"342 ออนไลน์"}
          </span>
        </button>
        <div style={{ position: "absolute", left: "40px", top: "486px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
          <span style={{ height: "40px", padding: "0 12px", borderRadius: "14px", background: "#EDE6DA", border: "2.5px dashed #6B6680", fontSize: "15px", fontWeight: "700", color: "#55557A", display: "flex", alignItems: "center", gap: "6px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 11h12v10H6z M8 11V8a4 4 0 0 1 8 0v3" />
            </svg>
            {"เยาวราช"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#55557A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px" }}>
            {"Send V3 ครบ 10 เส้น"}
          </span>
        </div>
        <div style={{ position: "absolute", left: "262px", top: "520px", display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
          <span style={{ height: "40px", padding: "0 12px", borderRadius: "14px", background: "#EDE6DA", border: "2.5px dashed #6B6680", fontSize: "15px", fontWeight: "700", color: "#55557A", display: "flex", alignItems: "center", gap: "6px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#55557A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 11h12v10H6z M8 11V8a4 4 0 0 1 8 0v3" />
            </svg>
            {"บางนา"}
          </span>
          <span style={{ fontSize: "12px", fontWeight: "600", color: "#55557A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px" }}>
            {"ปลดล็อกที่ V6"}
          </span>
        </div>
        <div style={{ position: "absolute", left: "16px", right: "16px", bottom: "98px", display: "grid", gridTemplateColumns: "1.45fr 1fr", gap: "10px" }}>
          <button type="button" style={{ textAlign: "left", background: "#1B1B3A", color: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #FFC93C", padding: "12px 14px", display: "flex", flexDirection: "column", gap: "8px", fontFamily: "inherit" }} onClick={() => go("soon")}>
            <span style={{ display: "flex", justifyContent: "space-between", width: "100%", fontSize: "15px", fontWeight: "700" }}>
              <span>
                {"ภารกิจรายวัน"}
              </span>
              <span style={{ color: "#FFC93C" }}>
                {"2/3"}
              </span>
            </span>
            <span style={{ display: "block", width: "100%", height: "10px", borderRadius: "999px", background: "#3A3A60", overflow: "hidden" }}>
              <span className="bb-fill" style={{ display: "block", width: "66%", height: "100%", background: "#FFC93C" }} />
            </span>
            <span style={{ fontSize: "12px", color: "#D8D6EA" }}>
              {"Send รูท V3+ อีก 1 เส้น · +50 เหรียญ"}
            </span>
          </button>
          <div style={{ background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "12px", display: "flex", flexDirection: "column", gap: "2px" }}>
            <span style={{ fontSize: "12px", fontWeight: "600", color: "#55557A" }}>
              {"ผนังรีเซ็ตใน"}
            </span>
            <b style={{ fontSize: "22px", fontVariantNumeric: "tabular-nums" }}>
              {"2ว 14:20"}
            </b>
          </div>
        </div>
        <div style={{ position: "absolute", left: "0", bottom: "0" }}>
          <BottomNav active="map" />
        </div>
      </div>
  );
}
