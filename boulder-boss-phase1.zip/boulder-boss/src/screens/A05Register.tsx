// Generated from handoff/screens/A05-Register.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type A05RegisterProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A05RegisterProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A05Register(props: A05RegisterProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", fontSize: "20px", fontWeight: "700" }}>
            {"สมัครสมาชิก"}
          </h1>
        </div>
        <div style={{ padding: "20px 24px 0" }}>
          <h2 style={{ margin: "0", fontSize: "26px" }}>
            {"สร้างบัญชีนักปีน"}
          </h2>
        </div>
        <form style={{ padding: "20px 24px 0", display: "flex", flexDirection: "column", gap: "12px" }}>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"อีเมล\n"}
            <input type="email" defaultValue="chalk.nong@email.com" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"รหัสผ่าน\n"}
            <input type="password" defaultValue="climbing123" style={{ height: "52px", boxSizing: "border-box", border: "2px solid #1B1B3A", borderRadius: "14px", background: "#FFFFFF", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
            <span style={{ fontSize: "12px", fontWeight: "500", color: "#55557A" }}>
              {"อย่างน้อย 8 ตัวอักษร มีตัวเลขอย่างน้อย 1 ตัว"}
            </span>
          </label>
          <label style={{ display: "flex", flexDirection: "column", gap: "6px", fontSize: "14px", fontWeight: "600" }}>
            {"ยืนยันรหัสผ่าน\n"}
            <input type="password" defaultValue="climbing12" style={{ height: "52px", boxSizing: "border-box", border: "2.5px solid #E5383B", borderRadius: "14px", background: "#FFF1EE", padding: "0 16px", fontFamily: "inherit", fontSize: "16px", color: "#1B1B3A" }} />
            <span style={{ fontSize: "12px", fontWeight: "600", color: "#B4232A" }}>
              {"รหัสผ่านไม่ตรงกัน"}
            </span>
          </label>
          <label style={{ display: "flex", alignItems: "flex-start", gap: "12px", fontSize: "14px", lineHeight: "1.5", color: "#55557A", minHeight: "44px" }}>
            <input type="checkbox" defaultChecked style={{ width: "24px", height: "24px", margin: "0", accentColor: "#1B1B3A", flexShrink: "0" }} />
            <span>
              {"ฉันยอมรับ "}
              <a href="J58-Legal.dc.html" style={{ color: "#1B1B3A", fontWeight: "700" }} onClick={() => go("/legal")}>
                {"ข้อตกลงการใช้งาน"}
              </a>
              {" และ "}
              <a href="J58-Legal.dc.html" style={{ color: "#1B1B3A", fontWeight: "700" }} onClick={() => go("/legal")}>
                {"นโยบายความเป็นส่วนตัว"}
              </a>
            </span>
          </label>
          <button type="submit" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/verify")}>
            {"สมัครสมาชิก"}
          </button>
        </form>
        <div style={{ padding: "18px 24px 0", display: "flex", alignItems: "center", gap: "12px", fontSize: "13px", color: "#55557A" }}>
          <span style={{ flex: "1", height: "2px", background: "#E9DFCF" }} />
          {"หรือสมัครด้วย"}
          <span style={{ flex: "1", height: "2px", background: "#E9DFCF" }} />
        </div>
        <div style={{ padding: "14px 24px 0", display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "10px" }}>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/player-info")}>
            <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "7px", background: "#06C755", color: "#FFFFFF", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"L"}
            </span>
            {"LINE"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/player-info")}>
            <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "50%", border: "2px solid #1B1B3A", boxSizing: "border-box", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"G"}
            </span>
            {"Google"}
          </button>
          <button type="button" style={{ height: "52px", borderRadius: "14px", background: "#1B1B3A", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }} onClick={() => go("/player-info")}>
            <span aria-hidden="true" style={{ width: "22px", height: "22px", borderRadius: "7px", background: "#FFFFFF", color: "#1B1B3A", fontSize: "11px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center" }}>
              {"A"}
            </span>
            {"Apple"}
          </button>
        </div>
        <div style={{ flex: "1" }} />
        <p style={{ margin: "0", padding: "0 24px 34px", textAlign: "center", fontSize: "15px", color: "#55557A" }}>
          {"มีบัญชีแล้ว? "}
          <a href="A03-Login.dc.html" style={{ color: "#1B1B3A", fontWeight: "700" }} onClick={() => go("/login")}>
            {"เข้าสู่ระบบ"}
          </a>
        </p>
      </div>
  );
}
