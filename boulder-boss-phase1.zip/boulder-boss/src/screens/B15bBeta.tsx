// Generated from handoff/screens/B15b-Beta.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Wall from '../components/Wall';

export type B15bBetaProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B15bBetaProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function B15bBeta(props: B15bBetaProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#1B1B3A" }}>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "470px", overflow: "hidden" }}>
          <div style={{ position: "absolute", left: "0", top: "-100px" }}>
            <Wall mode="climb" climberTop="250" />
          </div>
          <svg width="390" height="470" viewBox="0 0 390 470" style={{ position: "absolute", inset: "0" }} aria-hidden="true">
            <path d="M196 460C180 400 150 380 168 300S250 220 250 200 196 140 190 140" fill="none" stroke="#FFFFFF" strokeWidth="4" strokeDasharray="3 9" strokeLinecap="round" />
          </svg>
          <div style={{ position: "absolute", left: "20px", right: "20px", top: "52px", display: "flex", justifyContent: "space-between" }}>
            <button type="button" aria-label="ปิด" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.8" strokeLinecap="round" aria-hidden="true">
                <path d="M6 6l12 12 M18 6L6 18" />
              </svg>
            </button>
            <span style={{ height: "36px", padding: "0 12px", borderRadius: "12px", background: "#1B1B3A", color: "#FFFFFF", fontSize: "13px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"Beta 1/12 · ข้าวเหนียวมะม่วง V4"}
            </span>
          </div>
          <button className="bb-breathe" type="button" aria-label="เล่นคลิป" style={{ position: "absolute", left: "159px", top: "200px", width: "72px", height: "72px", borderRadius: "50%", background: "#FFC93C", border: "3px solid #1B1B3A", boxShadow: "0 5px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }}>
            <svg width="30" height="30" viewBox="0 0 24 24" fill="#1B1B3A" aria-hidden="true">
              <path d="M7 4l13 8-13 8z" />
            </svg>
          </button>
          <div style={{ position: "absolute", left: "16px", right: "16px", bottom: "14px", display: "flex", alignItems: "center", gap: "10px" }}>
            <span style={{ fontSize: "12px", fontWeight: "700", color: "#1B1B3A", background: "#FFFFFF", borderRadius: "6px", padding: "0 6px" }}>
              {"0:14 / 0:38"}
            </span>
            <div style={{ flex: "1", height: "10px", borderRadius: "999px", background: "#FFFFFF", border: "2px solid #1B1B3A", overflow: "hidden" }}>
              <div className="bb-fill" style={{ width: "37%", height: "100%", background: "#FF5F45" }} />
            </div>
            <button type="button" style={{ height: "32px", padding: "0 8px", borderRadius: "8px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontFamily: "inherit", fontSize: "12px", fontWeight: "700", color: "#1B1B3A" }}>
              {"0.5×"}
            </button>
          </div>
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", top: "458px", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "24px 24px 0 0", padding: "18px 20px 30px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <span style={{ width: "44px", height: "44px", borderRadius: "13px", background: "#FF8A3D", border: "2px solid #1B1B3A", overflow: "hidden", display: "flex", justifyContent: "center" }}>
              <Chibi w="56" shirt="#1B1B3A" hair="#E0A458" skin="#D9A27A" />
            </span>
            <div style={{ flex: "1" }}>
              <b style={{ fontSize: "15px" }}>
                {"ปีนแหลก99"}
              </b>
              <div style={{ fontSize: "12px", color: "#55557A" }}>
                {"V6 · Flash รูทนี้ · 2 วันก่อน"}
              </div>
            </div>
            <button type="button" aria-label="ถูกใจ 128" style={{ height: "44px", padding: "0 12px", borderRadius: "14px", background: "#FFFFFF", border: "2px solid #1B1B3A", display: "flex", alignItems: "center", gap: "6px", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#1B1B3A" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="#FF5F45" stroke="#1B1B3A" strokeWidth="2" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" />
              </svg>
              {"128"}
            </button>
          </div>
          <div style={{ background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "14px", padding: "10px 12px", fontSize: "14px", lineHeight: "1.5" }}>
            {"\"hold ที่ 6 อย่าจับตรงๆ ใช้ pinch แล้ว drop knee ซ้าย ประหยัด grip มาก\""}
          </div>
          <b style={{ fontSize: "15px" }}>
            {"Beta อื่นๆ"}
          </b>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "8px" }}>
            <button type="button" style={{ height: "120px", borderRadius: "14px", background: "#F3D9A8", border: "2.5px solid #1B1B3A", position: "relative", padding: "0", fontFamily: "inherit", overflow: "hidden" }}>
              <span style={{ position: "absolute", left: "6px", bottom: "6px", right: "6px", fontSize: "11px", fontWeight: "700", color: "#FFFFFF", background: "#1B1B3A", borderRadius: "6px", padding: "2px 4px" }}>
                {"มายด์ · 0:42"}
              </span>
            </button>
            <button type="button" style={{ height: "120px", borderRadius: "14px", background: "#EBCB93", border: "2.5px solid #1B1B3A", position: "relative", padding: "0", fontFamily: "inherit", overflow: "hidden" }}>
              <span style={{ position: "absolute", left: "6px", bottom: "6px", right: "6px", fontSize: "11px", fontWeight: "700", color: "#FFFFFF", background: "#1B1B3A", borderRadius: "6px", padding: "2px 4px" }}>
                {"โค้ชเต้ย · 0:29"}
              </span>
            </button>
            <button type="button" style={{ height: "120px", borderRadius: "14px", background: "#E5C185", border: "2.5px solid #1B1B3A", position: "relative", padding: "0", fontFamily: "inherit", overflow: "hidden" }}>
              <span style={{ position: "absolute", left: "6px", bottom: "6px", right: "6px", fontSize: "11px", fontWeight: "700", color: "#FFFFFF", background: "#1B1B3A", borderRadius: "6px", padding: "2px 4px" }}>
                {"พี่หมี · 0:51"}
              </span>
            </button>
          </div>
        </div>
      </div>
  );
}
