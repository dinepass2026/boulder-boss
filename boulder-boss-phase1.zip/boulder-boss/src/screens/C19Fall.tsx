// Generated from handoff/screens/C19-Fall.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Wall from '../components/Wall';

export type C19FallProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: C19FallProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function C19Fall(props: C19FallProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div className="bb-shake" style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#1B1B3A" }}>
        <div style={{ position: "absolute", left: "0", top: "-60px" }}>
          <Wall mode="plain" />
        </div>
        <div className="bb-flash-red" style={{ position: "absolute", left: "0", right: "0", top: "0", height: "560px", background: "rgba(229,56,59,0.18)" }} />
        <div className="bb-tumble" style={{ position: "absolute", left: "130px", top: "380px" }}>
          <Chibi pose="fall" w="120" band="#FFC93C" />
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "96px", display: "flex", justifyContent: "center" }}>
          <span className="bb-drop" style={{ fontSize: "72px", fontWeight: "700", color: "#FFFFFF", WebkitTextStroke: "3px #1B1B3A", textShadow: "0 6px 0 #1B1B3A", transform: "rotate(-6deg)", letterSpacing: "2px" }}>
            {"ตก!"}
          </span>
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "20px 20px 34px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontSize: "13px", color: "#55557A" }}>
                {"ข้าวเหนียวมะม่วง · V4"}
              </div>
              <h1 style={{ margin: "0", fontSize: "24px" }}>
                {"High point ใหม่ 74%"}
              </h1>
            </div>
            <span style={{ height: "32px", padding: "0 10px", borderRadius: "10px", background: "#3DDC84", border: "2.5px solid #1B1B3A", fontSize: "14px", fontWeight: "700", display: "flex", alignItems: "center" }}>
              {"+4%"}
            </span>
          </div>
          <div style={{ position: "relative", height: "20px", borderRadius: "999px", border: "2.5px solid #1B1B3A", background: "#FFFFFF", overflow: "hidden" }}>
            <div className="bb-fill" style={{ position: "absolute", left: "0", top: "0", bottom: "0", width: "74%", background: "#FF5F45" }} />
            <div className="bb-fill" style={{ position: "absolute", left: "0", top: "0", bottom: "0", width: "70%", background: "#FF8A73" }} />
            <div style={{ position: "absolute", left: "70%", top: "0", bottom: "0", width: "3px", background: "#1B1B3A" }} />
          </div>
          <div style={{ display: "flex", gap: "10px", background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "16px", padding: "10px 12px", alignItems: "flex-start" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flexShrink: "0", marginTop: "2px" }}>
              <path d="M9 18h6 M10 21h4 M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z" />
            </svg>
            <span style={{ fontSize: "14px", lineHeight: "1.5" }}>
              {"Grip หมดตอนจับ Sloper — ลองลงชอล์กก่อนถึง hold ที่ 8"}
            </span>
          </div>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/climb")}>
            {"ลองใหม่"}
          </button>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: "10px" }}>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/beta")}>
              {"ดู beta"}
            </button>
            <button type="button" style={{ height: "48px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", fontFamily: "inherit", fontSize: "15px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/routes")}>
              {"กลับไปรายการรูท"}
            </button>
          </div>
        </div>
      </div>
  );
}
