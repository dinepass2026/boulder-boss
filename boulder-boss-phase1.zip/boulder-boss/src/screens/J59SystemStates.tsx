// Generated from handoff/screens/J59-SystemStates.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Skyline from '../components/Skyline';

export type J59SystemStatesProps = { state?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: J59SystemStatesProps, state: any, setState: (patch: any) => void): any {

const s = props.state ?? 'offline';
return {
offline: { time: 'night', pose: 'fall', iconBg: '#5AB8FF', icon: 'M2 8.5a15 15 0 0 1 20 0 M5 12a10 10 0 0 1 14 0 M8.5 15.5a5 5 0 0 1 7 0 M12 19h.01 M3 3l18 18', tag: 'ไม่มีอินเทอร์เน็ต', title: 'สัญญาณหลุดจากผนัง', body: 'ต่ออินเทอร์เน็ตไม่ได้ ความคืบหน้าล่าสุดถูกเก็บไว้ในเครื่องแล้ว จะซิงก์ให้อัตโนมัติเมื่อกลับมาออนไลน์', detail: 'บันทึกล่าสุด: ข้าวเหนียวมะม่วง high point 74%', cta: 'ลองเชื่อมต่ออีกครั้ง', cta2: 'เล่น Tutorial แบบออฟไลน์' },
maintenance: { time: 'dawn', pose: 'stand', iconBg: '#FFC93C', icon: 'M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z', tag: 'ปิดปรับปรุง', title: 'ทีมงานกำลังเปลี่ยน hold ใหม่', body: 'ปิดปรับปรุงระบบชั่วคราว ผนังทุกยิมจะกลับมาพร้อมรูทชุดใหม่', detail: 'คาดว่าเปิดอีกครั้ง: [วันที่] เวลา [เวลา] น.', cta: 'ติดตามข่าวสาร', cta2: 'ตรวจสอบอีกครั้ง' },
update: { time: 'day', pose: 'cheer', iconBg: '#3DDC84', icon: 'M12 3v12 M7 10l5 5 5-5 M5 21h14', tag: 'มีเวอร์ชันใหม่', title: 'อัปเดตก่อนปีนต่อ', body: 'เวอร์ชันนี้เก่าเกินไปจนเชื่อมต่อเซิร์ฟเวอร์ไม่ได้ อัปเดตเพื่อเล่นต่อ ข้อมูลในบัญชีไม่หาย', detail: 'เวอร์ชันของคุณ 0.1.0 → ล่าสุด [เลขเวอร์ชัน]', cta: 'อัปเดตตอนนี้', cta2: 'ดูมีอะไรใหม่' }
}[s];
}

export default function J59SystemStates(props: J59SystemStatesProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ position: "relative", height: "420px", flexShrink: "0" }}>
          <Skyline time={v.time} w="390" h="420" />
          <div style={{ position: "absolute", left: "0", right: "0", bottom: "8px", display: "flex", justifyContent: "center", alignItems: "flex-end", gap: "10px" }}>
            <Chibi pose={v.pose} w="130" band="#FFC93C" />
          </div>
          <div style={{ position: "absolute", left: "50%", top: "110px", marginLeft: "-44px", width: "88px", height: "88px", borderRadius: "26px", background: v.iconBg, border: "3px solid #1B1B3A", boxShadow: "0 5px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d={v.icon} />
            </svg>
          </div>
        </div>
        <div style={{ flex: "1", marginTop: "-24px", position: "relative", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "28px 24px 34px", display: "flex", flexDirection: "column", gap: "12px" }}>
          <span style={{ alignSelf: "flex-start", height: "26px", padding: "0 10px", borderRadius: "8px", background: v.iconBg, border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center" }}>
            {v.tag}
          </span>
          <h1 style={{ margin: "0", fontSize: "26px", lineHeight: "1.25" }}>
            {v.title}
          </h1>
          <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.6", color: "#55557A" }}>
            {v.body}
          </p>
          <div style={{ background: "#FFFFFF", border: "2px solid #1B1B3A", borderRadius: "14px", padding: "10px 12px", fontSize: "14px", fontWeight: "600" }}>
            {v.detail}
          </div>
          <div style={{ flex: "1" }} />
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/map")}>
            {v.cta}
          </button>
          <button type="button" style={{ height: "44px", border: "none", background: "none", fontFamily: "inherit", fontSize: "15px", fontWeight: "600", color: "#55557A" }} onClick={() => go("/tutorial")}>
            {v.cta2}
          </button>
        </div>
      </div>
  );
}
