// Generated from handoff/screens/A09-Tutorial.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';
import Wall from '../components/Wall';

export type A09TutorialProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A09TutorialProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A09Tutorial(props: A09TutorialProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#F3D9A8" }}>
        <div style={{ position: "absolute", left: "0", top: "0" }}>
          <Wall mode="climb" climberTop="322" />
        </div>
        <div style={{ position: "absolute", left: "0", right: "0", top: "0", height: "620px", background: "rgba(27,27,58,0.35)" }} />
        <div className="bb-ring" style={{ position: "absolute", left: "228px", top: "284px", width: "68px", height: "68px", borderRadius: "50%", border: "4px solid #FFC93C", boxShadow: "0 0 0 6px rgba(255,201,60,0.4)" }} />
        <div className="bb-tap" style={{ position: "absolute", left: "250px", top: "330px", transform: "rotate(-20deg)" }}>
          <svg width="56" height="64" viewBox="0 0 56 64" aria-hidden="true">
            <path d="M20 6c0-3 2-5 5-5s5 2 5 5v22l10 2c5 1 8 5 7 10l-3 14c-1 6-6 10-12 10H22c-4 0-7-2-9-5L4 38c-2-3-1-6 2-7 2-1 5 0 7 2l7 7z" fill="#FFFFFF" stroke="#1B1B3A" strokeWidth="3" strokeLinejoin="round" />
          </svg>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "52px", display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{ flex: "1", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", gap: "8px", padding: "0 12px" }}>
            <span style={{ fontSize: "13px", fontWeight: "700" }}>
              {"บทเรียน 1/4"}
            </span>
            <div style={{ flex: "1", display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "4px" }}>
              <span style={{ height: "8px", borderRadius: "999px", background: "#FFC93C", border: "1.5px solid #1B1B3A" }} />
              <span style={{ height: "8px", borderRadius: "999px", background: "#E9DFCF" }} />
              <span style={{ height: "8px", borderRadius: "999px", background: "#E9DFCF" }} />
              <span style={{ height: "8px", borderRadius: "999px", background: "#E9DFCF" }} />
            </div>
          </div>
          <button type="button" style={{ height: "44px", padding: "0 14px", borderRadius: "14px", background: "#1B1B3A", border: "2.5px solid #1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#FFFFFF" }} onClick={() => go("/map")}>
            {"ข้าม"}
          </button>
        </div>
        <div className="bb-sheet" style={{ position: "absolute", left: "0", right: "0", bottom: "0", height: "260px", boxSizing: "border-box", background: "#FFF7EC", borderTop: "2.5px solid #1B1B3A", borderRadius: "28px 28px 0 0", padding: "20px 20px 34px", display: "flex", flexDirection: "column", gap: "14px" }}>
          <div style={{ display: "flex", gap: "12px", alignItems: "flex-end" }}>
            <Chibi pose="wave" w="72" shirt="#6C4CF1" hair="#1B1B3A" skin="#D9A27A" pants="#2D2346" />
            <div style={{ flex: "1", position: "relative", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "18px", padding: "12px 14px" }}>
              <div style={{ fontSize: "13px", fontWeight: "700", color: "#4B33C9" }}>
                {"โค้ชเต้ย"}
              </div>
              <div style={{ fontSize: "16px", fontWeight: "600", lineHeight: "1.45" }}>
                {"แตะ hold ที่มีวงสีเหลือง เพื่อเอื้อมมือไปจับ ปีนให้ถึง TOP!"}
              </div>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: "6px" }}>
            <span style={{ height: "44px", borderRadius: "12px", background: "#FFC93C", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
              {"แตะ hold"}
            </span>
            <span style={{ height: "44px", borderRadius: "12px", background: "#FFFFFF", border: "2px solid #B9B2C8", color: "#55557A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
              {"Stamina"}
            </span>
            <span style={{ height: "44px", borderRadius: "12px", background: "#FFFFFF", border: "2px solid #B9B2C8", color: "#55557A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
              {"ประเภท hold"}
            </span>
            <span style={{ height: "44px", borderRadius: "12px", background: "#FFFFFF", border: "2px solid #B9B2C8", color: "#55557A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
              {"ท่า Dyno"}
            </span>
          </div>
          <div style={{ fontSize: "13px", color: "#55557A", textAlign: "center" }}>
            {"จบครบ 4 บท รับ "}
            <b style={{ color: "#1B1B3A" }}>
              {"200 เหรียญ + ถุงชอล์กลายเหลือง"}
            </b>
          </div>
        </div>
      </div>
  );
}
