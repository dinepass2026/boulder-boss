// Generated from handoff/screens/A06-VerifyOTP.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type A06VerifyOTPProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: A06VerifyOTPProps, state: any, setState: (patch: any) => void): any {
 return {};
}

export default function A06VerifyOTP(props: A06VerifyOTPProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", fontSize: "20px", fontWeight: "700" }}>
            {"ยืนยันอีเมล"}
          </h1>
        </div>
        <div style={{ padding: "24px 24px 0", display: "flex", justifyContent: "center" }}>
          <div style={{ position: "relative", width: "220px", height: "170px" }}>
            <div style={{ position: "absolute", left: "20px", top: "40px", width: "180px", height: "120px", borderRadius: "18px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A" }}>
              <svg width="180" height="120" viewBox="0 0 180 120" aria-hidden="true">
                <path d="M4 8l86 58 86-58" fill="none" stroke="#1B1B3A" strokeWidth="2.5" strokeLinejoin="round" />
              </svg>
            </div>
            <div className="bb-pop" style={{ position: "absolute", right: "-6px", top: "18px", width: "54px", height: "54px", borderRadius: "50%", background: "#17B2A0", border: "2.5px solid #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12l5 5 9-10" />
              </svg>
            </div>
            <div style={{ position: "absolute", left: "-16px", top: "0" }}>
              <Chibi pose="cheer" w="78" shirt="#FF5F45" band="#FFC93C" />
            </div>
          </div>
        </div>
        <div style={{ padding: "20px 24px 0", textAlign: "center", display: "flex", flexDirection: "column", gap: "6px" }}>
          <h2 style={{ margin: "0", fontSize: "24px" }}>
            {"เช็กอีเมลของคุณ"}
          </h2>
          <p style={{ margin: "0", fontSize: "15px", lineHeight: "1.55", color: "#55557A" }}>
            {"ใส่รหัส 6 หลักที่ส่งไปที่"}
            <br />
            <b style={{ color: "#1B1B3A" }}>
              {"chalk.nong@email.com"}
            </b>
          </p>
        </div>
        <div style={{ padding: "22px 24px 0", display: "grid", gridTemplateColumns: "repeat(6, minmax(0, 1fr))", gap: "8px" }}>
          <input aria-label="หลักที่ 1" defaultValue="7" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
          <input aria-label="หลักที่ 2" defaultValue="2" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
          <input aria-label="หลักที่ 3" defaultValue="0" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
          <input aria-label="หลักที่ 4" defaultValue="5" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
          <input aria-label="หลักที่ 5" defaultValue="9" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
          <input aria-label="หลักที่ 6" defaultValue="3" style={{ height: "60px", minWidth: "0", boxSizing: "border-box", textAlign: "center", border: "2.5px solid #1B1B3A", borderRadius: "14px", background: "#E3F7F4", fontFamily: "inherit", fontSize: "26px", fontWeight: "700", color: "#1B1B3A" }} />
        </div>
        <div style={{ padding: "14px 24px 0", display: "flex", justifyContent: "center", alignItems: "center", gap: "8px", fontSize: "14px", fontWeight: "600", color: "#0B6B60" }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0B6B60" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M5 12l5 5 9-10" />
          </svg>
          {"รหัสถูกต้อง"}
        </div>
        <div style={{ flex: "1" }} />
        <div style={{ padding: "0 24px 34px", display: "flex", flexDirection: "column", gap: "10px" }}>
          <button type="button" style={{ height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("/player-info")}>
            {"ไปตั้งชื่อนักปีน"}
          </button>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <button type="button" disabled style={{ minHeight: "44px", border: "none", background: "none", padding: "0", fontFamily: "inherit", fontSize: "14px", fontWeight: "600", color: "#55557A" }}>
              {"ส่งรหัสใหม่ (00:32)"}
            </button>
            <button type="button" style={{ minHeight: "44px", border: "none", background: "none", padding: "0", fontFamily: "inherit", fontSize: "14px", fontWeight: "700", color: "#1B1B3A", textDecoration: "underline" }} onClick={() => go("back")}>
              {"เปลี่ยนอีเมล"}
            </button>
          </div>
        </div>
      </div>
  );
}
