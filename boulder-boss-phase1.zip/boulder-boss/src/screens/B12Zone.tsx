// Generated from handoff/screens/B12-Zone.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import BottomNav from '../components/BottomNav';
import Skyline from '../components/Skyline';

export type B12ZoneProps = { time?: string };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: B12ZoneProps, state: any, setState: (patch: any) => void): any {
 return { time: props.time ?? 'auto' };
}

export default function B12Zone(props: B12ZoneProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC" }}>
        <div style={{ position: "absolute", left: "0", top: "0" }}>
          <Skyline time={v.time} w="390" h="250" />
        </div>
        <button type="button" aria-label="กลับไปแผนที่" style={{ position: "absolute", left: "20px", top: "52px", width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("/map")}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M15 5l-7 7 7 7" />
          </svg>
        </button>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "186px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "14px 16px", display: "flex", flexDirection: "column", gap: "8px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <h1 style={{ margin: "0", fontSize: "26px" }}>
              {"โซนสุขุมวิท"}
            </h1>
            <span style={{ fontSize: "13px", fontWeight: "600", display: "flex", alignItems: "center", gap: "6px" }}>
              <span style={{ width: "9px", height: "9px", borderRadius: "50%", background: "#17B2A0" }} />
              {"342 ออนไลน์"}
            </span>
          </div>
          <div style={{ display: "flex", gap: "8px", fontSize: "13px", color: "#55557A", flexWrap: "wrap" }}>
            <span>
              {"3 ยิม"}
            </span>
            <span>
              {"·"}
            </span>
            <span>
              {"126 รูท"}
            </span>
            <span>
              {"·"}
            </span>
            <span>
              {"ครองโดยคลับ "}
              <b style={{ color: "#1B1B3A" }}>
                {"Crimp Gang"}
              </b>
            </span>
          </div>
        </div>
        <div style={{ position: "absolute", left: "20px", right: "20px", top: "310px", bottom: "96px", display: "flex", flexDirection: "column", gap: "14px", overflow: "hidden" }}>
          <h2 style={{ margin: "0", fontSize: "18px" }}>
            {"ยิมในโซน"}
          </h2>
          <button type="button" style={{ textAlign: "left", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "12px", display: "flex", gap: "12px", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("/gym")}>
            <span style={{ width: "92px", height: "92px", flexShrink: "0", borderRadius: "14px", border: "2px solid #1B1B3A", background: "#F3D9A8", position: "relative", overflow: "hidden" }}>
              <svg width="92" height="92" viewBox="0 0 92 92" aria-hidden="true">
                <polygon points="0,0 40,0 46,92 0,92" fill="#EBCB93" />
                <g stroke="#1B1B3A" strokeWidth="2">
                  <circle cx="20" cy="70" r="7" fill="#FF5F45" />
                  <circle cx="50" cy="52" r="6" fill="#FF5F45" />
                  <circle cx="30" cy="34" r="6" fill="#5AB8FF" />
                  <circle cx="64" cy="22" r="7" fill="#FF5F45" />
                  <circle cx="72" cy="66" r="6" fill="#3DDC84" />
                </g>
              </svg>
            </span>
            <span style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", gap: "4px" }}>
              <span style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <b style={{ fontSize: "17px" }}>
                  {"Crimp Factory ทองหล่อ"}
                </b>
              </span>
              <span style={{ fontSize: "13px", color: "#55557A" }}>
                {"ธีมโรงงานเก่า · ผนังชัน 45°"}
              </span>
              <span style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#FFE3B3", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
                  {"Crimp"}
                </span>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#FFE3B3", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
                  {"Overhang"}
                </span>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#FF5F45", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center" }}>
                  {"8 NEW"}
                </span>
              </span>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"48 รูท · V0–V9 · 156 คนในยิม"}
              </span>
            </span>
          </button>
          <button type="button" style={{ textAlign: "left", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "12px", display: "flex", gap: "12px", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("/gym")}>
            <span style={{ width: "92px", height: "92px", flexShrink: "0", borderRadius: "14px", border: "2px solid #1B1B3A", background: "#CDEBFF", position: "relative", overflow: "hidden" }}>
              <svg width="92" height="92" viewBox="0 0 92 92" aria-hidden="true">
                <polygon points="0,92 92,30 92,92" fill="#A9D8F7" />
                <g stroke="#1B1B3A" strokeWidth="2">
                  <ellipse cx="24" cy="72" rx="9" ry="5" fill="#6C4CF1" />
                  <ellipse cx="50" cy="56" rx="8" ry="5" fill="#6C4CF1" />
                  <ellipse cx="70" cy="40" rx="9" ry="5" fill="#FFC93C" />
                  <ellipse cx="34" cy="28" rx="7" ry="4" fill="#6C4CF1" />
                </g>
              </svg>
            </span>
            <span style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", gap: "4px" }}>
              <b style={{ fontSize: "17px" }}>
                {"Slab Lab เอกมัย"}
              </b>
              <span style={{ fontSize: "13px", color: "#55557A" }}>
                {"ธีมห้องแล็บ · ผนังเอียงเข้า"}
              </span>
              <span style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#E3F7F4", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
                  {"Slab"}
                </span>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#E3F7F4", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
                  {"Balance"}
                </span>
              </span>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"40 รูท · V0–V7 · 98 คนในยิม"}
              </span>
            </span>
          </button>
          <button type="button" style={{ textAlign: "left", background: "#FFFFFF", border: "2.5px solid #1B1B3A", borderRadius: "20px", boxShadow: "0 4px 0 #1B1B3A", padding: "12px", display: "flex", gap: "12px", fontFamily: "inherit", color: "#1B1B3A" }} onClick={() => go("/gym")}>
            <span style={{ width: "92px", height: "92px", flexShrink: "0", borderRadius: "14px", border: "2px solid #1B1B3A", background: "#2B2F6B", position: "relative", overflow: "hidden" }}>
              <svg width="92" height="92" viewBox="0 0 92 92" aria-hidden="true">
                <g stroke="#1B1B3A" strokeWidth="2">
                  <circle cx="18" cy="74" r="7" fill="#3DDC84" />
                  <circle cx="74" cy="22" r="9" fill="#3DDC84" />
                </g>
                <path d="M24 66Q50 30 68 28" stroke="#FFC93C" strokeWidth="3" strokeDasharray="5 5" fill="none" />
              </svg>
            </span>
            <span style={{ flex: "1", minWidth: "0", display: "flex", flexDirection: "column", gap: "4px" }}>
              <b style={{ fontSize: "17px" }}>
                {"Dyno Den พร้อมพงษ์"}
              </b>
              <span style={{ fontSize: "13px", color: "#55557A" }}>
                {"ธีมไนต์คลับ · เปิดถึงตี 2"}
              </span>
              <span style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#EEE9FF", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
                  {"Dyno"}
                </span>
                <span style={{ height: "24px", padding: "0 8px", borderRadius: "8px", background: "#1B1B3A", color: "#FFC93C", border: "1.5px solid #1B1B3A", fontSize: "12px", fontWeight: "700", display: "flex", alignItems: "center" }}>
                  {"Boss Wall"}
                </span>
              </span>
              <span style={{ fontSize: "12px", color: "#55557A" }}>
                {"38 รูท · V2–V12 · 88 คนในยิม"}
              </span>
            </span>
          </button>
        </div>
        <div style={{ position: "absolute", left: "0", bottom: "0" }}>
          <BottomNav active="map" />
        </div>
      </div>
  );
}
