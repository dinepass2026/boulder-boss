// Generated from handoff/screens/D25-Achievements.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';

export type D25AchievementsProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D25AchievementsProps, state: any, setState: (patch: any) => void): any {

const I = {
flag: 'M5 21V4 M5 4h11l-2 4 2 4H5', bolt: 'M13 2L4 14h7l-1 8 9-12h-7z', fire: 'M12 22c4 0 7-3 7-7 0-5-5-7-5-12-3 2-5 5-5 8-1-1-2-2-2-4-2 2-2 5-2 8 0 4 3 7 7 7z',
map: 'M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z M9 3v15 M15 6v15', star: 'M12 3l2.8 5.8 6.2.9-4.5 4.4 1 6.3L12 17.5 6.5 20.4l1-6.3L3 9.7l6.2-.9z',
mount: 'M3 20l6-10 4 6 3-4 5 8z', lock: 'M6 11h12v10H6z M8 11V8a4 4 0 0 1 8 0v3', trophy: 'M8 4h8v5a4 4 0 0 1-8 0z M8 6H4v1a4 4 0 0 0 4 4 M16 6h4v1a4 4 0 0 1-4 4 M12 13v4 M8 21h8'
};
const raw = [
['Send แรก', 'ได้แล้ว', I.flag, '#FFC93C', true], ['Flash ×5', 'ได้แล้ว', I.bolt, '#17B2A0', true], ['ปีน 7 วันติด', 'ได้แล้ว', I.fire, '#FF5F45', true],
['นักสำรวจสยาม', 'ได้แล้ว', I.map, '#5AB8FF', true], ['ให้ดาว 10 รูท', 'ได้แล้ว', I.star, '#FFC93C', true], ['ถึง V3', 'ได้แล้ว', I.mount, '#3DDC84', true],
['ถึง V5', '3/5 รูท V4', I.mount, '#FFFFFF', false], ['Flash ×20', '6/20', I.bolt, '#FFFFFF', false], ['ครบ 3 ยิม', '2/3', I.map, '#FFFFFF', false],
['Boss Wall แรก', 'ล็อก', I.trophy, '#FFFFFF', false], ['ปีน 30 วันติด', '7/30', I.fire, '#FFFFFF', false], ['ความลับ', '???', I.lock, '#FFFFFF', false]
];
return { badges: raw.map(([name, sub, d, bg, on]) => ({ name, sub, d, bg: on ? bg : '#EDE6DA', card: on ? '#FFFFFF' : '#F6F0E6', bs: on ? 'solid' : 'dashed', bc: on ? '#1B1B3A' : '#8A85A0', ic: on ? '#1B1B3A' : '#55557A' })) };
}

export default function D25Achievements(props: D25AchievementsProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"ตราและความสำเร็จ"}
          </h1>
        </div>
        <div style={{ margin: "14px 20px 0", background: "#1B1B3A", color: "#FFFFFF", borderRadius: "20px", boxShadow: "0 4px 0 #FFC93C", padding: "14px 16px", display: "flex", alignItems: "center", gap: "14px" }}>
          <div style={{ width: "60px", height: "60px", borderRadius: "18px", background: "#FFC93C", border: "2.5px solid #FFFFFF", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M8 4h8v5a4 4 0 0 1-8 0z M8 6H4v1a4 4 0 0 0 4 4 M16 6h4v1a4 4 0 0 1-4 4 M12 13v4 M8 21h8" />
            </svg>
          </div>
          <div style={{ flex: "1", display: "flex", flexDirection: "column", gap: "6px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontWeight: "700" }}>
              <span>
                {"ปลดล็อกแล้ว"}
              </span>
              <span style={{ color: "#FFC93C" }}>
                {"9 / 40"}
              </span>
            </div>
            <div style={{ height: "10px", borderRadius: "999px", background: "#3A3A60", overflow: "hidden" }}>
              <div style={{ width: "22.5%", height: "100%", background: "#FFC93C" }} />
            </div>
            <span style={{ fontSize: "12px", color: "#D8D6EA" }}>
              {"Boss Wall ที่ผ่าน: 0 / 7"}
            </span>
          </div>
        </div>
        <div style={{ padding: "12px 20px 0", display: "flex", gap: "6px", overflow: "hidden" }}>
          <button type="button" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#1B1B3A", color: "#FFFFFF", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"ทั้งหมด"}
          </button>
          <button type="button" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"การปีน"}
          </button>
          <button type="button" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"สำรวจ"}
          </button>
          <button type="button" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"Boss Wall"}
          </button>
        </div>
        <div style={{ padding: "14px 20px 0", display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "10px" }}>
          {(v.badges || []).map((b: any, b_i: number) => (
            <Fragment key={b_i}>
              <div className="bb-in" style={{ minHeight: "124px", boxSizing: "border-box", borderRadius: "18px", background: b.card, border: `2.5px ${b.bs} ${b.bc}`, padding: "10px 6px", display: "flex", flexDirection: "column", alignItems: "center", gap: "6px", textAlign: "center", animationDelay: `${Math.min(b_i, 12) * 45}ms` }}>
                <span style={{ width: "48px", height: "48px", borderRadius: "15px", background: b.bg, border: `2.5px solid ${b.bc}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={b.ic} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d={b.d} />
                  </svg>
                </span>
                <span style={{ fontSize: "12px", fontWeight: "700", lineHeight: "1.2" }}>
                  {b.name}
                </span>
                <span style={{ fontSize: "11px", color: "#55557A" }}>
                  {b.sub}
                </span>
              </div>
            </Fragment>
          ))}
        </div>
      </div>
  );
}
