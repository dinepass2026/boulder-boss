// Generated from handoff/screens/D24-Wardrobe.dc.html — layout matches the design canvas 1:1.
/* eslint-disable */
import { Fragment } from 'react';
import { useDC, useGo } from '../lib/dc';
import Chibi from '../components/Chibi';

export type D24WardrobeProps = {  };

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function renderVals(props: D24WardrobeProps, state: any, setState: (patch: any) => void): any {

const raw = [
['เสื้อกล้ามทีล', '#17B2A0', 'on'], ['เสื้อยืดคอรัล', '#FF5F45', 'own'], ['เสื้อฮู้ดเหลือง', '#FFC93C', 'own'],
['แจ็กเก็ตม่วง', '#6C4CF1', 'own'], ['เสื้อลายสยาม', '#5AB8FF', 'new'], ['เสื้อ Crimp Gang', '#1B1B3A', 'own'],
['ชุด Boss ทอง', '#FFB800', 'lock'], ['เสื้อทีมงานยิม', '#3DDC84', 'lock'], ['ชุดลอยกระทง', '#FF8FC8', 'lock']
];
return { items: raw.map(([name, c, st]) => ({
name, c,
bg: st === 'on' ? '#FFF1C2' : st === 'lock' ? '#EDE6DA' : '#FFFFFF',
border: st === 'lock' ? '#B9B2C8' : '#1B1B3A', shadow: st === 'on' ? '#1B1B3A' : 'transparent',
o: st === 'lock' ? 0.75 : 1,
tag: st === 'on' ? 'สวมอยู่' : st === 'new' ? 'NEW' : st === 'lock' ? 'ร้านค้า' : '',
tagD: st === 'own' ? 'none' : 'flex',
tagBg: st === 'on' ? '#FFC93C' : st === 'new' ? '#FF5F45' : '#FFFFFF', tagFg: '#1B1B3A'
})) };
}

export default function D24Wardrobe(props: D24WardrobeProps) {
  const go = useGo();
  const v = useDC(renderVals, props);
  void go; void v;
  return (
      <div style={{ width: "390px", height: "844px", position: "relative", overflow: "hidden", fontFamily: "'Bai Jamjuree', sans-serif", color: "#1B1B3A", background: "#FFF7EC", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "52px 20px 0", display: "flex", alignItems: "center", gap: "12px" }}>
          <button type="button" aria-label="ย้อนกลับ" style={{ width: "44px", height: "44px", borderRadius: "14px", background: "#FFFFFF", border: "2.5px solid #1B1B3A", boxShadow: "0 3px 0 #1B1B3A", display: "flex", alignItems: "center", justifyContent: "center", padding: "0" }} onClick={() => go("back")}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M15 5l-7 7 7 7" />
            </svg>
          </button>
          <h1 style={{ margin: "0", flex: "1", fontSize: "20px" }}>
            {"ตู้เสื้อผ้า"}
          </h1>
          <span style={{ fontSize: "13px", fontWeight: "600", color: "#55557A" }}>
            {"มี 14/62 ชิ้น"}
          </span>
        </div>
        <div style={{ margin: "14px 20px 0", height: "220px", borderRadius: "24px", border: "2.5px solid #1B1B3A", background: "#6C4CF1", position: "relative", overflow: "hidden", display: "flex" }}>
          <svg width="346" height="220" viewBox="0 0 346 220" style={{ position: "absolute", inset: "0" }} aria-hidden="true">
            <g fill="#7D61F3">
              <circle cx="300" cy="40" r="30" />
              <circle cx="250" cy="170" r="14" />
              <circle cx="40" cy="30" r="10" />
            </g>
            <ellipse cx="110" cy="200" rx="80" ry="16" fill="#FFC93C" stroke="#1B1B3A" strokeWidth="2.5" />
          </svg>
          <div style={{ position: "absolute", left: "50px", top: "16px" }}>
            <Chibi pose="cheer" w="130" shirt="#17B2A0" shoes="#FF5F45" band="#FFC93C" />
          </div>
          <div style={{ position: "absolute", right: "14px", top: "14px", bottom: "14px", width: "132px", display: "flex", flexDirection: "column", gap: "6px" }}>
            <span style={{ fontSize: "12px", fontWeight: "700", color: "#FFFFFF" }}>
              {"สวมอยู่"}
            </span>
            <span style={{ height: "32px", padding: "0 8px", borderRadius: "9px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
              {"เสื้อกล้ามทีล"}
            </span>
            <span style={{ height: "32px", padding: "0 8px", borderRadius: "9px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
              {"รองเท้าคอรัล"}
            </span>
            <span style={{ height: "32px", padding: "0 8px", borderRadius: "9px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
              {"ชอล์กมินต์"}
            </span>
            <span style={{ height: "32px", padding: "0 8px", borderRadius: "9px", background: "#FFFFFF", border: "2px solid #1B1B3A", fontSize: "12px", fontWeight: "600", display: "flex", alignItems: "center" }}>
              {"ผ้าคาดเหลือง"}
            </span>
          </div>
        </div>
        <div role="tablist" aria-label="หมวด" style={{ padding: "14px 20px 0", display: "flex", gap: "6px", overflow: "hidden" }}>
          <button type="button" role="tab" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#1B1B3A", color: "#FFFFFF", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"ชุด"}
          </button>
          <button type="button" role="tab" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"รองเท้า"}
          </button>
          <button type="button" role="tab" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"ชอล์ก"}
          </button>
          <button type="button" role="tab" style={{ height: "44px", padding: "0 14px", flexShrink: "0", borderRadius: "999px", border: "2px solid #1B1B3A", background: "#FFFFFF", color: "#1B1B3A", fontFamily: "inherit", fontSize: "14px", fontWeight: "600" }}>
            {"เอฟเฟกต์"}
          </button>
        </div>
        <div style={{ padding: "14px 20px 0", display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: "10px" }}>
          {(v.items || []).map((it: any, it_i: number) => (
            <Fragment key={it_i}>
              <button className="bb-in" type="button" style={{ position: "relative", height: "112px", borderRadius: "18px", background: it.bg, border: `2.5px solid ${it.border}`, boxShadow: `0 3px 0 ${it.shadow}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "4px", padding: "6px", fontFamily: "inherit", color: "#1B1B3A", opacity: it.o, animationDelay: `${Math.min(it_i, 12) * 45}ms` }}>
                <svg width="46" height="46" viewBox="0 0 48 48" aria-hidden="true">
                  <path d="M16 6l8 5 8-5 10 7-5 8-4-2v23H15V19l-4 2-5-8z" fill={it.c} stroke="#1B1B3A" strokeWidth="2.5" strokeLinejoin="round" />
                </svg>
                <span style={{ fontSize: "12px", fontWeight: "600", textAlign: "center", lineHeight: "1.2" }}>
                  {it.name}
                </span>
                <span style={{ position: "absolute", top: "6px", right: "6px", height: "20px", padding: "0 6px", borderRadius: "6px", fontSize: "10px", fontWeight: "700", display: it.tagD, alignItems: "center", background: it.tagBg, color: it.tagFg, border: "1.5px solid #1B1B3A" }}>
                  {it.tag}
                </span>
              </button>
            </Fragment>
          ))}
        </div>
        <div style={{ flex: "1" }} />
        <div style={{ padding: "0 20px 34px" }}>
          <button type="button" style={{ width: "100%", height: "56px", borderRadius: "16px", background: "#FFC93C", border: "2.5px solid #1B1B3A", boxShadow: "0 4px 0 #1B1B3A", fontFamily: "inherit", fontSize: "18px", fontWeight: "700", color: "#1B1B3A" }} onClick={() => go("back")}>
            {"บันทึกลุคนี้"}
          </button>
        </div>
      </div>
  );
}
