import { Link } from 'react-router-dom';
import { SCREENS } from './routes';

/** /dev — jump to any Phase 1 screen (not part of the player UI). */
export default function DevIndex() {
  return (
    <div style={{ width: 390, height: 844, overflowY: 'auto', background: '#FFF7EC', fontFamily: "'Bai Jamjuree', sans-serif", color: '#1B1B3A', padding: '40px 20px', boxSizing: 'border-box' }}>
      <h1 style={{ margin: 0, fontSize: 28 }}>Boulder Boss · Phase 1</h1>
      <p style={{ margin: '4px 0 16px', color: '#55557A', fontSize: 13 }}>ดัชนีหน้าจอสำหรับทีม (mock data)</p>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        {SCREENS.map((s) => (
          <Link key={s.id} to={s.link ?? s.path} style={{ textDecoration: 'none', color: '#1B1B3A', background: '#FFFFFF', border: '2.5px solid #1B1B3A', boxShadow: '0 3px 0 #1B1B3A', borderRadius: 14, padding: '8px 10px', display: 'flex', flexDirection: 'column' }}>
            <b style={{ fontSize: 13 }}>{s.id}</b>
            <span style={{ fontSize: 14, fontWeight: 600 }}>{s.title}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
