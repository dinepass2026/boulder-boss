import { useEffect, useState } from 'react';

export default function Toast() {
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    let t: number | undefined;
    const on = (e: Event) => {
      setMsg((e as CustomEvent<string>).detail);
      window.clearTimeout(t);
      t = window.setTimeout(() => setMsg(null), 1800);
    };
    window.addEventListener('bb-toast', on);
    return () => window.removeEventListener('bb-toast', on);
  }, []);
  if (!msg) return null;
  return (
    <div role="status" className="bb-toast">
      {msg}
    </div>
  );
}
