import { ReactNode, useEffect, useState } from 'react';
import { STAGE } from '../lib/tokens';

/**
 * Every screen is designed on a fixed 390×844 portrait artboard. The stage keeps that
 * exact layout and scales it to fit the viewport (letterboxed on paper colour), so
 * positions match the design 1:1 on any phone. On a 390×844 device the scale is 1.
 */
export default function Stage({ children }: { children: ReactNode }) {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const vv = window.visualViewport;
      const w = vv?.width ?? window.innerWidth;
      const h = vv?.height ?? window.innerHeight;
      // leave room for the device frame on desktop
      const pad = w >= 600 ? 32 : 0;
      setScale(Math.min((w - pad) / STAGE.w, (h - pad) / STAGE.h));
    };
    fit();
    window.addEventListener('resize', fit);
    window.visualViewport?.addEventListener('resize', fit);
    return () => {
      window.removeEventListener('resize', fit);
      window.visualViewport?.removeEventListener('resize', fit);
    };
  }, []);
  return (
    <div className="bb-viewport">
      <div className="bb-stage-box" style={{ width: STAGE.w * scale, height: STAGE.h * scale }}>
        <div className="bb-stage" style={{ width: STAGE.w, height: STAGE.h, transform: `scale(${scale})` }}>
          {children}
        </div>
      </div>
    </div>
  );
}
