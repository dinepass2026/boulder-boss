import { ComponentType, ReactNode, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Confetti from './Confetti';
import A01Splash from '../screens/A01Splash';
import A02Welcome from '../screens/A02Welcome';
import A03Login from '../screens/A03Login';
import A04ForgotPassword from '../screens/A04ForgotPassword';
import A05Register from '../screens/A05Register';
import A06VerifyOTP from '../screens/A06VerifyOTP';
import A07PlayerInfo from '../screens/A07PlayerInfo';
import A08AvatarCreator from '../screens/A08AvatarCreator';
import A09Tutorial from '../screens/A09Tutorial';
import A10LinkGuest from '../screens/A10LinkGuest';
import B11MapHome from '../screens/B11MapHome';
import B12Zone from '../screens/B12Zone';
import B13Gym from '../screens/B13Gym';
import B13bWallView from '../screens/B13bWallView';
import B14RouteList from '../screens/B14RouteList';
import B15RouteDetail from '../screens/B15RouteDetail';
import B15bBeta from '../screens/B15bBeta';
import C16Climb from '../screens/C16Climb';
import C17MoveMinigame from '../screens/C17MoveMinigame';
import C18PauseMenu from '../screens/C18PauseMenu';
import C19Fall from '../screens/C19Fall';
import C20Result from '../screens/C20Result';
import D21Profile from '../screens/D21Profile';
import D22EditProfile from '../screens/D22EditProfile';
import D23Logbook from '../screens/D23Logbook';
import D24Wardrobe from '../screens/D24Wardrobe';
import D25Achievements from '../screens/D25Achievements';
import D26PlayerProfile from '../screens/D26PlayerProfile';
import J56Notifications from '../screens/J56Notifications';
import J57Settings from '../screens/J57Settings';
import J58Legal from '../screens/J58Legal';
import J59SystemStates from '../screens/J59SystemStates';

function AutoAdvance({ to, ms, children }: { to: string; ms: number; children: ReactNode }) {
  const navigate = useNavigate();
  useEffect(() => {
    const id = window.setTimeout(() => navigate(to, { replace: true }), ms);
    return () => window.clearTimeout(id);
  }, [navigate, to, ms]);
  return <div onClick={() => navigate(to, { replace: true })}>{children}</div>;
}

/** Route param → screen prop (e.g. /result/:result → <C20Result result=…/>). */
function withParam<P>(C: ComponentType<P>, param: string) {
  return function Param() {
    const p = useParams();
    return <C {...({ [param]: p[param] } as any)} />;
  };
}
function ResultRoute() {
  const { result } = useParams();
  return (
    <div style={{ position: 'relative' }}>
      <C20Result result={result} />
      {result !== 'project' && <Confetti count={result === 'flash' ? 48 : 32} />}
    </div>
  );
}

function MoveRoute() {
  const { move } = useParams();
  // Heel hook mock: the drag demo plays, then the move lands.
  if (move === 'heelhook') return <AutoAdvance to="/result/send" ms={3600}><C17MoveMinigame move={move} /></AutoAdvance>;
  return <C17MoveMinigame move={move} />;
}

function FallRoute() {
  useEffect(() => {
    try { navigator.vibrate?.([120, 60, 180]); } catch { /* not supported */ }
  }, []);
  return <C19Fall />;
}
const SystemRoute = withParam(J59SystemStates, 'state');

export interface ScreenDef { id: string; title: string; path: string; element: ReactNode; link?: string }

export const SCREENS: ScreenDef[] = [
  { id: 'A01', title: 'Splash', path: '/', element: <AutoAdvance to="/welcome" ms={2200}><A01Splash /></AutoAdvance> },
  { id: 'A02', title: 'ต้อนรับ', path: '/welcome', element: <A02Welcome /> },
  { id: 'A03', title: 'เข้าสู่ระบบ', path: '/login', element: <A03Login /> },
  { id: 'A04', title: 'ลืมรหัสผ่าน', path: '/forgot', element: <A04ForgotPassword /> },
  { id: 'A05', title: 'สมัครสมาชิก', path: '/register', element: <A05Register /> },
  { id: 'A06', title: 'ยืนยัน OTP', path: '/verify', element: <A06VerifyOTP /> },
  { id: 'A07', title: 'ข้อมูลนักปีน', path: '/player-info', element: <A07PlayerInfo /> },
  { id: 'A08', title: 'สร้างตัวละคร', path: '/avatar', element: <A08AvatarCreator /> },
  { id: 'A09', title: 'Tutorial', path: '/tutorial', element: <A09Tutorial /> },
  { id: 'A10', title: 'ผูกบัญชี Guest', path: '/link-guest', element: <A10LinkGuest /> },
  { id: 'B11', title: 'แผนที่กรุงเทพ', path: '/map', element: <B11MapHome /> },
  { id: 'B12', title: 'ย่าน', path: '/zone', element: <B12Zone /> },
  { id: 'B13', title: 'ยิม', path: '/gym', element: <B13Gym /> },
  { id: 'B13b', title: 'ดูผนัง', path: '/wall', element: <B13bWallView /> },
  { id: 'B14', title: 'รายการรูท', path: '/routes', element: <B14RouteList /> },
  { id: 'B15', title: 'รายละเอียดรูท', path: '/route', element: <B15RouteDetail /> },
  { id: 'B15b', title: 'Beta', path: '/beta', element: <B15bBeta /> },
  { id: 'C16', title: 'ปีน', path: '/climb', element: <C16Climb /> },
  { id: 'C17', title: 'Mini-game', path: '/move/:move', link: '/move/dyno', element: <MoveRoute /> },
  { id: 'C17·hh', title: 'Mini-game heel hook', path: '', link: '/move/heelhook', element: null },
  { id: 'C18', title: 'หยุดเกม', path: '/pause', element: <C18PauseMenu /> },
  { id: 'C19', title: 'ตก', path: '/fall', element: <FallRoute /> },
  { id: 'C20', title: 'ผลลัพธ์', path: '/result/:result', link: '/result/send', element: <ResultRoute /> },
  { id: 'C20·flash', title: 'ผลลัพธ์ Flash', path: '', link: '/result/flash', element: null },
  { id: 'C20·project', title: 'ผลลัพธ์ Project', path: '', link: '/result/project', element: null },
  { id: 'D21', title: 'โปรไฟล์', path: '/profile', element: <D21Profile /> },
  { id: 'D22', title: 'แก้ไขโปรไฟล์', path: '/profile/edit', element: <D22EditProfile /> },
  { id: 'D23', title: 'Logbook', path: '/logbook', element: <D23Logbook /> },
  { id: 'D24', title: 'ตู้เสื้อผ้า', path: '/wardrobe', element: <D24Wardrobe /> },
  { id: 'D25', title: 'ตรา', path: '/achievements', element: <D25Achievements /> },
  { id: 'D26', title: 'โปรไฟล์ผู้เล่นอื่น', path: '/player', element: <D26PlayerProfile /> },
  { id: 'J56', title: 'การแจ้งเตือน', path: '/notifications', element: <J56Notifications /> },
  { id: 'J57', title: 'ตั้งค่า', path: '/settings', element: <J57Settings /> },
  { id: 'J58', title: 'ข้อกฎหมาย', path: '/legal', element: <J58Legal /> },
  { id: 'J59', title: 'สถานะระบบ', path: '/system/:state', link: '/system/offline', element: <SystemRoute /> },
  { id: 'J59·mt', title: 'ปิดปรับปรุง', path: '', link: '/system/maintenance', element: null },
  { id: 'J59·up', title: 'อัปเดต', path: '', link: '/system/update', element: null },
];
