import { HashRouter, Navigate, Route, Routes, useLocation, useNavigationType } from 'react-router-dom';
import Stage from './Stage';
import Toast from './Toast';
import DevIndex from './DevIndex';
import { SCREENS } from './routes';

/** Re-keys on every navigation so each screen plays its enter animation. */
function AnimatedRoutes() {
  const location = useLocation();
  const navType = useNavigationType();
  const dir = navType === 'POP' ? 'bb-page-back' : location.pathname.startsWith('/result') || location.pathname === '/fall' || location.pathname === '/pause' ? 'bb-page-pop' : 'bb-page-fwd';
  return (
    <div key={location.pathname} className={`bb-page ${dir}`}>
      <Routes location={location}>
          {SCREENS.filter((s) => s.path).map((s) => (
            <Route key={s.id} path={s.path} element={s.element} />
          ))}
          <Route path="/dev" element={<DevIndex />} />
          <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Stage>
        <AnimatedRoutes />
        <Toast />
      </Stage>
    </HashRouter>
  );
}
