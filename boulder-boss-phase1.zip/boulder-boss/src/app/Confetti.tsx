import { useMemo } from 'react';

const COLORS = ['#FFC93C', '#FF5F45', '#17B2A0', '#5AB8FF', '#6C4CF1', '#FFFFFF'];

/** Celebration burst for SEND / FLASH (sticker-style pieces with ink outline). */
export default function Confetti({ count = 36 }: { count?: number }) {
  const pieces = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        left: Math.random() * 100,
        delay: Math.random() * 0.9,
        dur: 1.8 + Math.random() * 1.6,
        size: 7 + Math.random() * 8,
        color: COLORS[i % COLORS.length],
        round: i % 3 === 0,
        drift: (Math.random() - 0.5) * 120,
        spin: (Math.random() < 0.5 ? -1 : 1) * (360 + Math.random() * 540),
      })),
    [count],
  );
  return (
    <div className="bb-confetti-layer" aria-hidden="true">
      {pieces.map((p, i) => (
        <span
          key={i}
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.round ? p.size : p.size * 0.6,
            background: p.color,
            borderRadius: p.round ? '50%' : 2,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.dur}s`,
            ['--drift' as string]: `${p.drift}px`,
            ['--spin' as string]: `${p.spin}deg`,
          }}
        />
      ))}
    </div>
  );
}
