import { useEffect, useId, useState } from 'react';

export type SkyTime = 'auto' | 'dawn' | 'day' | 'dusk' | 'night';
type Phase = Exclude<SkyTime, 'auto'>;

export interface SkylineProps {
  /** 'auto' follows the device clock: dawn 5–8, day 8–16, dusk 16–19, night otherwise. */
  time?: SkyTime | string;
  w?: number | string;
  h?: number | string;
}

const PALETTE: Record<Phase, {
  skyTop: string; skyBottom: string; far: string; near: string; sun: string; sunX: number; sunY: number;
  starO: number; cloudO: number; lightO: number; rail: string; river: string; trainWin: string; label: string;
}> = {
  dawn: { skyTop: '#FF9E7A', skyBottom: '#FFE3C2', far: '#E9A898', near: '#9E5A78', sun: '#FFF1C9', sunX: 330, sunY: 150, starO: 0, cloudO: 0.7, lightO: 0.2, rail: '#6E3D5E', river: '#E58F8F', trainWin: '#5AB8FF', label: 'วิวกรุงเทพยามเช้า' },
  day: { skyTop: '#3FA4F5', skyBottom: '#BFE6FF', far: '#93C9EC', near: '#3E78B0', sun: '#FFE066', sunX: 320, sunY: 60, starO: 0, cloudO: 0.95, lightO: 0, rail: '#2C5A8A', river: '#4FA3E0', trainWin: '#5AB8FF', label: 'วิวกรุงเทพตอนกลางวัน' },
  dusk: { skyTop: '#5B3F8C', skyBottom: '#FF8A5B', far: '#A9608F', near: '#4A2F63', sun: '#FFB347', sunX: 70, sunY: 160, starO: 0.4, cloudO: 0.35, lightO: 0.7, rail: '#2F1D44', river: '#C0607A', trainWin: '#FFD66B', label: 'วิวกรุงเทพยามเย็น' },
  night: { skyTop: '#0C1433', skyBottom: '#2B2F6B', far: '#283070', near: '#141A3E', sun: '#F4F1DE', sunX: 330, sunY: 56, starO: 1, cloudO: 0, lightO: 1, rail: '#0A0E26', river: '#1F2A63', trainWin: '#FFD66B', label: 'วิวกรุงเทพยามค่ำ' },
};

export function phaseForHour(hr: number): Phase {
  return hr >= 5 && hr < 8 ? 'dawn' : hr >= 8 && hr < 16 ? 'day' : hr >= 16 && hr < 19 ? 'dusk' : 'night';
}

function useClockPhase(enabled: boolean): Phase {
  const [phase, setPhase] = useState<Phase>(() => phaseForHour(new Date().getHours()));
  useEffect(() => {
    if (!enabled) return;
    const id = window.setInterval(() => setPhase(phaseForHour(new Date().getHours())), 60_000);
    return () => window.clearInterval(id);
  }, [enabled]);
  return phase;
}

/** Bangkok skyline (BTS, Mahanakhon, Chao Phraya) that changes with real time. */
export default function Skyline({ time = 'auto', w = 390, h = 300 }: SkylineProps) {
  const auto = !time || time === 'auto';
  const clock = useClockPhase(auto);
  const t: Phase = auto ? clock : (time as Phase);
  const S = PALETTE[t] ?? PALETTE.day;
  const gid = 'bbsky-' + useId().replace(/:/g, '');
  return (
    <div style={{ width: Number(w), height: Number(h), overflow: 'hidden', background: S.skyTop, display: 'flex', alignItems: 'flex-end' }}>
      <svg width="100%" height="100%" viewBox="0 0 390 300" preserveAspectRatio="xMidYMax meet" role="img" aria-label={S.label}>
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={S.skyTop} />
            <stop offset="1" stopColor={S.skyBottom} />
          </linearGradient>
        </defs>
        <rect x="0" y="0" width="390" height="300" fill={`url(#${gid})`} />
        <g className="bb-stars" fill="#FFFFFF" opacity={S.starO}>
          <circle cx="30" cy="30" r="1.6" /><circle cx="84" cy="62" r="1.2" /><circle cx="140" cy="22" r="1.8" /><circle cx="200" cy="54" r="1.2" />
          <circle cx="236" cy="18" r="1.4" /><circle cx="318" cy="40" r="1.6" /><circle cx="362" cy="80" r="1.2" /><circle cx="170" cy="96" r="1" />
        </g>
        <circle className="bb-sun" cx={S.sunX} cy={S.sunY} r="24" fill={S.sun} />
        <g fill="#FFFFFF" opacity={S.cloudO}>
          <path className="bb-cloud" d="M40 92a12 12 0 0 1 22-6 10 10 0 0 1 18 6z" />
          <path className="bb-cloud bb-cloud-2" d="M270 70a10 10 0 0 1 18-5 9 9 0 0 1 16 5z" />
        </g>
        <polygon
          fill={S.far}
          points="0,300 0,205 22,205 22,180 40,180 40,195 56,195 56,150 78,150 78,200 96,200 96,170 116,170 116,190 130,190 130,130 136,130 136,118 142,118 142,130 148,130 148,195 168,195 168,160 192,160 192,185 210,185 210,140 232,140 232,200 250,200 250,172 272,172 272,192 290,192 290,135 316,135 316,198 334,198 334,170 356,170 356,190 372,190 372,160 390,160 390,300"
        />
        <g fill={S.near}>
          <path d="M28 300V262h8v-12h6v-14h5v-18h3v-22h2v-20h1.5v-26h1v26H56v20h2v22h3v18h5v14h6v12h8v38z" />
          <path d="M4 300v-22h4v-8h3v-10h2v-14h1v14h2v10h3v8h4v22z" />
          <path d="M84 300v-22h4v-8h3v-10h2v-14h1v14h2v10h3v8h4v22z" />
          <rect x="110" y="200" width="34" height="100" />
          <rect x="148" y="172" width="28" height="128" />
          <rect x="180" y="214" width="36" height="86" />
          <rect x="218" y="186" width="26" height="114" />
          <polygon points="250,300 250,62 262,42 286,42 286,118 279,118 279,148 286,148 286,186 278,186 278,218 286,218 286,300" />
          <rect x="292" y="160" width="32" height="140" />
          <rect x="328" y="206" width="30" height="94" />
          <rect x="360" y="182" width="30" height="118" />
        </g>
        <g className="bb-lights" fill="#FFD66B" opacity={S.lightO}>
          <rect x="116" y="210" width="6" height="6" /><rect x="130" y="226" width="6" height="6" /><rect x="116" y="242" width="6" height="6" />
          <rect x="154" y="184" width="6" height="6" /><rect x="166" y="200" width="6" height="6" /><rect x="154" y="216" width="6" height="6" />
          <rect x="258" y="70" width="5" height="5" /><rect x="270" y="96" width="5" height="5" /><rect x="258" y="130" width="5" height="5" />
          <rect x="270" y="168" width="5" height="5" /><rect x="258" y="200" width="5" height="5" />
          <rect x="298" y="174" width="6" height="6" /><rect x="312" y="194" width="6" height="6" /><rect x="298" y="214" width="6" height="6" />
          <rect x="366" y="196" width="6" height="6" /><rect x="378" y="214" width="6" height="6" />
        </g>
        <rect x="0" y="246" width="390" height="9" fill={S.rail} />
        <g fill={S.rail}>
          <rect x="40" y="255" width="7" height="26" /><rect x="120" y="255" width="7" height="26" /><rect x="200" y="255" width="7" height="26" />
          <rect x="280" y="255" width="7" height="26" /><rect x="360" y="255" width="7" height="26" />
        </g>
        <g className="bb-train">
          <rect x="150" y="231" width="100" height="16" rx="5" fill="#FFFFFF" stroke="#1B1B3A" strokeWidth="2" />
          <rect x="150" y="241" width="100" height="3" fill="#17B2A0" />
          <g fill={S.trainWin}>
            <rect x="158" y="234" width="12" height="6" rx="1.5" /><rect x="176" y="234" width="12" height="6" rx="1.5" />
            <rect x="194" y="234" width="12" height="6" rx="1.5" /><rect x="212" y="234" width="12" height="6" rx="1.5" />
            <rect x="230" y="234" width="12" height="6" rx="1.5" />
          </g>
        </g>
        <rect x="0" y="280" width="390" height="20" fill={S.river} />
        <path className="bb-river" d="M20 288h18 M90 292h24 M170 287h16 M250 293h22 M330 288h18" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" opacity="0.5" />
      </svg>
    </div>
  );
}
