import { useState } from 'react';
import Chibi from './Chibi';

export type HoldShape = 'jug' | 'crimp' | 'sloper' | 'pinch' | 'vol';
export type WallMode = 'climb' | 'preview' | 'plain';

/** One hold on the 390×620 wall: x, y (top-left px), size, shape, rotation°, colour. */
export interface Hold { x: number; y: number; s: number; shape: HoldShape; r?: number; c: string }

export const HOLD_PATHS: Record<HoldShape, string> = {
  jug: 'M4 26c0-10 8-18 18-18s16 6 14 14-8 12-16 12S4 34 4 26z',
  crimp: 'M2 20c4-6 32-6 36 0v6c-4 4-32 4-36 0z',
  sloper: 'M3 32C3 17 12 7 22 7s15 10 15 25z',
  pinch: 'M12 4c6-2 12 2 12 8l2 18c0 6-8 8-12 4L8 14c-1-4 0-8 4-10z',
  vol: 'M2 36L20 4l18 32z',
};

const h = (x: number, y: number, s: number, shape: HoldShape, r: number, c: string): Hold => ({ x, y, s, shape, r, c });

/** Mock route "ข้าวเหนียวมะม่วง" (coral), START bottom → TOP. */
export const MOCK_ROUTE: Hold[] = [
  h(176, 548, 34, 'jug', 0, '#FF5F45'), h(222, 552, 30, 'jug', 20, '#FF5F45'), h(140, 470, 32, 'crimp', -10, '#FF5F45'),
  h(238, 420, 34, 'sloper', 0, '#FF5F45'), h(166, 360, 30, 'crimp', 8, '#FF5F45'), h(244, 300, 36, 'pinch', 30, '#FF5F45'),
  h(186, 236, 30, 'crimp', -6, '#FF5F45'), h(118, 176, 34, 'jug', -20, '#FF5F45'), h(226, 114, 32, 'sloper', 10, '#FF5F45'),
  h(196, 44, 40, 'jug', 0, '#FF5F45'),
];

/** Other routes' holds on the same wall (dimmed unless mode = plain). */
export const MOCK_OTHER_HOLDS: Hold[] = [
  h(40, 520, 30, 'jug', 0, '#5AB8FF'), h(70, 430, 26, 'crimp', 0, '#5AB8FF'), h(36, 330, 30, 'sloper', 0, '#5AB8FF'),
  h(74, 240, 28, 'pinch', 0, '#5AB8FF'), h(30, 130, 32, 'jug', 0, '#5AB8FF'),
  h(320, 540, 30, 'pinch', 0, '#3DDC84'), h(330, 450, 28, 'jug', 0, '#3DDC84'), h(300, 370, 52, 'vol', 0, '#6C4CF1'),
  h(334, 260, 28, 'crimp', 0, '#3DDC84'), h(310, 160, 30, 'sloper', 0, '#3DDC84'), h(330, 70, 28, 'jug', 0, '#3DDC84'),
  h(86, 60, 46, 'vol', 0, '#FFC93C'),
];

export interface WallProps {
  /** climb: climber + reachable-hold rings · preview: START/TOP tags · plain: all holds full opacity */
  mode?: WallMode | string;
  climberTop?: number | string;
  pose?: string;
  route?: Hold[];
  others?: Hold[];
  /** Indices in `route` the climber can reach now (yellow dashed ring). Default [5, 6] in climb mode. */
  reach?: number[];
  /** Tap on a route hold (index into `route`). */
  onHoldTap?: (index: number) => void;
  /**
   * Mock climbing: tap a ringed hold and the climber moves up one move; the rings
   * advance along the route. Fires onTop when the TOP hold is matched.
   */
  climbable?: boolean;
  onTop?: () => void;
  onMove?: (step: number) => void;
}

/** 2D front-on climbing wall, 390×620, with T-nut grid, panels and blue crash mat. */
export default function Wall({
  mode = 'climb',
  climberTop = 322,
  pose = 'climb',
  route = MOCK_ROUTE,
  others = MOCK_OTHER_HOLDS,
  reach,
  onHoldTap,
  climbable,
  onTop,
  onMove,
}: WallProps) {
  const [step, setStep] = useState(0);
  const [reaching, setReaching] = useState(false);
  const startRing = reach ?? (mode === 'climb' ? [5, 6] : []);
  const last = route.length - 1;
  const ring = climbable ? startRing.map((i) => Math.min(last, i + step)).filter((v, i, a) => a.indexOf(v) === i) : startRing;
  const top = Number(climberTop) - (climbable ? step * 64 : 0);
  const tap = (i: number) => {
    onHoldTap?.(i);
    if (!climbable) return;
    setReaching(true);
    window.setTimeout(() => setReaching(false), 280);
    if (i === last) {
      window.setTimeout(() => onTop?.(), 420);
      return;
    }
    setStep((s) => s + 1);
    onMove?.(step + 1);
  };
  const otherOpacity = mode === 'plain' ? 1 : 0.45;
  const renderHold = (hd: Hold, key: string, opacity: number, ringOn: boolean, onTap?: () => void) => {
    const inner = (
      <>
        <div style={{ position: 'absolute', inset: -10, borderRadius: '50%', border: '3.5px dashed #1B1B3A', background: 'rgba(255,201,60,0.55)', display: ringOn ? 'block' : 'none' }} />
        <svg width={hd.s} height={hd.s} viewBox="0 0 40 40" style={{ position: 'relative', transform: `rotate(${hd.r ?? 0}deg)` }} aria-hidden="true">
          <path d={HOLD_PATHS[hd.shape]} fill={hd.c} stroke="#1B1B3A" strokeWidth="2.5" strokeLinejoin="round" />
          <circle cx="20" cy="22" r="2.6" fill="#1B1B3A" opacity="0.6" />
        </svg>
      </>
    );
    const style = { position: 'absolute' as const, left: hd.x, top: hd.y, width: hd.s, height: hd.s, opacity };
    return onTap ? (
      <button key={key} type="button" className="bb-hold" aria-label="จับ hold นี้" onClick={onTap} style={{ ...style, padding: 0, border: 'none', background: 'none' }}>
        {inner}
      </button>
    ) : (
      <div key={key} style={style}>{inner}</div>
    );
  };
  return (
    <div style={{ width: 390, height: 620, position: 'relative', overflow: 'hidden', background: '#F3D9A8', fontFamily: "'Bai Jamjuree', sans-serif", color: '#1B1B3A' }}>
      <svg width="390" height="620" viewBox="0 0 390 620" style={{ position: 'absolute', inset: 0 }} aria-hidden="true">
        <defs>
          <pattern id="tnut" width="26" height="26" patternUnits="userSpaceOnUse"><circle cx="13" cy="13" r="2" fill="#C9A66E" /></pattern>
        </defs>
        <polygon points="0,0 130,0 150,620 0,620" fill="#EBCB93" />
        <polygon points="130,0 290,0 270,620 150,620" fill="#F3D9A8" />
        <polygon points="290,0 390,0 390,620 270,620" fill="#E5C185" />
        <rect width="390" height="620" fill="url(#tnut)" />
        <path d="M130 0L150 620 M290 0L270 620 M0 210H390 M0 420H390" stroke="#C9A66E" strokeWidth="2.5" />
        <rect x="0" y="596" width="390" height="24" fill="#3B5BDB" />
        <rect x="0" y="594" width="390" height="4" fill="#1B1B3A" />
      </svg>
      {route.map((hd, i) => {
        const on = ring.includes(i);
        return renderHold(hd, 'r' + i, 1, on, (onHoldTap || climbable) && on ? () => tap(i) : undefined);
      })}
      {others.map((hd, i) => renderHold(hd, 'o' + i, otherOpacity, false))}
      {mode === 'preview' && (
        <>
          <span style={{ position: 'absolute', left: 196, top: 572, height: 22, padding: '0 8px', borderRadius: 6, background: '#FFFFFF', border: '2px solid #1B1B3A', fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center' }}>START</span>
          <span style={{ position: 'absolute', left: 236, top: 24, height: 22, padding: '0 8px', borderRadius: 6, background: '#1B1B3A', color: '#FFC93C', border: '2px solid #1B1B3A', fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center' }}>TOP</span>
        </>
      )}
      {mode === 'climb' && (
        <div className={reaching ? 'bb-reach' : undefined} style={{ position: 'absolute', left: 150, top: Math.max(-20, top), transition: 'top 320ms cubic-bezier(.3,1.4,.5,1)', pointerEvents: 'none' }}>
          <Chibi pose={reaching ? 'cheer' : pose} w={110} band="#FFC93C" />
        </div>
      )}
    </div>
  );
}
