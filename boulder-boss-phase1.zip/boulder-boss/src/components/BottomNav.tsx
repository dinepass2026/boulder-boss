import { useNavigate } from 'react-router-dom';
import { toast } from '../lib/dc';

export type NavTab = 'map' | 'gym' | 'club' | 'shop' | 'profile';

const ITEMS: { id: NavTab; label: string; d: string; to?: string; disabled?: boolean }[] = [
  { id: 'map', label: 'แผนที่', d: 'M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z M9 3v15 M15 6v15', to: '/map' },
  { id: 'gym', label: 'ยิม', d: 'M4 21V9l8-6 8 6v12 M9 21v-6h6v6', to: '/gym' },
  { id: 'club', label: 'คลับ', d: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z' },
  // Shop is hidden for now (revenue phase) — kept in place but disabled so the 5-slot layout stays intact.
  { id: 'shop', label: 'ร้านค้า', d: 'M5 8h14l-1 13H6z M9 8V6a3 3 0 0 1 6 0v2', disabled: true },
  { id: 'profile', label: 'โปรไฟล์', d: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4 21c0-4 4-6 8-6s8 2 8 6', to: '/profile' },
];

/** Player-role bottom navigation, 390×84. */
export default function BottomNav({ active = 'map' }: { active?: NavTab | string }) {
  const navigate = useNavigate();
  return (
    <nav
      aria-label="เมนูหลัก"
      style={{ width: 390, height: 84, boxSizing: 'border-box', background: '#FFFFFF', borderTop: '2.5px solid #1B1B3A', display: 'grid', gridTemplateColumns: 'repeat(5, minmax(0, 1fr))', padding: '6px 6px 16px', fontFamily: "'Bai Jamjuree', sans-serif", color: '#1B1B3A' }}
    >
      {ITEMS.map((item) => {
        const on = item.id === active;
        return (
          <button
            key={item.id}
            type="button"
            className="bb-nav"
            aria-label={item.label}
            aria-current={on ? 'page' : undefined}
            disabled={item.disabled}
            onClick={() => (item.to ? navigate(item.to) : toast('คลับ — เปิดในเฟส 3'))}
            style={{ minHeight: 58, border: 'none', background: 'none', padding: 0, fontFamily: 'inherit', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, opacity: item.disabled ? 0.35 : 1 }}
          >
            <span style={{ width: 52, height: 34, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', background: on ? '#FFC93C' : 'transparent', border: `2px solid ${on ? '#1B1B3A' : 'transparent'}` }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B1B3A" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d={item.d} />
              </svg>
            </span>
            <span style={{ fontSize: 12, fontWeight: on ? 700 : 500, color: on ? '#1B1B3A' : '#55557A' }}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
