import { useId } from 'react';
import { color } from '../lib/tokens';

export type ChibiPose = 'stand' | 'climb' | 'wave' | 'cheer' | 'fall';

export interface ChibiProps {
  pose?: ChibiPose | string;
  skin?: string;
  hair?: string;
  shirt?: string;
  pants?: string;
  shoes?: string;
  bag?: string;
  /** Headband colour; omitted = no headband. */
  band?: string;
  /** Width in px; height is always w × 4/3. */
  w?: number | string;
}

// [left arm, right arm, legs, mouth]
const POSES: Record<string, [string, string, string, string]> = {
  stand: ['rotate(14 33 90)', 'rotate(-14 87 90)', '', 'M54 72q6 5 12 0'],
  climb: ['rotate(165 33 90)', 'rotate(-150 87 90)', 'translate(0 -4)', 'M55 73h10'],
  wave: ['rotate(14 33 90)', 'rotate(-150 87 90)', '', 'M53 71q7 7 14 0'],
  cheer: ['rotate(150 33 90)', 'rotate(-150 87 90)', 'translate(0 -2)', 'M52 70q8 9 16 0z'],
  fall: ['rotate(120 33 90)', 'rotate(-120 87 90)', 'rotate(8 60 120)', 'M55 75q5-5 10 0'],
};

/** Chibi climber avatar (head:body = 1:1). Every player renders with their own outfit. */
export default function Chibi({
  pose = 'stand',
  skin = '#F5C6A0',
  hair = '#2D2346',
  shirt = '#FF5F45',
  pants = '#3B5BDB',
  shoes = '#FFC93C',
  bag = '#17B2A0',
  band,
  w = 120,
}: ChibiProps) {
  const width = Number(w);
  const height = Math.round((width * 4) / 3);
  const [armL, armR, legs, mouth] = POSES[pose] ?? ['', '', '', 'M54 72q6 5 12 0'];
  const ink = color.ink;
  // Per-instance offset so a crowd of chibis never moves in sync.
  const seed = useId().split('').reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 997, 7);
  const delay = `-${(seed % 23) / 10}s`;
  const sw = 2.5;
  return (
    <div className={`bb-chibi bb-pose-${pose}`} style={{ width, height, ['--d' as string]: delay }}>
      <svg width={width} height={height} viewBox="0 0 120 160" role="img" aria-label="ตัวละครนักปีน">
        <ellipse className="bb-c-shadow" cx="60" cy="153" rx="30" ry="5" fill={ink} opacity={pose === 'climb' ? 0 : 0.15} />
        <g className="bb-c-body">
        <g transform={legs}>
          <rect x="43" y="110" width="15" height="32" rx="7" fill={pants} stroke={ink} strokeWidth={sw} />
          <rect x="62" y="110" width="15" height="32" rx="7" fill={pants} stroke={ink} strokeWidth={sw} />
          <path d="M40 139h19v9H38a3 3 0 0 1-3-3 6 6 0 0 1 5-6z" fill={shoes} stroke={ink} strokeWidth={sw} strokeLinejoin="round" />
          <path d="M61 139h19a6 6 0 0 1 5 6 3 3 0 0 1-3 3H61z" fill={shoes} stroke={ink} strokeWidth={sw} strokeLinejoin="round" />
        </g>
        <g className="bb-c-armL"><g transform={armL}>
          <rect x="27" y="88" width="13" height="28" rx="6.5" fill={shirt} stroke={ink} strokeWidth={sw} />
          <circle cx="33.5" cy="118" r="6" fill={skin} stroke={ink} strokeWidth={sw} />
        </g></g>
        <g className="bb-c-armR"><g transform={armR}>
          <rect x="80" y="88" width="13" height="28" rx="6.5" fill={shirt} stroke={ink} strokeWidth={sw} />
          <circle cx="86.5" cy="118" r="6" fill={skin} stroke={ink} strokeWidth={sw} />
        </g></g>
        <rect x="35" y="84" width="50" height="36" rx="15" fill={shirt} stroke={ink} strokeWidth={sw} />
        <path d="M50 86l10 8 10-8" fill="none" stroke={ink} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.5" />
        <rect x="72" y="108" width="15" height="15" rx="5" fill={bag} stroke={ink} strokeWidth={sw} />
        <path d="M73 112h13" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
        <circle cx="60" cy="52" r="37" fill={skin} stroke={ink} strokeWidth={sw} />
        <path
          d="M23 54c-2-24 14-40 37-40s39 16 37 40c-6-7-15-12-24-13 3 3 4 7 3 10-10-9-27-11-39-7-6 2-10 5-14 10z"
          fill={hair}
          stroke={ink}
          strokeWidth={sw}
          strokeLinejoin="round"
        />
        <path d="M27 40c8-4 58-4 66 0" fill="none" stroke={band ?? color.yellow} strokeWidth="6" strokeLinecap="round" opacity={band ? 1 : 0} />
        <g className="bb-c-eyes">
        <ellipse cx="46" cy="60" rx="5.5" ry="7.5" fill={ink} />
        <ellipse cx="74" cy="60" rx="5.5" ry="7.5" fill={ink} />
        <circle cx="48" cy="57" r="2.2" fill="#FFFFFF" />
        <circle cx="76" cy="57" r="2.2" fill="#FFFFFF" />
        </g>
        <ellipse cx="38" cy="71" rx="5.5" ry="3.2" fill="#FF8A8A" opacity="0.75" />
        <ellipse cx="82" cy="71" rx="5.5" ry="3.2" fill="#FF8A8A" opacity="0.75" />
        <path d={mouth} fill="none" stroke={ink} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}
